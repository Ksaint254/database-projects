ALTER TABLE customers ADD COLUMN IF NOT EXISTS account_number text;
CREATE SEQUENCE IF NOT EXISTS billwave_customer_account_seq START WITH 100001;
UPDATE customers SET account_number = lpad(nextval('billwave_customer_account_seq')::text, 6, '0') WHERE account_number IS NULL OR trim(account_number)='';
CREATE UNIQUE INDEX IF NOT EXISTS customers_account_number_unique ON customers(account_number);
CREATE TABLE IF NOT EXISTS tuma_collection_transactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  isp_id uuid NOT NULL REFERENCES isps(id) ON DELETE CASCADE,
  customer_id uuid REFERENCES customers(id) ON DELETE SET NULL,
  account_number text NOT NULL,
  amount numeric(12,2) NOT NULL CHECK (amount > 0),
  receipt_number text,
  provider_transaction_id text,
  status text NOT NULL DEFAULT 'received',
  raw_callback jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS tuma_collection_receipt_unique ON tuma_collection_transactions(receipt_number) WHERE receipt_number IS NOT NULL;
CREATE INDEX IF NOT EXISTS tuma_collection_account_idx ON tuma_collection_transactions(account_number, created_at DESC);
CREATE INDEX IF NOT EXISTS tuma_collection_isp_idx ON tuma_collection_transactions(isp_id, created_at DESC);