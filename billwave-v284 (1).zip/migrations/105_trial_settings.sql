CREATE TABLE IF NOT EXISTS billwave_settings (key text PRIMARY KEY, value text NOT NULL, updated_at timestamptz NOT NULL DEFAULT now());
INSERT INTO billwave_settings(key,value) VALUES ('trial_enabled','true') ON CONFLICT (key) DO NOTHING;
INSERT INTO billwave_settings(key,value) VALUES ('trial_days','14') ON CONFLICT (key) DO NOTHING;