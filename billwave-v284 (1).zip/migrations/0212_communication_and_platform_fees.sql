CREATE TABLE IF NOT EXISTS isp_whatsapp_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  isp_id uuid NOT NULL UNIQUE REFERENCES isps(id) ON DELETE CASCADE,
  enabled boolean NOT NULL DEFAULT false,
  provider_name text,
  api_url text,
  access_token text,
  phone_number_id text,
  business_account_id text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS isp_message_campaigns (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  isp_id uuid NOT NULL REFERENCES isps(id) ON DELETE CASCADE,
  name text NOT NULL,
  channel text NOT NULL CHECK (channel IN ('sms','whatsapp')),
  audience text NOT NULL DEFAULT 'all_active',
  message text NOT NULL,
  status text NOT NULL DEFAULT 'draft',
  scheduled_at timestamptz,
  sent_count integer NOT NULL DEFAULT 0,
  delivered_count integer NOT NULL DEFAULT 0,
  failed_count integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS isp_message_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  isp_id uuid NOT NULL REFERENCES isps(id) ON DELETE CASCADE,
  campaign_id uuid REFERENCES isp_message_campaigns(id) ON DELETE SET NULL,
  customer_id uuid REFERENCES customers(id) ON DELETE SET NULL,
  channel text NOT NULL CHECK (channel IN ('sms','whatsapp')),
  recipient text,
  status text NOT NULL DEFAULT 'queued',
  provider_reference text,
  error_message text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS billwave_platform_fees (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  isp_id uuid NOT NULL REFERENCES isps(id) ON DELETE CASCADE,
  payment_id uuid REFERENCES payments(id) ON DELETE SET NULL,
  service text NOT NULL DEFAULT 'pppoe',
  rate numeric(8,5) NOT NULL DEFAULT 0.0055,
  payment_amount numeric(14,2) NOT NULL,
  fee_amount numeric(14,2) NOT NULL,
  status text NOT NULL DEFAULT 'accrued',
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_isp_message_campaigns_isp ON isp_message_campaigns(isp_id, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_isp_message_logs_isp ON isp_message_logs(isp_id, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_billwave_platform_fees_isp ON billwave_platform_fees(isp_id, created_at DESC);