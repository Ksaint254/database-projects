CREATE TABLE IF NOT EXISTS isp_notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  isp_id uuid NOT NULL REFERENCES isps(id) ON DELETE CASCADE,
  type text NOT NULL,
  severity text NOT NULL DEFAULT 'info',
  title text NOT NULL,
  message text NOT NULL,
  entity_type text,
  entity_id uuid,
  read_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS isp_notifications_isp_created_idx ON isp_notifications(isp_id, created_at DESC);
CREATE INDEX IF NOT EXISTS isp_notifications_isp_unread_idx ON isp_notifications(isp_id, read_at) WHERE read_at IS NULL