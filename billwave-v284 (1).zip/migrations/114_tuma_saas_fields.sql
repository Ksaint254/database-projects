ALTER TABLE isp_tuma_settings ADD COLUMN IF NOT EXISTS tuma_business_id uuid;
ALTER TABLE isp_tuma_settings ADD COLUMN IF NOT EXISTS bank_id uuid;
ALTER TABLE isp_tuma_settings ADD COLUMN IF NOT EXISTS bank_name text;
ALTER TABLE isp_tuma_settings ADD COLUMN IF NOT EXISTS account_number text;
ALTER TABLE isp_tuma_settings ADD COLUMN IF NOT EXISTS business_name text;
ALTER TABLE isp_tuma_settings ADD COLUMN IF NOT EXISTS mobile text;
ALTER TABLE isp_tuma_settings ADD COLUMN IF NOT EXISTS provisioning_status text NOT NULL DEFAULT 'manual';
ALTER TABLE isp_tuma_settings ADD COLUMN IF NOT EXISTS last_error text;
CREATE UNIQUE INDEX IF NOT EXISTS isp_tuma_business_id_unique ON isp_tuma_settings(tuma_business_id) WHERE tuma_business_id IS NOT NULL;