CREATE TABLE IF NOT EXISTS isp_branding (
  isp_id uuid PRIMARY KEY REFERENCES isps(id) ON DELETE CASCADE,
  logo_url text,
  primary_color text NOT NULL DEFAULT '#f59e0b',
  dark_mode boolean NOT NULL DEFAULT true,
  updated_at timestamptz NOT NULL DEFAULT now()
)