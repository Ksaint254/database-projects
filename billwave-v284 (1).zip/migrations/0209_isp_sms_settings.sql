CREATE TABLE IF NOT EXISTS isp_sms_settings (
  isp_id uuid PRIMARY KEY REFERENCES isps(id) ON DELETE CASCADE,
  enabled boolean NOT NULL DEFAULT false,
  provider_name text,
  api_url text,
  api_key text,
  sender_id text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
)