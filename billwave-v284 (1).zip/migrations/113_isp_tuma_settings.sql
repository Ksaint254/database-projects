CREATE TABLE isp_tuma_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  isp_id uuid NOT NULL UNIQUE,
  email text NOT NULL,
  api_key text NOT NULL,
  enabled boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
)