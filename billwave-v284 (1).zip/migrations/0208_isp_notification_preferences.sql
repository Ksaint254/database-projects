CREATE TABLE IF NOT EXISTS isp_notification_preferences (
  isp_id uuid PRIMARY KEY REFERENCES isps(id) ON DELETE CASCADE,
  mikrotik_errors boolean NOT NULL DEFAULT true,
  payment_events boolean NOT NULL DEFAULT true,
  pppoe_events boolean NOT NULL DEFAULT true,
  subscription_events boolean NOT NULL DEFAULT true,
  system_errors boolean NOT NULL DEFAULT true,
  security_events boolean NOT NULL DEFAULT true,
  customer_expiry_sms boolean NOT NULL DEFAULT true,
  customer_payment_sms boolean NOT NULL DEFAULT true,
  customer_renewal_sms boolean NOT NULL DEFAULT true,
  reminder_days integer NOT NULL DEFAULT 3,
  updated_at timestamptz NOT NULL DEFAULT now()
)