BillWave Router Connector setup

1. Install Node.js 18 or newer on a computer/server inside the ISP network.
2. Create a connector in BillWave under MikroTik > Router Connector and copy the one-time token.
3. Set these environment variables:
   BILLWAVE_CONNECTOR_TOKEN=your_token
   MIKROTIK_URL=https://192.168.88.1/rest
   MIKROTIK_USER=admin
   MIKROTIK_PASSWORD=your_password
4. Run: node billwave-router-connector.js
5. The connector sends an encrypted outbound heartbeat to BillWave every 30 seconds and polls for router jobs.

The MikroTik remains private. Do not expose 192.168.88.1 to the internet.