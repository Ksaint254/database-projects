(function(){
  const API_ORIGIN='https://billwave.hatchable.site';
  document.documentElement.dataset.billwaveApi=API_ORIGIN;
  document.querySelectorAll('[data-app-link]').forEach(function(a){
    try{
      const u=new URL(a.getAttribute('href'),location.href);
      a.href=API_ORIGIN+u.pathname+u.search+u.hash;
    }catch(e){}
  });
})();