BILLWAVE PORTABLE WEBSITE

This folder is the portable static/public website layer.

Namecheap deployment:
1. Upload the contents of this folder to the desired document root (for example public_html/).
2. Keep assets/ beside index.html.
3. The links marked data-app-link point to the separately hosted BillWave application at https://billwave.hatchable.site.

Important:
- This folder contains no database, secrets, server-side code, or Hatchable SDK dependency.
- Do not copy api/, migrations/, lib/, seed.sql, or hatchable.toml to Namecheap as part of this static website deployment.
- The BillWave backend/API remains separately hosted.
- Future frontend changes should be made here first, then this folder can be exported as a ZIP for Namecheap.