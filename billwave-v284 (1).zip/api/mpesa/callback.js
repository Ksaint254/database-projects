import { db } from 'hatchable';
import { setPppoeEnabled } from '../../lib/mikrotik-auto.js';
import { provisionHotspot } from 'lib/mikrotik-hotspot.js';
export const access='public';
export const methods=['POST'];
export default async function(req,res){
  const body=req.body||{}; const cb=body.Body?.stkCallback;
  if(!cb)return res.status(400).json({error:'Invalid M-Pesa callback'});
  const checkout=cb.CheckoutRequestID; const resultCode=String(cb.ResultCode??'');
  const items=cb.CallbackMetadata?.Item||[]; const get=n=>items.find(x=>x.Name===n)?.Value??null; const receipt=get('MpesaReceiptNumber');
  const tx=await db.query('SELECT * FROM mpesa_transactions WHERE checkout_request_id=$1 LIMIT 1',[checkout]);
  if(!tx.rows[0]){
    const po=await db.query('SELECT * FROM pppoe_payment_orders WHERE checkout_request_id=$1 LIMIT 1',[checkout]);
    if(po.rows[0]){
      const o=po.rows[0];
      if(o.status==='completed')return res.json({ResultCode:0,ResultDesc:'Already processed'});
      if(resultCode!=='0'){await db.query("UPDATE pppoe_payment_orders SET status='failed' WHERE id=$1",[o.id]);return res.json({ResultCode:0,ResultDesc:'Accepted'});}
      const pkgq=await db.query('SELECT * FROM packages WHERE id=$1 AND isp_id=$2',[o.package_id,o.isp_id]);
      const cust=await db.query('SELECT id FROM customers WHERE id=$1 AND isp_id=$2',[o.customer_id,o.isp_id]);
      if(!pkgq.rows[0]||!cust.rows[0])return res.json({ResultCode:0,ResultDesc:'Accepted'});
      const pkg=pkgq.rows[0];
      const days=Number(pkg.duration_days||30);
      const sub=await db.query("SELECT id,expires_at FROM subscriptions WHERE customer_id=$1 AND package_id=$2 AND isp_id=$3 ORDER BY expires_at DESC NULLS LAST LIMIT 1",[o.customer_id,o.package_id,o.isp_id]);
      const base=new Date(); const old=sub.rows[0]?.expires_at?new Date(sub.rows[0].expires_at):null; if(old&&old>base)base.setTime(old.getTime()); const expiry=new Date(base.getTime()+days*86400000);
      if(sub.rows[0])await db.query("UPDATE subscriptions SET status='active',starts_at=COALESCE(starts_at,now()),expires_at=$1,updated_at=now() WHERE id=$2",[expiry.toISOString(),sub.rows[0].id]);
      else await db.query("INSERT INTO subscriptions(isp_id,customer_id,package_id,status,starts_at,expires_at) VALUES($1,$2,$3,'active',now(),$4)",[o.isp_id,o.customer_id,o.package_id,expiry.toISOString()]);
      const a=await db.query("SELECT username FROM pppoe_accounts WHERE customer_id=$1 AND isp_id=$2 ORDER BY created_at DESC LIMIT 1",[o.customer_id,o.isp_id]);
      let activated=false;if(a.rows[0]){const u=a.rows[0].username;await db.query("UPDATE pppoe_accounts SET status='active',expires_at=$1,profile=$2,updated_at=now() WHERE customer_id=$3 AND isp_id=$4 AND username=$5",[expiry.toISOString(),pkg.speed||null,o.customer_id,o.isp_id,u]);const r=await setPppoeEnabled(o.isp_id,u,true);activated=!!r.ok;}
      await db.query("INSERT INTO payments(isp_id,customer_id,amount,method,reference) VALUES($1,$2,$3,'mpesa',$4)",[o.isp_id,o.customer_id,o.amount,receipt]);
      await db.query("UPDATE pppoe_payment_orders SET status=$1,mpesa_receipt=$2,paid_at=now() WHERE id=$3",[activated?'completed':'provision_failed',receipt,o.id]);
      return res.json({ResultCode:0,ResultDesc:'Accepted',billwave:{payment:'completed',pppoe_activated:activated,expires_at:expiry.toISOString()}});
    }
    const ho=await db.query('SELECT * FROM hotspot_payment_orders WHERE checkout_request_id=$1 LIMIT 1',[checkout]);
    if(!ho.rows[0])return res.json({ResultCode:0,ResultDesc:'Accepted'});
    const h=ho.rows[0];
    if(h.status==='completed')return res.json({ResultCode:0,ResultDesc:'Already processed'});
    if(resultCode!=='0'){await db.query("UPDATE hotspot_payment_orders SET status='failed' WHERE id=$1",[h.id]);return res.json({ResultCode:0,ResultDesc:'Accepted'})}
    const profile=await db.query('SELECT * FROM hotspot_profiles WHERE id=$1 AND isp_id=$2',[h.profile_id,h.isp_id]);
    if(!profile.rows[0])return res.json({ResultCode:0,ResultDesc:'Accepted'});
    const p=profile.rows[0]; const network=await provisionHotspot(h.isp_id,{username:h.username,password:h.password,profile:p.name,comment:`BillWave ${p.name}`});
    await db.query("INSERT INTO hotspot_customer_sales(isp_id,profile_id,amount,purchased_at,duration_minutes,consumed_minutes,status,reference) VALUES($1,$2,$3,now(),$4,0,$5,$6)",[h.isp_id,p.id,h.amount,p.duration_minutes,network.success?'active':'provision_failed',h.username]);
    await db.query("UPDATE hotspot_payment_orders SET status=$1,mpesa_receipt=$2,paid_at=now() WHERE id=$3",[network.success?'completed':'provision_failed',receipt,h.id]);
    return res.json({ResultCode:0,ResultDesc:'Accepted'});
  }
  const t=tx.rows[0];
  if(t.status==='completed')return res.json({ResultCode:0,ResultDesc:'Already processed'});
  if(resultCode!=='0'){
    await db.query('UPDATE mpesa_transactions SET status=\'failed\',result_code=$1,result_description=$2,raw_callback=$3,updated_at=now() WHERE id=$4',[resultCode,cb.ResultDesc,JSON.stringify(body),t.id]);
    return res.json({ResultCode:0,ResultDesc:'Accepted'});
  }
  const amount=Number(get('Amount')||t.amount);
  await db.query("INSERT INTO payments (isp_id,customer_id,invoice_id,amount,method,reference) VALUES ($1,$2,$3,$4,'mpesa',$5)",[t.isp_id,t.customer_id,t.invoice_id,amount,receipt]);
  await db.query("UPDATE invoices SET balance=GREATEST(balance-$1,0), status=CASE WHEN balance-$1<=0 THEN 'paid' ELSE 'partial' END WHERE id=$2 AND isp_id=$3",[amount,t.invoice_id,t.isp_id]);
  let activated=false; let pppoeUsername=null; let newExpiry=null;
  if(t.invoice_id){
    await db.query("UPDATE subscriptions s SET status='active',starts_at=COALESCE(s.starts_at,now()),expires_at=now()+(p.duration_days||' days')::interval,updated_at=now() FROM invoices i JOIN packages p ON p.id=s.package_id WHERE s.id=i.subscription_id AND i.id=$1 AND i.isp_id=$2 AND i.balance<=0",[t.invoice_id,t.isp_id]);
    const a=await db.query("SELECT a.username,a.expires_at FROM pppoe_accounts a JOIN invoices i ON i.customer_id=a.customer_id WHERE i.id=$1 AND i.isp_id=$2 ORDER BY a.created_at DESC LIMIT 1",[t.invoice_id,t.isp_id]);
    if(a.rows[0]){pppoeUsername=a.rows[0].username;newExpiry=a.rows[0].expires_at;await db.query("UPDATE pppoe_accounts SET status='active',expires_at=COALESCE((SELECT s.expires_at FROM subscriptions s JOIN invoices i ON i.subscription_id=s.id WHERE i.id=$1 AND i.isp_id=$2 AND s.status='active' LIMIT 1),expires_at),updated_at=now() WHERE username=$3 AND isp_id=$2",[t.invoice_id,t.isp_id,pppoeUsername]);const fresh=await db.query('SELECT expires_at FROM pppoe_accounts WHERE isp_id=$1 AND username=$2 LIMIT 1',[t.isp_id,pppoeUsername]);newExpiry=fresh.rows[0]?.expires_at||newExpiry;const r=await setPppoeEnabled(t.isp_id,pppoeUsername,true);activated=r.ok;}
  }
  await db.query("UPDATE mpesa_transactions SET status='completed',mpesa_receipt=$1,result_code=$2,result_description=$3,raw_callback=$4,updated_at=now() WHERE id=$5",[receipt,resultCode,cb.ResultDesc,JSON.stringify(body),t.id]);
  return res.json({ResultCode:0,ResultDesc:'Accepted',billwave:{payment:'completed',pppoe_username:pppoeUsername,pppoe_activated:activated,expires_at:newExpiry}});
}