import { db } from "hatchable";
import { workspaceFor } from "../../lib/tenant-context.js";

export const access = "user";
export const methods = ["GET", "PUT"];

export default async function(req, res) {
  const workspace = await workspaceFor(req);
  if (!workspace) return res.status(403).json({ error: "ISP workspace not found" });

  if (req.method === "GET") {
    const { rows } = await db.query("SELECT id, provider, environment, short_code, account_reference, callback_url, enabled, created_at, updated_at FROM isp_mpesa_settings WHERE isp_id = $1 LIMIT 1", [workspace.isp_id]);
    return res.json({ configured: rows.length > 0, settings: rows[0] || null });
  }

  const body = req.body || {};
  const environment = body.environment === "production" ? "production" : "sandbox";
  const enabled = Boolean(body.enabled);
  const { rows } = await db.query("INSERT INTO isp_mpesa_settings (isp_id, provider, environment, short_code, account_reference, consumer_key, consumer_secret, passkey, callback_url, enabled) VALUES ($1, 'mpesa', $2, $3, $4, $5, $6, $7, $8, $9) ON CONFLICT (isp_id) DO UPDATE SET environment = EXCLUDED.environment, short_code = EXCLUDED.short_code, account_reference = EXCLUDED.account_reference, consumer_key = EXCLUDED.consumer_key, consumer_secret = EXCLUDED.consumer_secret, passkey = EXCLUDED.passkey, callback_url = EXCLUDED.callback_url, enabled = EXCLUDED.enabled, updated_at = now() RETURNING id, provider, environment, short_code, account_reference, callback_url, enabled, updated_at", [workspace.isp_id, environment, body.short_code || null, body.account_reference || null, body.consumer_key || null, body.consumer_secret || null, body.passkey || null, body.callback_url || null, enabled]);
  return res.json({ ok: true, settings: rows[0] });
}