import { db } from 'hatchable';
export const access = 'public';
export const methods = ['GET'];
export default async function(req,res){const ispId=req.query.isp_id;if(!ispId)return res.status(422).json({error:'isp_id is required'});const q=await db.query("SELECT id,name,duration_minutes,data_mb,price FROM hotspot_profiles WHERE isp_id=$1 AND status='active' ORDER BY price ASC",[ispId]);res.json({packages:q.rows})}