export const access = 'user';
export const methods = ['GET'];
import { db } from 'hatchable';
import { workspaceFor } from 'lib/tenant-context.js';
export default async function(req,res){const w=await workspaceFor(req);if(!w)return res.status(403).json({error:'No ISP workspace assigned'});const q=await db.query("SELECT s.*,p.name profile_name,c.name customer_name,GREATEST(s.duration_minutes-FLOOR(EXTRACT(EPOCH FROM(now()-s.purchased_at))/60),0)::int remaining_minutes FROM hotspot_customer_sales s JOIN hotspot_profiles p ON p.id=s.profile_id LEFT JOIN customers c ON c.id=s.customer_id WHERE s.isp_id=$1 AND s.status='active' ORDER BY s.purchased_at DESC",[w.isp_id]);res.json({sessions:q.rows})}