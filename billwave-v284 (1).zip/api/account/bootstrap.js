import { auth, db } from "hatchable";
export const access = "member";
export const methods = ["GET"];
export default async function (req, res) {
  const user = await auth.getUser(req);
  if (!user) return res.status(401).json({ error: "Not signed in." });

  let { rows } = await db.query(
    "SELECT iu.isp_id, iu.role, i.name AS isp_name, i.slug, i.status, p.timezone, p.currency FROM isp_users iu JOIN isps i ON i.id = iu.isp_id LEFT JOIN isp_profiles p ON p.isp_id = i.id WHERE iu.auth_user_id = $1 AND iu.status = 'active' ORDER BY i.created_at ASC LIMIT 1",
    [user.id]
  );

  // Recover legacy accounts where the ISP was created for the same email but
  // the stored Hatchable member id differs from the current auth identity.
  if (!rows.length && user.email) {
    const pending = await db.query(
      "SELECT id FROM isps WHERE lower(admin_email)=lower($1) ORDER BY created_at DESC LIMIT 1",
      [user.email]
    );
    if (pending.rows.length) {
      await db.query(
        "INSERT INTO isp_users (isp_id, auth_user_id, role, status) VALUES ($1, $2, 'isp_admin', 'active') ON CONFLICT (isp_id, auth_user_id) DO UPDATE SET status='active', role='isp_admin'",
        [pending.rows[0].id, user.id]
      );
      ({ rows } = await db.query(
        "SELECT iu.isp_id, iu.role, i.name AS isp_name, i.slug, i.status, p.timezone, p.currency FROM isp_users iu JOIN isps i ON i.id = iu.isp_id LEFT JOIN isp_profiles p ON p.isp_id = i.id WHERE iu.auth_user_id = $1 AND iu.status = 'active' ORDER BY i.created_at ASC LIMIT 1",
        [user.id]
      ));
    }
  }

  if (!rows.length) return res.status(403).json({ error: "No ISP workspace has been assigned to this account yet." });
  res.json({ workspace: rows[0], user: { id: user.id, email: user.email, name: user.name || null } });
}