import { auth } from 'hatchable';
import { workspaceFor } from 'lib/tenant-context.js';

export const access='public';
export const methods=['GET'];

export default async function(req,res){
  // Use the platform auth identity first. Some ISP workspace mappings can
  // expose a member record whose email is not the signed-in account email.
  const u=await auth.getUser(req)||req.member||req.user;
  if(!u)return res.status(401).json({error:'Sign in required'});
  const email=String(u.email||'').trim().toLowerCase();

  // Only the BillWave owner account may enter the Owner Admin surface.
  // Every other account, including ISP administrators, stays in its ISP workspace.
  if(email==='iancty8@gmail.com')return res.json({destination:'/admin',role:'owner'});

  // Normal ISP users land in their ISP workspace.
  const w=await workspaceFor(req);
  if(w)return res.json({destination:'/dashboard',role:w.role,isp_id:w.isp_id});

  return res.json({destination:'/onboarding',role:'new_user'});
}