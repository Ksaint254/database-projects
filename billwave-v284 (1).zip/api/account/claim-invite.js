import { db } from "hatchable";
export const access = "user";
export const methods = ["POST"];
export default async function (req, res) {
  const email = String(req.user.email || "").trim().toLowerCase();
  if (!email) return res.status(422).json({ error: "Your account does not have an email address." });
  const { rows } = await db.query("SELECT id AS isp_id FROM isps WHERE lower(admin_email) = lower($1) ORDER BY created_at ASC LIMIT 1", [email]);
  if (!rows.length) return res.status(403).json({ error: "No pending ISP administrator assignment was found for this email." });
  await db.query("INSERT INTO isp_users (isp_id, auth_user_id, role) VALUES ($1, $2, 'isp_admin') ON CONFLICT (isp_id, auth_user_id) DO NOTHING", [rows[0].isp_id, req.user.id]);
  res.json({ ok: true, isp_id: rows[0].isp_id, role: "isp_admin" });
}