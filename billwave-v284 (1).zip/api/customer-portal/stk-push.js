import { db } from 'hatchable';
export const access='public';
export const methods=['POST'];
export default async function(req,res){
 const {customer_id,package_id,phone}=req.body||{};
 if(!customer_id||!package_id||!phone)return res.status(422).json({error:'Customer, package and phone required'});
 const customer=await db.query("SELECT isp_id FROM customers WHERE id=$1",[customer_id]);
 const pack=await db.query("SELECT price FROM packages WHERE id=$1",[package_id]);
 if(!customer.rows.length||!pack.rows.length)return res.status(404).json({error:'Customer or package not found'});
 const tokenRes=await fetch('https://api.tuma.co.ke/auth/token',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({email:process.env.TUMA_EMAIL,api_key:process.env.TUMA_API_KEY})});
 const tokenJson=await tokenRes.json();
 const token=tokenJson?.data?.token||tokenJson?.token;
 if(!token)return res.status(500).json({error:'Tuma authentication failed'});
 const order=await db.query("INSERT INTO pppoe_payment_orders(isp_id,customer_id,package_id,phone,amount,status) VALUES($1,$2,$3,$4,$5,'pending') RETURNING id",[customer.rows[0].isp_id,customer_id,package_id,phone,pack.rows[0].price]);
 const push=await fetch('https://api.tuma.co.ke/payment/stk-push',{method:'POST',headers:{'Content-Type':'application/json','Authorization':`Bearer ${token}`},body:JSON.stringify({amount:Number(pack.rows[0].price),phone,callback_url:'https://billwave.hatchable.site/api/customer-portal/callback',description:'Internet subscription payment'})});
 const data=await push.json();
 if(data?.data){await db.query("UPDATE pppoe_payment_orders SET merchant_request_id=$1,checkout_request_id=$2 WHERE id=$3",[data.data.merchant_request_id,data.data.checkout_request_id,order.rows[0].id]);}
 res.json(data);
}