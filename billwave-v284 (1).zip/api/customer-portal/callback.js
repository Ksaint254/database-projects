import { db } from 'hatchable';
export const access='public';
export const methods=['POST'];
export default async function(req,res){
 const b=req.body||{};
 const q=await db.query("SELECT id,customer_id,package_id FROM pppoe_payment_orders WHERE checkout_request_id=$1 LIMIT 1",[b.checkout_request_id]);
 if(!q.rows.length)return res.json({received:true});
 if(b.result_code==='0'||b.status==='completed'){
  await db.query("UPDATE pppoe_payment_orders SET status='paid',mpesa_receipt=$1,paid_at=now() WHERE id=$2",[b.mpesa_receipt_number,q.rows[0].id]);
  await db.query("UPDATE customers SET status='active',package_id=$1,updated_at=now() WHERE id=$2",[q.rows[0].package_id,q.rows[0].customer_id]);
 }
 res.json({received:true});
}