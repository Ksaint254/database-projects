import { db } from 'hatchable';
export const access='public';
export const methods=['GET'];
export default async function(req,res){
 const slug=req.query.slug;
 if(!slug)return res.status(422).json({error:'ISP slug required'});
 const isp=await db.query("SELECT id,name FROM isps WHERE slug=$1 AND status='active'",[slug]);
 if(!isp.rows.length)return res.status(404).json({error:'ISP not found'});
 const packages=await db.query("SELECT id,name,speed,price,description FROM packages WHERE isp_id=$1 AND status='active'",[isp.rows[0].id]);
 res.json({isp:isp.rows[0],packages:packages.rows});
}