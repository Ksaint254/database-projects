import { db } from "hatchable";
export const access = "public";
export const methods = ["POST"];
function phone(v){let p=String(v||'').replace(/\D/g,'');if(p.startsWith('0'))p='254'+p.slice(1);if(p.startsWith('+'))p=p.slice(1);return /^2547\d{8}$/.test(p)?p:null}
export default async function(req,res){
 const b=req.body||{}, customerNumber=String(b.customer_number||b.account_number||'').trim(), invoiceId=b.invoice_id, msisdn=phone(b.phone);
 if(!customerNumber||!invoiceId||!msisdn)return res.status(422).json({error:'Account number, invoice and valid Kenyan mobile number are required'});
 const q=await db.query("SELECT c.id customer_id,c.isp_id,c.account_number,i.id invoice_id,i.invoice_number,i.balance FROM customers c JOIN invoices i ON i.customer_id=c.id AND i.isp_id=c.isp_id WHERE (c.account_number=$1 OR c.customer_number=$1) AND c.id=$2 AND i.id=$3 AND CASE WHEN regexp_replace(c.phone,'\\D','','g') LIKE '0%' THEN '254'||substring(regexp_replace(c.phone,'\\D','','g') FROM 2) ELSE regexp_replace(c.phone,'\\D','','g') END=$4 LIMIT 1",[customerNumber,b.customer_id,invoiceId,msisdn]);
 if(!q.rows.length)return res.status(404).json({error:'Customer or invoice could not be verified'});
 const x=q.rows[0], amount=Math.min(Number(x.balance),Number(b.amount)||Number(x.balance));if(amount<=0)return res.status(400).json({error:'This invoice is already paid'});
 const cfg=await db.query("SELECT email,api_key FROM isp_tuma_settings WHERE isp_id=$1 AND enabled=true LIMIT 1",[x.isp_id]);if(!cfg.rows.length)return res.status(400).json({error:'Tuma payments are not enabled for this ISP'});
 const s=cfg.rows[0];
 const auth=await fetch('https://api.tuma.co.ke/auth/token',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({email:s.email,api_key:s.api_key})});const ad=await auth.json().catch(()=>({}));if(!auth.ok||!ad.success)return res.status(502).json({error:ad.message||'Unable to authenticate with Tuma'});const token=ad.data?.token||ad.token;if(!token)return res.status(502).json({error:'Tuma returned no access token'});
 const callback=`${new URL(req.url,'https://billwave.hatchable.site').origin}/api/tuma/customer-callback`;
 const push=await fetch('https://api.tuma.co.ke/payment/stk-push',{method:'POST',headers:{'Content-Type':'application/json','Authorization':`Bearer ${token}`},body:JSON.stringify({amount:Math.round(amount),phone:msisdn,callback_url:callback,description:`BillWave ${x.invoice_number}`,account_reference:x.account_number||x.invoice_number})});const pd=await push.json().catch(()=>({}));if(!push.ok||!pd.success)return res.status(502).json({error:pd.message||'Tuma STK Push failed'});const d=pd.data||pd;
 await db.query("INSERT INTO mpesa_transactions (isp_id,customer_id,invoice_id,merchant_request_id,checkout_request_id,phone,amount,account_reference,status) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,'pending')",[x.isp_id,x.customer_id,x.invoice_id,d.merchant_request_id||null,d.checkout_request_id||null,msisdn,amount,x.account_number||x.invoice_number]);
 res.json({ok:true,message:d.customer_message||'Tuma STK Push sent. Enter your M-Pesa PIN on your phone.',checkout_request_id:d.checkout_request_id||null,account_number:x.account_number||null});
}