import { db } from "hatchable";
export const access = "public";
export const methods = ["POST"];
function clean(v){return String(v||'').trim();}
export default async function(req,res){
  const b=req.body||{}; const customerNumber=clean(b.customer_number||b.account_number); const phone=clean(b.phone).replace(/\D/g,'');
  if(!customerNumber||!phone)return res.status(422).json({error:'Account number and phone number are required'});
  const normalized=phone.startsWith('0')?'254'+phone.slice(1):phone.startsWith('+')?phone.slice(1):phone;
  const q=await db.query("SELECT c.id,c.customer_number,c.account_number,c.name,c.phone,c.status,p.name AS package_name,p.speed,s.status AS subscription_status,s.expires_at,COALESCE(SUM(CASE WHEN i.status IN ('unpaid','partial') THEN i.balance ELSE 0 END),0) AS outstanding FROM customers c LEFT JOIN packages p ON p.id=c.package_id AND p.isp_id=c.isp_id LEFT JOIN subscriptions s ON s.customer_id=c.id AND s.isp_id=c.isp_id LEFT JOIN invoices i ON i.customer_id=c.id AND i.isp_id=c.isp_id WHERE (c.account_number=$1 OR c.customer_number=$1) AND CASE WHEN regexp_replace(c.phone,'\\D','','g') LIKE '0%' THEN '254'||substring(regexp_replace(c.phone,'\\D','','g') FROM 2) ELSE regexp_replace(c.phone,'\\D','','g') END=$2 GROUP BY c.id,p.name,p.speed,s.status,s.expires_at LIMIT 1",[customerNumber,normalized]);
  if(!q.rows.length)return res.status(404).json({error:'Customer not found. Check your account number and phone number.'});
  const c=q.rows[0]; const inv=await db.query("SELECT id,invoice_number,amount,balance,status,due_date FROM invoices WHERE customer_id=$1 AND isp_id=(SELECT isp_id FROM customers WHERE id=$1) AND status IN ('unpaid','partial') ORDER BY created_at DESC",[c.id]);
  const gw=await db.query("SELECT (EXISTS(SELECT 1 FROM isp_mpesa_settings m WHERE m.isp_id=(SELECT isp_id FROM customers WHERE id=$1) AND m.enabled=true AND m.consumer_key IS NOT NULL AND m.consumer_secret IS NOT NULL AND m.passkey IS NOT NULL)) AS mpesa, (EXISTS(SELECT 1 FROM isp_tuma_settings t WHERE t.isp_id=(SELECT isp_id FROM customers WHERE id=$1) AND t.enabled=true AND t.api_key IS NOT NULL)) AS tuma, (EXISTS(SELECT 1 FROM isp_bank_settings b WHERE b.isp_id=(SELECT isp_id FROM customers WHERE id=$1) AND b.enabled=true)) AS bank",[c.id]);
  const bank=gw.rows[0]?.bank?await db.query("SELECT bank_name,account_name,account_number,branch,swift_code,instructions FROM isp_bank_settings WHERE isp_id=(SELECT isp_id FROM customers WHERE id=$1) AND enabled=true LIMIT 1",[c.id]):{rows:[]};
  return res.json({customer:c,invoices:inv.rows,payment_gateways:gw.rows[0]||{mpesa:false,tuma:false,bank:false},bank_details:bank.rows[0]||null});
}