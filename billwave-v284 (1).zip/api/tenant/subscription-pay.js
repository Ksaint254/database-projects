import { auth, db } from 'hatchable';
import { workspaceFor } from 'lib/tenant-context.js';
export const access='public'; export const methods=['POST'];
export default async function(req,res){
 const u=await auth.requireUser(req,res); if(!u)return;
 req.user=u;
 const w=await workspaceFor(req); if(!w)return res.status(403).json({error:'No ISP workspace assigned'});
 const {plan_id,reference,amount}=req.body||{};
 if(!plan_id||!reference||!amount)return res.status(422).json({error:'Plan, bank reference and amount are required'});
 const plan=await db.query("SELECT id,name,monthly_price FROM billwave_plans WHERE id=$1 AND status='active'",[plan_id]);
 if(!plan.rows.length)return res.status(422).json({error:'Invalid BillWave plan'});
 const n=Number(amount); if(!Number.isFinite(n)||n<=0)return res.status(422).json({error:'Invalid payment amount'});
 const dup=await db.query("SELECT id FROM billwave_subscription_payments WHERE lower(reference)=lower($1) LIMIT 1",[String(reference).trim()]);
 if(dup.rows.length)return res.status(409).json({error:'That payment reference has already been submitted'});
 let sub=await db.query("SELECT id FROM isp_subscriptions WHERE isp_id=$1 ORDER BY created_at DESC LIMIT 1",[w.isp_id]);
 if(!sub.rows.length) sub=await db.query("INSERT INTO isp_subscriptions(isp_id,plan_id,status) VALUES($1,$2,'pending') RETURNING id",[w.isp_id,plan_id]);
 else await db.query("UPDATE isp_subscriptions SET plan_id=$1,status=CASE WHEN status='active' THEN status ELSE 'pending' END WHERE id=$2 AND isp_id=$3",[plan_id,sub.rows[0].id,w.isp_id]);
 const payment=await db.query("INSERT INTO billwave_subscription_payments(isp_subscription_id,amount,payment_method,reference,status,paid_at) VALUES($1,$2,'bank_transfer',$3,'pending',NULL) RETURNING id,amount,payment_method,reference,status,created_at",[sub.rows[0].id,n,String(reference).trim()]);
 return res.status(201).json({payment:payment.rows[0],message:'Payment submitted for BillWave admin verification'});
}