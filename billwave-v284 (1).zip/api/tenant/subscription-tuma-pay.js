import { auth, db } from 'hatchable';
import { workspaceFor } from 'lib/tenant-context.js';
export const access='public'; export const methods=['POST'];
export default async function(req,res){
 const u=await auth.requireUser(req,res); if(!u)return; req.user=u;
 const w=await workspaceFor(req); if(!w)return res.status(403).json({error:'No ISP workspace assigned'});
 const {plan_id,phone}=req.body||{}; if(!plan_id||!phone)return res.status(422).json({error:'Plan and phone are required'});
 const plan=await db.query("SELECT id,name,monthly_price FROM billwave_plans WHERE id=$1 AND status='active'",[plan_id]); if(!plan.rows.length)return res.status(422).json({error:'Invalid BillWave plan'});
 const amount=Number(plan.rows[0].monthly_price); if(!Number.isFinite(amount)||amount<=0)return res.status(422).json({error:'Invalid plan amount'});
 let sub=await db.query('SELECT id FROM isp_subscriptions WHERE isp_id=$1 ORDER BY created_at DESC LIMIT 1',[w.isp_id]);
 if(!sub.rows.length)sub=await db.query("INSERT INTO isp_subscriptions(isp_id,plan_id,status) VALUES($1,$2,'pending') RETURNING id",[w.isp_id,plan_id]);
 else await db.query('UPDATE isp_subscriptions SET plan_id=$1 WHERE id=$2',[plan_id,sub.rows[0].id]);
 const normalized=String(phone).replace(/\s+/g,'').replace(/^\+/,'').replace(/^0/,'254'); if(!/^2547\d{8}$/.test(normalized))return res.status(422).json({error:'Use a valid Kenyan M-Pesa number such as 254712345678'});
 const tokenRes=await fetch('https://api.tuma.co.ke/auth/token',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({email:process.env.TUMA_EMAIL,api_key:process.env.TUMA_API_KEY})});
 const tokenBody=await tokenRes.json().catch(()=>null),token=tokenBody?.data?.token||tokenBody?.token; if(!tokenRes.ok||!token)return res.status(502).json({error:'Tuma authentication failed',details:tokenBody?.message||null});
 const callback=`${new URL(req.url).origin}/api/tuma/callback`;
 const push=await fetch('https://api.tuma.co.ke/payment/stk-push',{method:'POST',headers:{'Content-Type':'application/json','Authorization':`Bearer ${token}`},body:JSON.stringify({amount,phone:normalized,callback_url:callback,description:`BillWave ${plan.rows[0].name} subscription`})});
 const pushBody=await push.json().catch(()=>({})); if(!push.ok||!pushBody?.success||!(pushBody?.data?.checkout_request_id||pushBody?.checkout_request_id))return res.status(502).json({error:pushBody?.message||'Tuma STK Push failed',details:pushBody?.result_desc||null});
 const d=pushBody.data||pushBody;
 await db.query("INSERT INTO billwave_subscription_payments(isp_subscription_id,amount,payment_method,status,provider,merchant_request_id,checkout_request_id,paid_at) VALUES($1,$2,'mpesa','pending','tuma',$3,$4,NULL)",[sub.rows[0].id,amount,d.merchant_request_id||null,d.checkout_request_id]);
 res.status(201).json({success:true,message:d.customer_message||pushBody.message||'STK Push sent successfully',checkout_request_id:d.checkout_request_id});
}