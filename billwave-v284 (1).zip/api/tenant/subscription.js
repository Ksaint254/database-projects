import { auth, db } from 'hatchable';
import { workspaceFor } from 'lib/tenant-context.js';
export const access='public'; export const methods=['GET'];
export default async function(req,res){
 const u=await auth.requireUser(req,res); if(!u)return;
 req.user=u;
 const w=await workspaceFor(req); if(!w)return res.status(403).json({error:'No ISP workspace assigned'});
 const sub=await db.query("SELECT s.id,s.status,s.started_at,s.renews_at,p.id plan_id,p.name plan_name,p.monthly_price,p.description FROM isp_subscriptions s JOIN billwave_plans p ON p.id=s.plan_id WHERE s.isp_id=$1 ORDER BY s.created_at DESC LIMIT 1",[w.isp_id]);
 const plans=await db.query("SELECT id,name,monthly_price,description FROM billwave_plans WHERE status='active' ORDER BY monthly_price");
 const payments=await db.query("SELECT id,amount,payment_method,reference,status,paid_at,created_at FROM billwave_subscription_payments WHERE isp_subscription_id=$1 ORDER BY created_at DESC LIMIT 10",[sub.rows[0]?.id||null]);
 const bank=await db.query("SELECT bank_name,account_name,account_number,branch,instructions FROM billwave_bank_settings ORDER BY updated_at DESC LIMIT 1");
 return res.json({subscription:sub.rows[0]||null,plans:plans.rows,payments:payments.rows,bank:bank.rows[0]||null});
}