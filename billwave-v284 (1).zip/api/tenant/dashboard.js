import { db } from "hatchable";
import { workspaceFor } from "lib/tenant-context.js";

// BillWave ISP users are end-user accounts, not Hatchable collaborators.
// Keep this route public at the edge and resolve the signed-in app user in workspaceFor.
export const access="public";
export const methods=["GET"];

export default async function(req,res){
 const w=await workspaceFor(req); if(!w)return res.status(401).json({error:"Login required"});
 const id=w.isp_id;
 // Reconcile stale connector state before calculating dashboard totals. The
 // heartbeat sets a router online, but nothing should leave an old `online`
 // flag behind forever when the router disappears from the network.
 await db.query(`
   UPDATE mikrotik_routers r
   SET status='offline', last_error=COALESCE(last_error,'Heartbeat timeout')
   WHERE r.isp_id=$1 AND r.status='online'
     AND EXISTS (
       SELECT 1 FROM router_connectors rc
       WHERE rc.router_id=r.id
         AND rc.isp_id=r.isp_id
         AND (rc.last_seen_at IS NULL OR rc.last_seen_at < now()-interval '90 seconds')
     )`,[id]);
 const q=async(sql,p=[id])=>(await db.query(sql,p)).rows;
 const [customers,active,expired,expiring,pppoe,online,routers,routerOnline,payments,todayPayments,invoices,fees,recent]=await Promise.all([
 q("SELECT count(*)::int count FROM customers WHERE isp_id=$1"),
 q("SELECT count(*)::int count FROM customers WHERE isp_id=$1 AND status='active'"),
 q("SELECT count(DISTINCT customer_id)::int count FROM pppoe_accounts WHERE isp_id=$1 AND expires_at IS NOT NULL AND expires_at<now()"),
 q("SELECT count(DISTINCT customer_id)::int count FROM pppoe_accounts WHERE isp_id=$1 AND expires_at>now() AND expires_at<=now()+interval '7 days' AND status='active'"),
 q("SELECT count(*)::int count FROM pppoe_accounts WHERE isp_id=$1"),
 q("SELECT count(*)::int count FROM pppoe_accounts a WHERE a.isp_id=$1 AND a.status='active' AND EXISTS (SELECT 1 FROM router_connectors rc WHERE rc.router_id=a.router_id AND rc.last_seen_at>=now()-interval '90 seconds' AND COALESCE(rc.metadata->'ppp_active','[]'::jsonb) @> jsonb_build_array(jsonb_build_object('name',a.username)))"),
 q("SELECT count(*)::int count FROM mikrotik_routers WHERE isp_id=$1"),
 q("SELECT count(*)::int count FROM mikrotik_routers WHERE isp_id=$1 AND status='online'"),
 q("SELECT COALESCE(sum(amount),0) total FROM payments WHERE isp_id=$1 AND paid_at>=date_trunc('month',now())"),
 q("SELECT COALESCE(sum(amount),0) total FROM payments WHERE isp_id=$1 AND paid_at>=date_trunc('day',now())"),
 q("SELECT COALESCE(sum(balance),0) total FROM invoices WHERE isp_id=$1 AND status IN ('unpaid','partial','pending')"),
 q("SELECT COALESCE(sum(fee_amount),0) total FROM billwave_platform_fees WHERE isp_id=$1 AND service='pppoe' AND status='accrued'"),
 q("SELECT p.amount,p.method,p.reference,p.paid_at,c.name customer_name FROM payments p JOIN customers c ON c.id=p.customer_id WHERE p.isp_id=$1 ORDER BY p.paid_at DESC LIMIT 6")
 ]);
 const isp=await db.query("SELECT name,email FROM isps WHERE id=$1 LIMIT 1",[id]);
 const trend=await q("SELECT to_char(d,'DD Mon') label,COALESCE(sum(p.amount),0) amount FROM generate_series(current_date-interval '6 days',current_date,interval '1 day') d LEFT JOIN payments p ON p.isp_id=$1 AND p.paid_at>=d AND p.paid_at<d+interval '1 day' GROUP BY d ORDER BY d");
 res.json({role:w.role,isp_name:isp.rows[0]?.name||'',isp_email:isp.rows[0]?.email||'',customers:customers[0].count,active_customers:active[0].count,expired_customers:expired[0].count,expiring_7d:expiring[0].count,pppoe:pppoe[0].count,online_pppoe:online[0].count,routers:routers[0].count,online_routers:routerOnline[0].count,revenue_month:Number(payments[0].total),revenue_today:Number(todayPayments[0].total),outstanding:Number(invoices[0].total),pppoe_platform_fees:Number(fees[0].total),trend,recent});
}