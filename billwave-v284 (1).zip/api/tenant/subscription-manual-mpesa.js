import { auth, db } from 'hatchable';
import { workspaceFor } from 'lib/tenant-context.js';
export const access='public'; export const methods=['POST'];
export default async function(req,res){
 const u=await auth.requireUser(req,res); if(!u)return; req.user=u;
 const w=await workspaceFor(req); if(!w)return res.status(403).json({error:'No ISP workspace assigned'});
 const {plan_id,receipt}=req.body||{}; const code=String(receipt||'').trim().toUpperCase();
 if(!plan_id||!code)return res.status(422).json({error:'Select a plan and enter the M-Pesa receipt code'});
 if(!/^[A-Z0-9-]{5,30}$/.test(code))return res.status(422).json({error:'Enter a valid M-Pesa receipt code'});
 const plan=await db.query("SELECT id,monthly_price FROM billwave_plans WHERE id=$1 AND status='active'",[plan_id]); if(!plan.rows.length)return res.status(422).json({error:'Invalid plan'});
 const sub=await db.query('SELECT id FROM isp_subscriptions WHERE isp_id=$1 ORDER BY created_at DESC LIMIT 1',[w.isp_id]); if(!sub.rows.length)return res.status(409).json({error:'No subscription found'});
 const duplicate=await db.query('SELECT id FROM billwave_subscription_payments WHERE mpesa_receipt=$1 OR reference=$1 LIMIT 1',[code]); if(duplicate.rows.length)return res.status(409).json({error:'This M-Pesa receipt has already been submitted'});
 await db.query('UPDATE isp_subscriptions SET plan_id=$1 WHERE id=$2',[plan_id,sub.rows[0].id]);
 const q=await db.query("INSERT INTO billwave_subscription_payments(isp_subscription_id,amount,payment_method,reference,mpesa_receipt,status,provider,paid_at,verification_note) VALUES($1,$2,'mpesa_manual',$3,$3,'pending','manual',NULL,'Awaiting owner verification') RETURNING id",[sub.rows[0].id,Number(plan.rows[0].monthly_price),code]);
 res.status(201).json({success:true,payment_id:q.rows[0].id,message:'Receipt submitted. BillWave will verify it manually.'});
}