import { db } from 'hatchable';

export const access = 'admin';
export const methods = ['POST'];

function esc(v) {
  return String(v).replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/\$/g, '\\$').replace(/\r?\n/g, ' ');
}

export default async function (req, res) {
  const routerId = String(req.body?.router_id || '').trim();
  if (!routerId) return res.status(422).json({ error: 'router_id is required' });

  const q = await db.query(
    `SELECT r.id AS router_id, r.name AS router_name, pc.connector_token
     FROM mikrotik_routers r
     JOIN router_provision_codes pc ON pc.router_id=r.id
     WHERE r.id=$1 AND pc.status='active' AND pc.expires_at>now()
     ORDER BY pc.created_at DESC LIMIT 1`,
    [routerId]
  );
  if (!q.rows[0]) return res.status(404).json({ error: 'No active BillWave provision token was found for this router. Generate a new provisioning code first.' });

  const token = esc(q.rows[0].connector_token);
  const script = `# BillWave heartbeat repair - RouterOS 7
:local api "https://billwave.hatchable.site"
:local token "${token}"
:local n [/system identity get name]
:local u [/system resource get uptime]
:local v [/system resource get version]
:local b [/system resource get board-name]
:local a [/system resource get architecture-name]
:local cc [/system resource get cpu-count]
:local cf [/system resource get cpu-frequency]
:local cm [/system resource get total-memory]
:local fm [/system resource get free-memory]
:local cl [/system resource get cpu-load]
:local fh [/system resource get free-hdd-space]
:local th [/system resource get total-hdd-space]
:local p [/system resource get platform]
:local activeSessions [:toarray ""]
:foreach sid in=[/ppp active find] do={
  :local sname [/ppp active get $sid name]
  :local sservice [/ppp active get $sid service]
  :local saddress [/ppp active get $sid address]
  :local suptime [/ppp active get $sid uptime]
  :local scaller [/ppp active get $sid caller-id]
  :set activeSessions ($activeSessions, {"name"=$sname;"service"=$sservice;"address"=$saddress;"uptime"=$suptime;"caller-id"=$scaller})
}
:local metadata {"identity"=$n;"uptime"=$u;"version"=$v;"board"=$b;"architecture"=$a;"cpu_count"=$cc;"cpu_frequency"=$cf;"total_memory"=$cm;"free_memory"=$fm;"cpu_load"=$cl;"free_hdd_space"=$fh;"total_hdd_space"=$th;"platform"=$p;"ppp_active"=$activeSessions}
:local d [:serialize to=json value={"metadata"=$metadata} options=json.no-string-conversion]
:onerror e in={ /tool fetch url=($api . "/api/connector/heartbeat") http-method=post http-header-field=("X-Connector-Token: " . $token . ",Content-Type: application/json") http-data=$d output=none } do={ :log warning ("BillWave heartbeat repair failed: " . $e) }
:log info "BillWave heartbeat repair installed"
/system script remove [find where name="billwave-heartbeat"]
/system script add name="billwave-heartbeat" policy=read,write,test source=[/system script get [find where name="billwave-heartbeat-repair-temp"] source]
`;

  res.json({ router_id: q.rows[0].router_id, router_name: q.rows[0].router_name, script });
}