import { db } from 'hatchable';

export const access = 'public';
export const methods = ['GET'];

async function hash(v) {
  const b = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(v));
  return [...new Uint8Array(b)].map(x => x.toString(16).padStart(2, '0')).join('');
}

function esc(v) {
  return String(v)
    .replace(/\\/g, '\\\\')
    .replace(/"/g, '\\"')
    .replace(/\$/g, '\\$')
    .replace(/\r?\n/g, ' ');
}

export default async function (req, res) {
  const raw = String(req.headers['x-connector-token'] || '').trim();
  if (!raw) return res.status(401).send('Invalid connector token\n');

  const h = await hash(raw);
  const c = await db.query(
    'SELECT id FROM router_connectors WHERE token_hash=$1 LIMIT 1',
    [h]
  );
  // Provisioned routers may still authenticate with the connector token stored
  // on their router_provision_codes record. Accept that token here too so the
  // safe connector-repair endpoint can retrieve the current script without
  // requiring a second credential.
  let valid = !!c.rows[0];
  if (!valid) {
    const p = await db.query(
      `SELECT id FROM router_provision_codes
       WHERE connector_token=$1 AND connector_token IS NOT NULL
       ORDER BY created_at DESC LIMIT 1`,
      [raw]
    );
    valid = !!p.rows[0];
  }
  if (!valid) return res.status(401).send('Invalid connector token\n');

  const token = esc(raw);
  const api = 'https://billwave.hatchable.site';
  const source = `:global billwaveConnectorRunning
:if ($billwaveConnectorRunning = true) do={ :return }
:set billwaveConnectorRunning true
:local api "${api}"
:local token "${token}"
:onerror pollError in={
  :local r [/tool fetch url=($api . "/api/connector/jobs") http-method=get http-header-field=("X-Connector-Token: " . $token) output=user as-value]
  :if (($r->"status") = "finished") do={
    :local body ($r->"data")
    :if ([:len $body] > 0) do={
      :local response [:deserialize from=json value=$body]
      :local job ($response->"job")
      :if ([:len $job] > 0) do={
        :local jobId ($job->"id")
        :local action ($job->"action")
        :local payload ($job->"payload")
        :local path ($payload->"path")
        :local username ($payload->"username")
        :local result {"ok"=false;"error"="Unsupported connector operation"}
        :local success false

        :if (($action = "mikrotik") and ([:len $jobId] > 0)) do={
          :if ($path = "/ppp/secret/disable") do={
            :local ids [/ppp secret find where name=$username]
            :if ([:len $ids] > 0) do={
              :local id [:pick $ids 0]
              /ppp secret set $id disabled=yes
              :local actualDisabled [/ppp secret get $id disabled]
              :if ($actualDisabled = true) do={
                :set result {"ok"=true;"username"=$username;"disabled"=true}
                :set success true
              } else={
                :set result {"ok"=false;"username"=$username;"disabled"=false;"error"=("RouterOS did not persist disabled=yes for " . $username)}
              }
            } else={ :set result {"ok"=false;"error"=("PPP secret not found: " . $username)} }
          }

          :if ($path = "/ppp/active/disconnect") do={
            :local ids [/ppp active find where name=$username]
            :foreach id in=$ids do={ /ppp active remove $id }
            :local remaining [/ppp active find where name=$username]
            :if ([:len $remaining] = 0) do={
              :set result {"ok"=true;"username"=$username;"disconnected"=true}
              :set success true
            } else={
              :set result {"ok"=false;"username"=$username;"disconnected"=false;"error"=("PPPoE session still active for " . $username)}
            }
          }

          :if ($path = "/ppp/secret/remove") do={
            # Safety: never physically remove a PPP secret from the live router.
            # A secret can be tied to an active PPPoE session, and deleting it
            # has caused collateral session churn on this production router.
            # "remove" is therefore treated as a safe retirement operation:
            # disable the exact secret and disconnect only its exact sessions.
            :local ids [/ppp secret find where name=$username]
            :if ([:len $ids] > 0) do={
              :local id [:pick $ids 0]
              /ppp secret set $id disabled=yes comment="BillWave retired"
              :local activeIds [/ppp active find where name=$username]
              :foreach activeId in=$activeIds do={ /ppp active remove $activeId }
              :local verify [/ppp secret find where name=$username]
              :if ([:len $verify] > 0) do={
                :set result {"ok"=true;"username"=$username;"removed"=false;"retired"=true;"disabled"=true}
                :set success true
              } else={
                :set result {"ok"=false;"username"=$username;"error"=("PPP secret disappeared during safe retirement: " . $username)}
              }
            } else={
              :set result {"ok"=true;"username"=$username;"removed"=true;"retired"=true;"note"="PPP secret was already absent"}
              :set success true
            }
          }

          :if ($path = "/ppp/secret/upsert") do={
            :local password ($payload->"password")
            :local profile ($payload->"profile")
            :local disabled ($payload->"disabled")
            :local expiresAt ($payload->"expires_at")
            :local accountStatus ($payload->"status")
            :local allowEnable ($payload->"allow_enable")
            :local ids [/ppp secret find where name=$username]
            :if (($disabled = false) and (($accountStatus != "active") or ($allowEnable != true))) do={ :set disabled true }
            :if (($disabled = false) and ($allowEnable != true)) do={
              :set result {"ok"=true;"skipped"=true;"username"=$username;"reason"="Refused to enable PPP secret with an expiry-bound job"}
              :set success true
            } else={
              :if ([:len $ids] = 0) do={
                /ppp secret add name=$username password=$password service=pppoe profile=$profile disabled=$disabled comment="BillWave managed"
              } else={
                :local id [:pick $ids 0]
                :local currentPassword [/ppp secret get $id password]
                :local currentService [/ppp secret get $id service]
                :local currentProfile [/ppp secret get $id profile]
                :local currentDisabled [/ppp secret get $id disabled]
                :local currentComment [/ppp secret get $id comment]
                :if (($currentPassword != $password) or ($currentService != "pppoe") or ($currentProfile != $profile) or ($currentDisabled != $disabled) or ($currentComment != "BillWave managed")) do={
                  /ppp secret set $id password=$password service=pppoe profile=$profile disabled=$disabled comment="BillWave managed"
                }
              }
              :local verify [/ppp secret find where name=$username]
              :if ([:len $verify] > 0) do={
                :set result {"ok"=true;"username"=$username;"profile"=$profile;"disabled"=$disabled}
                :set success true
              } else={ :set result {"ok"=false;"error"=("PPP secret was not created: " . $username)} }
            }
          }

          :local report {"job_id"=$jobId;"success"=$success;"result"=$result}
          :local reportJson [:serialize to=json value=$report options=json.no-string-conversion]
          :do {
            /tool fetch url=($api . "/api/connector/jobs") http-method=post http-header-field=("X-Connector-Token: " . $token . ",Content-Type: application/json") http-data=$reportJson output=none
          } on-error={ :log warning ("BillWave job report failed: " . $jobId) }
        }
      }
    }
  }
} do={ :log error ("BillWave connector error: " . $pollError) }
:set billwaveConnectorRunning false
`;

  res.setHeader('Content-Type', 'text/plain; charset=utf-8');
  res.setHeader('Cache-Control', 'no-store');
  return res.send(source);
}