export const access='public'; export const methods=['GET','POST'];
import { db } from 'hatchable';
async function hash(v){const b=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(v));return [...new Uint8Array(b)].map(x=>x.toString(16).padStart(2,'0')).join('')}
async function connector(req){const raw=((req.headers['x-connector-token']||req.headers['X-Connector-Token']||'')||((req.headers.authorization||'').replace(/^Bearer\s+/i,'')));if(!raw)return null;const h=await hash(raw);const q=await db.query('SELECT id,isp_id,router_id FROM router_connectors WHERE token_hash=$1',[h]);return q.rows[0]||null}
export default async function(req,res){
 const c=await connector(req); if(!c){res.setHeader('WWW-Authenticate','Bearer realm="BillWave Connector"');return res.status(401).json({error:'Invalid connector token'})}
 if(req.method==='GET'){
  // TEMPORARY NETWORK SAFETY LOCK: never hand a network-changing job to a
  // MikroTik connector while BillWave network control is paused.
  return res.json({job:null,network_control_disabled:true});
  for(let attempt=0;attempt<10;attempt++){
   const q=await db.query("WITH next_job AS (SELECT id FROM router_connector_jobs WHERE connector_id=$1 AND status='pending' ORDER BY created_at LIMIT 1 FOR UPDATE SKIP LOCKED) UPDATE router_connector_jobs j SET status='running' WHERE j.id=(SELECT id FROM next_job) AND j.connector_id=$1 AND j.status='pending' RETURNING j.*",[c.id]); const job=q.rows[0]; if(!job)return res.json({job:null});
   const payload=(job.payload&&typeof job.payload==='object')?job.payload:{}; const path=payload.path;
   if(path==='/ppp/secret/upsert'){
    const username=String(payload.username||'').trim(); const account=await db.query("SELECT id,status,service_locked,expires_at FROM pppoe_accounts WHERE isp_id=$1 AND router_id=$2 AND username=$3 LIMIT 1",[c.isp_id,c.router_id,username]);
    if(!account.rows[0]){await db.query("UPDATE router_connector_jobs SET status='completed',result=$1,completed_at=now() WHERE id=$2 AND connector_id=$3",[JSON.stringify({ok:true,skipped:true,reason:'PPPoE account no longer exists for this router',username}),job.id,c.id]);continue}
    const accountExpiresAt=account.rows[0].expires_at;
    const accountExpired=accountExpiresAt && new Date(accountExpiresAt)<=new Date();
    if(account.rows[0].status!=='active'||account.rows[0].service_locked===true||accountExpired){await db.query("UPDATE router_connector_jobs SET status='completed',result=$1,completed_at=now() WHERE id=$2 AND connector_id=$3",[JSON.stringify({ok:true,skipped:true,reason:'PPPoE account is currently disabled or service-locked',username,status:account.rows[0].status,service_locked:account.rows[0].service_locked}),job.id,c.id]);continue}
   }
   return res.json({job});
  } return res.json({job:null});
 }
 const b=(req.body&&typeof req.body==='object')?req.body:{}; const jobId=b.job_id||req.query?.job_id; const success=b.success!==undefined?b.success:req.query?.success; if(!jobId)return res.status(422).json({error:'job_id required'}); const result=b.result||{}; const reportedFailure=success===false||success==='false'||result?.ok===false; const finalStatus=reportedFailure?'failed':'completed'; await db.query("UPDATE router_connector_jobs SET status=$1,result=$2,completed_at=now() WHERE id=$3 AND connector_id=$4",[finalStatus,JSON.stringify(result),jobId,c.id]); res.json({ok:true,job_id:jobId,status:finalStatus});
}