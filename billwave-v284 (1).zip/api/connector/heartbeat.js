import { db } from 'hatchable';
import { billwaveSubscriptionAllowsNetwork, enforceSubscriptionNetworkLock } from 'lib/pppoe-service-lock.js';

export const access='public';
export const methods=['POST'];

async function hash(v){
  const b=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(v));
  return [...new Uint8Array(b)].map(x=>x.toString(16).padStart(2,'0')).join('');
}

export default async function(req,res){
  const raw=((req.headers['x-connector-token']||req.headers['X-Connector-Token']||'')||((req.headers.authorization||'').replace(/^Bearer\s+/i,'')));
  if(!raw){
    res.setHeader('WWW-Authenticate','Bearer realm="BillWave Connector"');
    return res.status(401).json({error:'Connector token required'});
  }

  const h=await hash(raw);

  // RouterOS sends JSON explicitly, but connector requests can arrive through
  // different HTTP parsers. Accept an already-parsed object as well as a JSON
  // string, and also accept metadata when the parser leaves that field as a
  // string. This prevents a valid heartbeat from being recorded as an empty
  // metadata object while still marking the connector online.
  let b=req.body||{};
  if(typeof b==='string'){
    try{ b=JSON.parse(b); }catch(_){ b={}; }
  }
  if(!b || typeof b!=='object' || Array.isArray(b)) b={};

  let metadata=b.metadata;
  if(typeof metadata==='string'){
    try{ metadata=JSON.parse(metadata); }catch(_){ metadata={}; }
  }
  if(!metadata || typeof metadata!=='object' || Array.isArray(metadata)) metadata={};

  // Normalize router system information so the dashboard can identify the
  // exact MikroTik board/model, RouterOS version and hardware details.
  const resource=metadata.resource&&typeof metadata.resource==='object'?metadata.resource:{};
  metadata.board=metadata.board||resource['board-name']||null;
  metadata.identity=metadata.identity||resource['board-name']||resource['platform']||null;
  metadata.version=metadata.version||resource.version||null;
  metadata.architecture=metadata.architecture||resource['architecture-name']||null;
  metadata.cpu_count=metadata.cpu_count??resource['cpu-count']??null;
  metadata.cpu_frequency=metadata.cpu_frequency||resource['cpu-frequency']||null;
  metadata.total_memory=metadata.total_memory||resource['total-memory']||null;
  metadata.free_memory=metadata.free_memory||resource['free-memory']||null;
  metadata.uptime=metadata.uptime||resource.uptime||null;
  metadata.cpu_load=metadata.cpu_load??Number(resource['cpu-load']||0);
  metadata.free_hdd_space=metadata.free_hdd_space||resource['free-hdd-space']||null;
  metadata.total_hdd_space=metadata.total_hdd_space||resource['total-hdd-space']||null;
  metadata.platform=metadata.platform||resource.platform||null;
  if(!Array.isArray(metadata.ppp_active)) metadata.ppp_active=[];
  const cleaned=metadata.ppp_active.map(x=>({name:x.name||'',service:x.service||'',address:x.address||'',uptime:x.uptime||'',caller_id:x['caller-id']||x.caller_id||'',session_id:x['session-id']||x.session_id||'',bytes_in:Number(x['bytes-in']??x.bytes_in??0)||0,bytes_out:Number(x['bytes-out']??x.bytes_out??0)||0})).filter(x=>x.name);
  metadata.ppp_active=cleaned;

  const q=await db.query(
    "UPDATE router_connectors SET status='online',last_seen_at=now(),metadata=$1 WHERE token_hash=$2 RETURNING id,isp_id,router_id",
    [JSON.stringify(metadata),h]
  );
  if(!q.rows[0]){
    res.setHeader('WWW-Authenticate','Bearer realm="BillWave Connector"');
    return res.status(401).json({error:'Invalid connector token'});
  }

  await db.query(
    "UPDATE mikrotik_routers SET status='online',last_connected_at=now(),last_error=NULL WHERE id=$1",
    [q.rows[0].router_id]
  );

  // Persist the last time each PPPoE username was actually observed in
  // MikroTik /ppp active. The username is the identity key; IP addresses
  // are deliberately not used to identify subscribers.
  const activeUsernames=[...new Set(cleaned.map(x=>String(x.name||'').trim()).filter(Boolean))];
  if(activeUsernames.length){
    await db.query(
      "UPDATE pppoe_accounts SET last_online_at=now(),updated_at=now() WHERE isp_id=$1 AND router_id=$2 AND username=ANY($3::text[])",
      [q.rows[0].isp_id,q.rows[0].router_id,activeUsernames]
    );
  }

  // Collect PPPoE traffic from MikroTik session counters. We store only the
  // delta since the previous heartbeat, so a 30-second poll does not double
  // count cumulative RouterOS byte counters. A new/reset session starts from
  // its current counter value, preserving usage across reconnects.
  for(const s of []){
    const username=String(s.name||'').trim();
    if(!username) continue;
    const accountQ=await db.query("SELECT id FROM pppoe_accounts WHERE isp_id=$1 AND router_id=$2 AND username=$3 LIMIT 1",[q.rows[0].isp_id,q.rows[0].router_id,username]);
    if(!accountQ.rows[0]) continue;
    const sessionKey=String(s.session_id||s.caller_id||username).trim();
    if(!sessionKey) continue;
    const currentIn=Math.max(0,Number(s.bytes_in)||0);
    const currentOut=Math.max(0,Number(s.bytes_out)||0);
    const prior=await db.query("SELECT last_download_bytes,last_upload_bytes FROM pppoe_usage_sessions WHERE router_id=$1 AND username=$2 AND session_key=$3 LIMIT 1",[q.rows[0].router_id,username,sessionKey]);
    let deltaIn=currentIn;
    let deltaOut=currentOut;
    if(prior.rows[0]){
      const oldIn=Math.max(0,Number(prior.rows[0].last_download_bytes)||0);
      const oldOut=Math.max(0,Number(prior.rows[0].last_upload_bytes)||0);
      deltaIn=currentIn>=oldIn?currentIn-oldIn:currentIn;
      deltaOut=currentOut>=oldOut?currentOut-oldOut:currentOut;
    }
    if(deltaIn>0 || deltaOut>0){
      await db.query("INSERT INTO pppoe_usage_daily(isp_id,pppoe_account_id,usage_date,download_bytes,upload_bytes) VALUES($1,$2,current_date,$3,$4) ON CONFLICT(pppoe_account_id,usage_date) DO UPDATE SET download_bytes=pppoe_usage_daily.download_bytes+EXCLUDED.download_bytes,upload_bytes=pppoe_usage_daily.upload_bytes+EXCLUDED.upload_bytes,updated_at=now()",[q.rows[0].isp_id,accountQ.rows[0].id,deltaIn,deltaOut]);
    }
    await db.query("INSERT INTO pppoe_usage_sessions(isp_id,router_id,pppoe_account_id,username,session_key,last_download_bytes,last_upload_bytes,last_seen_at,updated_at) VALUES($1,$2,$3,$4,$5,$6,$7,now(),now()) ON CONFLICT(router_id,username,session_key) DO UPDATE SET last_download_bytes=EXCLUDED.last_download_bytes,last_upload_bytes=EXCLUDED.last_upload_bytes,last_seen_at=now(),updated_at=now()",[q.rows[0].isp_id,q.rows[0].router_id,accountQ.rows[0].id,username,sessionKey,currentIn,currentOut]);
  }

  // Enforce PPPoE expiry on the router, not only in BillWave's database.
  // Accounts that have just crossed expiry are disabled and any current
  // session is explicitly disconnected. Renewal later re-enables the secret.
  // TEMPORARY NETWORK SAFETY LOCK: heartbeat remains online for monitoring,
  // but it must not turn billing expiry into a MikroTik network action.
  const expired={rows:[]};
  // Enforce expiry only when an account transitions into disabled state.
  // Do NOT re-queue every already-disabled expired account on every heartbeat:
  // the heartbeat runs every ~30 seconds, so that pattern floods the connector
  // queue and can delay unrelated customer operations. The hourly expiry worker
  // and this transition path already provide the required enforcement, while the
  // connector's PPP secret upsert guard prevents stale jobs from re-enabling an
  // expired account.
  for(const a of expired.rows){
    const username=String(a.username||'').trim();
    if(!username) continue;
    const jobs=[
      {path:'/ppp/secret/disable',method:'POST',username},
      {path:'/ppp/active/disconnect',method:'POST',username}
    ];
    for(const payload of jobs){
      await db.query(
        "INSERT INTO router_connector_jobs(connector_id,action,payload,status) VALUES($1,'mikrotik',$2,'pending')",
        [q.rows[0].id,JSON.stringify(payload)]
      );
    }
  }

  // BillWave subscription is a network-level entitlement for the ISP. When
  // the ISP's trial/subscription ends, every PPPoE account on this router is
  // locked and existing sessions are disconnected. When the ISP renews, only
  // accounts that were locked by this gate are restored; manually suspended or
  // expired customer accounts remain disabled.
  // TEMPORARY NETWORK SAFETY LOCK: keep heartbeat/monitoring alive, but do not
  // enforce ISP subscription state against live MikroTik sessions.
  const networkAllowed=true;
  const networkLock={allowed:true,disabled:true};

  // A provision code is only considered consumed after the router has
  // successfully checked in with its connector token.
  await db.query(
    "UPDATE router_provision_codes SET status='used',used_at=now() WHERE connector_token=$1 AND status='active'",
    [raw]
  );

  res.json({
    ok:true,
    connector_id:q.rows[0].id,
    active_pppoe_count:metadata.ppp_active.length,
    server_time:new Date().toISOString()
  });
}