import { db } from "hatchable";
import { workspaceFor, canManage } from "lib/tenant-context.js";
export const access='user';
export const methods=['GET','POST'];
export default async function(req,res){
  const w=await workspaceFor(req);
  if(!w)return res.status(403).json({error:'No ISP workspace assigned'});
  if(req.method==='GET'){
    const {rows}=await db.query("SELECT i.*, c.name AS customer_name, c.customer_number, p.name AS package_name FROM invoices i JOIN customers c ON c.id=i.customer_id AND c.isp_id=i.isp_id LEFT JOIN subscriptions s ON s.id=i.subscription_id LEFT JOIN packages p ON p.id=s.package_id WHERE i.isp_id=$1 ORDER BY i.created_at DESC",[w.isp_id]);
    return res.json({invoices:rows});
  }
  if(!canManage(w.role))return res.status(403).json({error:'Your role cannot create invoices'});
  const b=req.body||{};
  if(!b.customer_id||b.amount===undefined)return res.status(422).json({error:'customer_id and amount are required'});
  const amount=Number(b.amount);
  if(!Number.isFinite(amount)||amount<=0)return res.status(422).json({error:'Amount must be greater than zero'});
  const customer=await db.query("SELECT id FROM customers WHERE id=$1 AND isp_id=$2",[b.customer_id,w.isp_id]);
  if(!customer.rows.length)return res.status(404).json({error:'Customer not found'});
  let subscriptionId=b.subscription_id||null;
  if(subscriptionId){const s=await db.query("SELECT id FROM subscriptions WHERE id=$1 AND customer_id=$2 AND isp_id=$3",[subscriptionId,b.customer_id,w.isp_id]);if(!s.rows.length)return res.status(404).json({error:'Subscription not found'});}
  const invoiceNumber='BW-INV-'+Date.now().toString(36).toUpperCase();
  const {rows}=await db.query("INSERT INTO invoices (isp_id,customer_id,subscription_id,invoice_number,amount,balance,status,due_date) VALUES ($1,$2,$3,$4,$5,$5,'unpaid',$6) RETURNING *",[w.isp_id,b.customer_id,subscriptionId,invoiceNumber,amount,b.due_date||null]);
  return res.status(201).json({invoice:rows[0]});
}