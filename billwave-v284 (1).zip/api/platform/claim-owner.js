import { db } from 'hatchable';
export const access='admin';
export const methods=['POST'];
export default async function(req,res){const m=req.member;const existing=await db.query('SELECT 1 FROM billwave_platform_admins WHERE member_id=$1 LIMIT 1',[m.id]);if(existing.rows.length)return res.json({ok:true,member_id:m.id,already_owner:true});await db.query('INSERT INTO billwave_platform_admins(member_id) VALUES ($1)',[m.id]);res.json({ok:true,member_id:m.id,already_owner:false});}