import { db } from "hatchable";
export const access = "admin";
export const methods = ["POST"];
export default async function (req, res) {
  const { name, slug, email, phone, admin_email, timezone, currency } = req.body || {};
  if (!name || !slug || !admin_email) return res.status(422).json({ error: "name, slug and admin_email are required" });
  const cleanSlug = String(slug).trim().toLowerCase().replace(/[^a-z0-9-]/g, "-").replace(/-+/g, "-").replace(/^-|-$/g, "");
  const adminEmail = String(admin_email).trim().toLowerCase();
  const existing = await db.query("SELECT id FROM isps WHERE slug = $1", [cleanSlug]);
  if (existing.rows.length) return res.status(409).json({ error: "That ISP slug already exists" });
  const created = await db.query("INSERT INTO isps (name, slug, email, phone, admin_email) VALUES ($1, $2, $3, $4, $5) RETURNING id, name, slug, status", [String(name).trim(), cleanSlug, email || null, phone || null, adminEmail]);
  const isp = created.rows[0];
  await db.query("INSERT INTO isp_profiles (isp_id, timezone, currency) VALUES ($1, $2, $3)", [isp.id, timezone || "Africa/Nairobi", currency || "KES"]);
  await db.query("INSERT INTO invited_users (email) VALUES (lower($1)) ON CONFLICT DO NOTHING", [adminEmail]);
  res.status(201).json({ isp, admin_email: adminEmail, invitation_created: true, message: "ISP created. The administrator can now sign in with the invited email." });
}