import { db } from "hatchable";
export const access = "admin";
export const methods = ["POST"];
export default async function (req, res) {
  const { name, slug, email, phone } = req.body || {};
  if (!name || !slug) return res.status(422).json({ error: "name and slug are required" });
  const safeSlug = String(slug).trim().toLowerCase().replace(/[^a-z0-9-]/g, "-").replace(/-+/g, "-").replace(/^-|-$/g, "");
  if (!safeSlug) return res.status(422).json({ error: "A valid slug is required" });
  const { rows } = await db.query("INSERT INTO isps (name, slug, email, phone) VALUES ($1, $2, $3, $4) RETURNING id, name, slug, email, phone, status, created_at", [String(name).trim(), safeSlug, email || null, phone || null]);
  res.status(201).json({ isp: rows[0] });
}