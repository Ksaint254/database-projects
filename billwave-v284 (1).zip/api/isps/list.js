import { db } from "hatchable";
export const access = "admin";
export const methods = ["GET"];
export default async function (req, res) {
  const { rows } = await db.query("SELECT id, name, slug, email, phone, status, created_at FROM isps ORDER BY created_at DESC");
  res.json({ isps: rows });
}