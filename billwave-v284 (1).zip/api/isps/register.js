import { db } from "hatchable";

export const access = "user";
export const methods = ["POST"];

export default async function (req, res) {
  const member = req.user;
  const { name, slug, email, phone, timezone, currency, plan_id } = req.body || {};
  if (!member?.id) return res.status(401).json({ error: "Sign in required" });
  if (!name || !slug) return res.status(422).json({ error: "ISP name and slug are required" });

  const cleanSlug = String(slug).trim().toLowerCase().replace(/[^a-z0-9-]/g, "-").replace(/-+/g, "-").replace(/^-|-$/g, "");
  if (!cleanSlug) return res.status(422).json({ error: "Enter a valid ISP name" });

  const adminEmail = String(member.email || email || "").trim().toLowerCase();
  if (!adminEmail.includes("@")) return res.status(422).json({ error: "Your authenticated email could not be read" });

  const existingMember = await db.query("SELECT isp_id FROM isp_users WHERE auth_user_id = $1 AND status='active' LIMIT 1", [member.id]);
  if (existingMember.rows.length) {
    const currentIsp = await db.query("SELECT id, name, slug, status FROM isps WHERE id = $1 LIMIT 1", [existingMember.rows[0].isp_id]);
    return res.status(200).json({ ok: true, already_exists: true, isp: currentIsp.rows[0] || { id: existingMember.rows[0].isp_id }, destination: "/dashboard" });
  }

  const existing = await db.query("SELECT id FROM isps WHERE slug = $1", [cleanSlug]);
  if (existing.rows.length) return res.status(409).json({ error: "That ISP name is already in use" });

  let selectedPlan;
  if (plan_id) {
    const plan = await db.query("SELECT id, name, monthly_price FROM billwave_plans WHERE id = $1 AND status = 'active'", [plan_id]);
    if (!plan.rows.length) return res.status(422).json({ error: "Selected plan is not available" });
    selectedPlan = plan.rows[0];
  } else {
    const plan = await db.query("SELECT id, name, monthly_price FROM billwave_plans WHERE name = 'Starter' AND status = 'active' LIMIT 1");
    selectedPlan = plan.rows[0];
  }
  if (!selectedPlan) return res.status(503).json({ error: "BillWave plans are not available yet" });

  const settings = await db.query("SELECT key,value FROM billwave_settings WHERE key IN ('trial_enabled','trial_days')");
  const settingMap = Object.fromEntries(settings.rows.map(x => [x.key, x.value]));
  const trialEnabled = settingMap.trial_enabled !== 'false';
  const configuredDays = Number(settingMap.trial_days ?? 14);
  const trialDays = Number.isInteger(configuredDays) && configuredDays >= 0 && configuredDays <= 365 ? configuredDays : 14;
  const subscriptionStatus = trialEnabled && trialDays > 0 ? 'trial' : 'pending';

  const created = await db.query(
    "INSERT INTO isps (name, slug, email, phone, admin_email) VALUES ($1, $2, $3, $4, $5) RETURNING id, name, slug, status",
    [String(name).trim(), cleanSlug, adminEmail, phone || null, adminEmail]
  );
  const isp = created.rows[0];

  await db.query("INSERT INTO isp_users (isp_id, auth_user_id, role, status) VALUES ($1, $2, 'isp_admin', 'active')", [isp.id, member.id]);
  await db.query("INSERT INTO isp_profiles (isp_id, timezone, currency) VALUES ($1, $2, $3)", [isp.id, timezone || "Africa/Nairobi", currency || "KES"]);
  await db.query(
    "INSERT INTO isp_subscriptions (isp_id, plan_id, status, started_at, renews_at) VALUES ($1, $2, $3, now(), $4)",
    [isp.id, selectedPlan.id, subscriptionStatus, trialEnabled && trialDays > 0 ? new Date(Date.now() + trialDays * 86400000).toISOString() : null]
  );
  await db.query("INSERT INTO isp_onboarding (isp_id, owner_member_id, plan_id) VALUES ($1, $2, $3)", [isp.id, member.id, selectedPlan.id]);

  res.status(201).json({ ok: true, isp, plan: selectedPlan, trial_enabled: trialEnabled, trial_days: trialEnabled ? trialDays : 0, destination: "/dashboard" });
}