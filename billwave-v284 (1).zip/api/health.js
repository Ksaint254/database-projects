export const access = "public";
export const methods = ["GET"];

export default async function (req, res) {
  res.json({
    status: "ok",
    service: "BillWave",
    message: "BillWave project is online and ready for development."
  });
}