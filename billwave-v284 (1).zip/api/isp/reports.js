import { db } from "hatchable";
import { workspaceFor } from "lib/tenant-context.js";
export const access="user"; export const methods=["GET"];
export default async function(req,res){const w=await workspaceFor(req);if(!w)return res.status(401).json({error:'Login required'});const id=w.isp_id;
const [c,p,i,h,s]=await Promise.all([
 db.query("SELECT count(*)::int AS total,count(*) FILTER (WHERE status='active')::int AS active,count(*) FILTER (WHERE status<>'active')::int AS inactive FROM customers WHERE isp_id=$1",[id]),
 db.query("SELECT COALESCE(sum(amount),0) AS total, count(*)::int AS count FROM payments WHERE isp_id=$1 AND paid_at >= date_trunc('month',now())",[id]),
 db.query("SELECT count(*)::int AS total,COALESCE(sum(balance),0) AS outstanding FROM invoices WHERE isp_id=$1 AND status<>'paid'",[id]),
 db.query("SELECT count(*)::int AS sales,COALESCE(sum(amount),0) AS revenue,COALESCE(sum(duration_minutes-consumed_minutes),0)::int AS minutes_remaining FROM hotspot_customer_sales WHERE isp_id=$1 AND status='active'",[id]),
 db.query("SELECT count(*)::int AS accounts,count(*) FILTER(WHERE status='active')::int AS active FROM pppoe_accounts WHERE isp_id=$1",[id])
]);return res.json({customers:c.rows[0],payments:p.rows[0],invoices:i.rows[0],hotspot:h.rows[0],pppoe:s.rows[0]});}