import { db } from 'hatchable';
import { workspaceFor } from 'lib/tenant-context.js';

export const access='member';
export const methods=['GET','POST','PUT'];

export default async function(req,res){
  const w=await workspaceFor(req);
  if(!w)return res.status(403).json({error:'No ISP workspace assigned'});
  const ispId=w.isp_id;

  if(req.method==='GET'){
    const [sms,wa,campaigns,logs]=await Promise.all([
      db.query("SELECT enabled,provider_name,api_url,sender_id,(api_key IS NOT NULL AND api_key<>'') AS configured FROM isp_sms_settings WHERE isp_id=$1 LIMIT 1",[ispId]),
      db.query("SELECT enabled,provider_name,api_url,phone_number_id,business_account_id,(access_token IS NOT NULL AND access_token<>'') AS configured FROM isp_whatsapp_settings WHERE isp_id=$1 LIMIT 1",[ispId]),
      db.query("SELECT id,name,channel,audience,message,status,scheduled_at,sent_count,delivered_count,failed_count,created_at FROM isp_message_campaigns WHERE isp_id=$1 ORDER BY created_at DESC LIMIT 25",[ispId]),
      db.query("SELECT l.id,l.channel,l.recipient,l.status,l.provider_reference,l.error_message,l.created_at,c.name AS campaign_name,cu.name AS customer_name FROM isp_message_logs l LEFT JOIN isp_message_campaigns c ON c.id=l.campaign_id LEFT JOIN customers cu ON cu.id=l.customer_id WHERE l.isp_id=$1 ORDER BY l.created_at DESC LIMIT 30",[ispId])
    ]);
    return res.json({sms:sms.rows[0]||{enabled:false,configured:false},whatsapp:wa.rows[0]||{enabled:false,configured:false},campaigns:campaigns.rows,logs:logs.rows});
  }

  const b=req.body||{};
  if(req.method==='PUT'){
    const kind=String(b.kind||'').toLowerCase();
    if(kind==='sms'){
      await db.query("INSERT INTO isp_sms_settings(isp_id,enabled,provider_name,api_url,api_key,sender_id) VALUES($1,$2,$3,$4,$5,$6) ON CONFLICT(isp_id) DO UPDATE SET enabled=EXCLUDED.enabled,provider_name=EXCLUDED.provider_name,api_url=EXCLUDED.api_url,api_key=CASE WHEN EXCLUDED.api_key='' THEN isp_sms_settings.api_key ELSE EXCLUDED.api_key END,sender_id=EXCLUDED.sender_id,updated_at=now()",[ispId,Boolean(b.enabled),String(b.provider_name||'').trim()||null,String(b.api_url||'').trim()||null,String(b.api_key||''),String(b.sender_id||'').trim()||null]);
      return res.json({ok:true,kind:'sms'});
    }
    if(kind==='whatsapp'){
      await db.query("INSERT INTO isp_whatsapp_settings(isp_id,enabled,provider_name,api_url,access_token,phone_number_id,business_account_id) VALUES($1,$2,$3,$4,$5,$6,$7) ON CONFLICT(isp_id) DO UPDATE SET enabled=EXCLUDED.enabled,provider_name=EXCLUDED.provider_name,api_url=EXCLUDED.api_url,access_token=CASE WHEN EXCLUDED.access_token='' THEN isp_whatsapp_settings.access_token ELSE EXCLUDED.access_token END,phone_number_id=EXCLUDED.phone_number_id,business_account_id=EXCLUDED.business_account_id,updated_at=now()",[ispId,Boolean(b.enabled),String(b.provider_name||'').trim()||null,String(b.api_url||'').trim()||null,String(b.access_token||''),String(b.phone_number_id||'').trim()||null,String(b.business_account_id||'').trim()||null]);
      return res.json({ok:true,kind:'whatsapp'});
    }
    return res.status(422).json({error:'Unknown communication channel'});
  }

  if(req.method==='POST'){
    if(String(b.action||'').toLowerCase()==='send_direct'){
      const customerId=String(b.customer_id||'').trim();
      const channel=String(b.channel||'sms').toLowerCase();
      const rawMessage=String(b.message||'').trim();
      if(!customerId||!rawMessage)return res.status(422).json({error:'Customer and message are required'});
      if(!['sms','whatsapp'].includes(channel))return res.status(422).json({error:'Channel must be SMS or WhatsApp'});
      const cq=await db.query("SELECT c.id,c.name,c.phone,c.account_number,c.customer_number,p.username,p.expires_at,pk.name AS package_name FROM customers c LEFT JOIN LATERAL (SELECT username,expires_at,package_id FROM pppoe_accounts WHERE customer_id=c.id AND isp_id=$1 ORDER BY expires_at DESC NULLS LAST LIMIT 1) p ON true LEFT JOIN packages pk ON pk.id=p.package_id AND pk.isp_id=$1 WHERE c.id=$2 AND c.isp_id=$1 LIMIT 1",[ispId,customerId]);
      const customer=cq.rows[0];
      if(!customer)return res.status(404).json({error:'Customer not found'});
      if(!customer.phone)return res.status(422).json({error:'Customer has no phone number'});
      const msg=rawMessage.replace(/{{name}}/gi,customer.name||'Customer').replace(/{{phone}}/gi,customer.phone||'').replace(/{{expiry}}/gi,customer.expires_at?new Date(customer.expires_at).toLocaleDateString('en-KE'):'').replace(/{{account_number}}/gi,customer.account_number||customer.customer_number||'').replace(/{{username}}/gi,customer.username||'').replace(/{{package}}/gi,customer.package_name||'');
      const cfg=channel==='sms'
        ? (await db.query("SELECT enabled,provider_name,api_url,api_key,sender_id FROM isp_sms_settings WHERE isp_id=$1 LIMIT 1",[ispId])).rows[0]
        : (await db.query("SELECT enabled,provider_name,api_url,access_token,phone_number_id FROM isp_whatsapp_settings WHERE isp_id=$1 LIMIT 1",[ispId])).rows[0];
      if(!cfg?.enabled||!cfg?.api_url||(channel==='sms'?!cfg.api_key:!cfg.access_token)){
        await db.query("INSERT INTO isp_message_logs(isp_id,campaign_id,customer_id,channel,recipient,status,error_message) VALUES($1,NULL,$2,$3,$4,'failed',$5)",[ispId,customer.id,channel,customer.phone,`${channel==='sms'?'SMS':'WhatsApp'} provider is not configured or enabled`]);
        return res.status(422).json({error:`${channel==='sms'?'SMS':'WhatsApp'} provider is not configured or enabled`,status:'failed'});
      }
      let reference='';
      try{
        const headers={'content-type':'application/json'};
        let body;
        if(channel==='sms'){
          headers.authorization='Bearer '+cfg.api_key;
          body={to:customer.phone,message:msg,sender_id:cfg.sender_id||undefined,sender:cfg.sender_id||undefined};
        }else{
          headers.authorization='Bearer '+cfg.access_token;
          body=String(cfg.provider_name||'').toLowerCase().includes('cloud')
            ? {messaging_product:'whatsapp',to:customer.phone,type:'text',text:{preview_url:false,body:msg}}
            : {to:customer.phone,message:msg,text:msg,phone_number_id:cfg.phone_number_id||undefined};
        }
        const r=await fetch(cfg.api_url,{method:'POST',headers,body:JSON.stringify(body)});
        const text=await r.text();
        if(!r.ok)throw new Error(text.slice(0,500)||('HTTP '+r.status));
        reference=text.slice(0,500);
        await db.query("INSERT INTO isp_message_logs(isp_id,campaign_id,customer_id,channel,recipient,status,provider_reference,error_message) VALUES($1,NULL,$2,$3,$4,'sent',$5,NULL)",[ispId,customer.id,channel,customer.phone,reference||null]);
        return res.json({ok:true,status:'sent',channel,recipient:customer.phone,customer:customer.name,provider_reference:reference||null,message:msg});
      }catch(e){
        const error=String(e?.message||e).slice(0,500);
        await db.query("INSERT INTO isp_message_logs(isp_id,campaign_id,customer_id,channel,recipient,status,error_message) VALUES($1,NULL,$2,$3,$4,'failed',$5)",[ispId,customer.id,channel,customer.phone,error]);
        return res.status(502).json({ok:false,status:'failed',error:'Message provider rejected the request',detail:error});
      }
    }
    if(String(b.action||'').toLowerCase()==='send'){
      const campaignId=String(b.campaign_id||'').trim();
      if(!campaignId)return res.status(422).json({error:'Campaign is required'});
      const cq=await db.query("SELECT * FROM isp_message_campaigns WHERE id=$1 AND isp_id=$2 LIMIT 1",[campaignId,ispId]);
      const campaign=cq.rows[0];
      if(!campaign)return res.status(404).json({error:'Campaign not found'});
      if(campaign.status==='sent')return res.status(409).json({error:'Campaign has already been sent'});
      const cfg=campaign.channel==='sms'
        ? (await db.query("SELECT enabled,provider_name,api_url,api_key,sender_id FROM isp_sms_settings WHERE isp_id=$1 LIMIT 1",[ispId])).rows[0]
        : (await db.query("SELECT enabled,provider_name,api_url,access_token,phone_number_id FROM isp_whatsapp_settings WHERE isp_id=$1 LIMIT 1",[ispId])).rows[0];
      if(!cfg?.enabled||!cfg?.api_url||(campaign.channel==='sms'?!cfg.api_key:!cfg.access_token))return res.status(422).json({error:`${campaign.channel==='sms'?'SMS':'WhatsApp'} provider is not configured or enabled`});
      let audienceSql="c.isp_id=$1 AND c.phone IS NOT NULL AND trim(c.phone)<>''";
      const params=[ispId];
      if(campaign.audience==='all_active') audienceSql+=" AND EXISTS (SELECT 1 FROM pppoe_accounts p WHERE p.customer_id=c.id AND p.isp_id=$1 AND p.status='active')";
      if(campaign.audience==='expiring') audienceSql+=" AND EXISTS (SELECT 1 FROM pppoe_accounts p WHERE p.customer_id=c.id AND p.isp_id=$1 AND p.status='active' AND p.expires_at>now() AND p.expires_at<=now()+interval '7 days')";
      if(campaign.audience==='expired') audienceSql+=" AND EXISTS (SELECT 1 FROM pppoe_accounts p WHERE p.customer_id=c.id AND p.isp_id=$1 AND p.status='disabled' AND p.expires_at IS NOT NULL AND p.expires_at<=now())";
      if(campaign.audience==='pppoe') audienceSql+=" AND EXISTS (SELECT 1 FROM pppoe_accounts p WHERE p.customer_id=c.id AND p.isp_id=$1)";
      if(campaign.audience==='hotspot') audienceSql+=" AND EXISTS (SELECT 1 FROM hotspot_customer_sales s WHERE s.customer_id=c.id AND s.isp_id=$1)";
      const customers=(await db.query(`SELECT c.id,c.name,c.phone,p.expires_at FROM customers c LEFT JOIN LATERAL (SELECT expires_at FROM pppoe_accounts p WHERE p.customer_id=c.id AND p.isp_id=$1 ORDER BY expires_at DESC NULLS LAST LIMIT 1) p ON true WHERE ${audienceSql} ORDER BY c.name LIMIT 500`,params)).rows;
      let sent=0,failed=0;
      for(const c of customers){
        const msg=String(campaign.message).replace(/{{name}}/gi,c.name||'Customer').replace(/{{phone}}/gi,c.phone||'').replace(/{{expiry}}/gi,c.expires_at?new Date(c.expires_at).toLocaleDateString('en-KE'):'').replace(/{{account_number}}/gi,c.phone||'');
        let status='sent',reference='',error='';
        try{
          const headers={'content-type':'application/json'};
          let body;
          if(campaign.channel==='sms'){
            headers.authorization='Bearer '+cfg.api_key;
            body={to:c.phone,message:msg,sender_id:cfg.sender_id||undefined,sender:cfg.sender_id||undefined};
          }else{
            headers.authorization='Bearer '+cfg.access_token;
            body=String(cfg.provider_name||'').toLowerCase().includes('cloud')
              ? {messaging_product:'whatsapp',to:c.phone,type:'text',text:{preview_url:false,body:msg}}
              : {to:c.phone,message:msg,text:msg,phone_number_id:cfg.phone_number_id||undefined};
          }
          const r=await fetch(cfg.api_url,{method:'POST',headers,body:JSON.stringify(body)}); const text=await r.text();
          if(!r.ok)throw new Error(text.slice(0,500)||('HTTP '+r.status)); reference=text.slice(0,500);
        }catch(e){status='failed';failed++;error=String(e?.message||e).slice(0,500)}
        if(status==='sent')sent++;
        await db.query("INSERT INTO isp_message_logs(isp_id,campaign_id,customer_id,channel,recipient,status,provider_reference,error_message) VALUES($1,$2,$3,$4,$5,$6,$7,$8)",[ispId,campaign.id,c.id,campaign.channel,c.phone,status,reference||null,error||null]);
      }
      const finalStatus=customers.length===0?'failed':failed===0?'sent':sent===0?'failed':'partial';
      await db.query("UPDATE isp_message_campaigns SET status=$1,sent_count=$2,failed_count=$3,updated_at=now() WHERE id=$4 AND isp_id=$5",[finalStatus,sent,failed,campaign.id,ispId]);
      return res.json({ok:failed===0&&customers.length>0,status:finalStatus,total:customers.length,sent,failed});
    }
    const name=String(b.name||'').trim();
    const channel=String(b.channel||'sms').toLowerCase();
    const audience=String(b.audience||'all_active').toLowerCase();
    const message=String(b.message||'').trim();
    if(name.length<2||!message)return res.status(422).json({error:'Campaign name and message are required'});
    if(!['sms','whatsapp'].includes(channel))return res.status(422).json({error:'Channel must be SMS or WhatsApp'});
    if(!['all_active','expiring','expired','pppoe','hotspot'].includes(audience))return res.status(422).json({error:'Invalid audience'});
    const q=await db.query("INSERT INTO isp_message_campaigns(isp_id,name,channel,audience,message,status,scheduled_at) VALUES($1,$2,$3,$4,$5,'draft',$6) RETURNING id,name,channel,audience,message,status,scheduled_at,created_at",[ispId,name,channel,audience,message,b.scheduled_at||null]);
    return res.status(201).json({campaign:q.rows[0]});
  }

  return res.status(405).json({error:'Method not supported'});
}