import { db } from 'hatchable';
import { workspaceFor } from 'lib/tenant-context.js';
export const access='member';
export const methods=['GET','PUT','POST'];
export default async function(req,res){
  const w=await workspaceFor(req); if(!w)return res.status(403).json({error:'No ISP workspace assigned'});
  const ispId=w.isp_id;
  if(req.method==='GET'){
    const r=await db.query("SELECT enabled,provider_name,api_url,sender_id,CASE WHEN api_key IS NULL OR api_key='' THEN false ELSE true END AS has_api_key FROM isp_sms_settings WHERE isp_id=$1",[ispId]);
    return res.json(r.rows[0]||{enabled:false,provider_name:'',api_url:'',sender_id:'',has_api_key:false});
  }
  const b=req.body||{};
  if(req.method==='PUT'){
    await db.query("INSERT INTO isp_sms_settings(isp_id,enabled,provider_name,api_url,api_key,sender_id) VALUES($1,$2,$3,$4,$5,$6) ON CONFLICT(isp_id) DO UPDATE SET enabled=EXCLUDED.enabled,provider_name=EXCLUDED.provider_name,api_url=EXCLUDED.api_url,api_key=CASE WHEN EXCLUDED.api_key='' THEN isp_sms_settings.api_key ELSE EXCLUDED.api_key END,sender_id=EXCLUDED.sender_id,updated_at=now()",[ispId,Boolean(b.enabled),b.provider_name||null,b.api_url||null,b.api_key||'',b.sender_id||null]);
    return res.json({ok:true});
  }
  return res.status(501).json({error:'Use PUT to save SMS settings'});
}