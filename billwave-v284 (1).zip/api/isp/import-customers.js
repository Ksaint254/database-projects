import { db } from 'hatchable';
import { workspaceFor, canManage } from 'lib/tenant-context.js';
import { provisionPppoe } from 'lib/mikrotik-provision.js';
import { provisionHotspot } from 'lib/mikrotik-hotspot.js';
export const access='user'; export const methods=['POST'];

function norm(v){return String(v??'').trim()}
function key(v){return norm(v).toLowerCase().replace(/[^a-z0-9]+/g,'_').replace(/^_|_$/g,'')}
function parseCsv(text){
  const rows=[]; let row=[], cell='', quoted=false;
  for(let i=0;i<text.length;i++){const c=text[i],n=text[i+1];
    if(quoted){if(c==='"'&&n==='"'){cell+='"';i++;}else if(c==='"')quoted=false;else cell+=c;}
    else if(c==='"')quoted=true; else if(c===','){row.push(cell);cell='';}
    else if(c==='\n'){row.push(cell.replace(/\r$/,''));rows.push(row);row=[];cell='';} else cell+=c;
  }
  if(cell!==''||row.length){row.push(cell.replace(/\r$/,''));rows.push(row)} return rows;
}
function parseDate(v){const s=norm(v);if(!s)return null;const d=new Date(s);return Number.isNaN(d.getTime())?null:d.toISOString()}
function cleanSpeed(v){return norm(v).toUpperCase().replace(/\s+/g,'').replace('MBPS','M').replace('MB/S','M')}
function isConnection(v){return /^(pppoe?|ppp|hotspot)$/i.test(norm(v))}
function isPhone(v){return /^\d{9,15}$/.test(norm(v).replace(/[ +()-]/g,''))}
function isDate(v){return Boolean(parseDate(v))}
function isSpeed(v){return /^\d+(?:\.\d+)?\s*(?:MBPS|MB\/S|M|GBPS|GB)$/i.test(norm(v))}
function isStatus(v){return /^(active|inactive|disabled|suspended|expired|blocked|pending)$/i.test(norm(v))}
function isUrl(v){return /^https?:\/\//i.test(norm(v))}
function normalizeRow(headers,r){
  // Start with the header-position mapping, then repair rows from the old
  // export where Account # / Email are blank and later columns shift left.
  const o={}; headers.forEach((h,i)=>o[key(h)]=norm(r[i]));
  const vals=r.map(norm); const ci=vals.findIndex(isConnection);
  if(ci>=0){
    o.username=norm(vals[0]); o.password=norm(vals[1]);
    // The export frequently omits Account #, so the connection token lands
    // in that column. Everything after the connection is interpreted by type.
    const before=vals.slice(2,ci).filter(Boolean);
    const after=vals.slice(ci+1);
    o.connection=vals[ci];
    if(!o.first_name && before[0])o.first_name=before[0];
    if(!o.last_name && before[1])o.last_name=before[1];
    if(!o.email){const em=before.find(v=>v.includes('@'));if(em)o.email=em;}
    const phones=before.filter(isPhone);
    if(!o.phone&&phones[0])o.phone=phones[0];
    // Preserve a genuine account number when one is present; otherwise use
    // username as the stable customer account number.
    const explicitAccount=before.find(v=>isPhone(v)===false && !v.includes('@') && !isSpeed(v));
    if(!o.account_number && explicitAccount && !isStatus(explicitAccount))o.account_number=explicitAccount;
    if(!o.status){const st=after.find(isStatus);if(st)o.status=st;}
    if(!o.package){const sp=after.find(isSpeed);if(sp)o.package=sp;}
    if(!o.expiry){const dates=after.filter(isDate);if(dates.length)o.expiry=dates[dates.length-1];}
    if(!o.nas){const ns=after.find(v=>v&&!isDate(v)&&!isStatus(v)&&!isSpeed(v));if(ns)o.nas=ns;}
    if(!o.email){const em=after.find(v=>v.includes('@'));if(em)o.email=em;}
    // Some rows have phone in the position immediately before the connection.
    if(!o.phone){const ph=vals.slice(0,ci).reverse().find(isPhone);if(ph)o.phone=ph;}
  }
  return o;
}
function detectType(o){const s=(o.connection_type||o.connection||o.connectiontype||'').toLowerCase();if(s.includes('hotspot'))return'hotspot';if(s.includes('ppp'))return'pppoe';return null}
function nameOf(o){const full=[o.first_name,o.lastname||o.last_name].filter(Boolean).join(' ').trim();return full||o.username||'Imported Customer'}
function phoneOf(o){return o.phone||o.mobile||''}
function accountOf(o){return o.account_number||o.account||o.account_no||o.account_||o.customer_number||o.username||''}
function expiryOf(o){return parseDate(o.expiry||o.expires||o.expiry_date)}

async function findPackage(isp,o){
  const speed=cleanSpeed(o.package||o.speed); let p=null;
  if(o.package)p=await db.query("SELECT id,name,speed FROM packages WHERE isp_id=$1 AND lower(name)=lower($2) LIMIT 1",[isp,o.package]);
  if((!p||!p.rows.length)&&speed)p=await db.query("SELECT id,name,speed FROM packages WHERE isp_id=$1 AND regexp_replace(upper(speed),'\\s+','','g')=$2 LIMIT 1",[isp,speed]);
  return p?.rows[0]||null;
}
async function findRouter(isp,o){
  const wanted=norm(o.nas||o.router||o.nas_router);
  if(wanted){const q=await db.query("SELECT id,name FROM mikrotik_routers WHERE isp_id=$1 AND lower(name)=lower($2) AND enabled=true ORDER BY CASE WHEN status='online' THEN 0 ELSE 1 END LIMIT 1",[isp,wanted]);if(q.rows[0])return q.rows[0];}
  const q=await db.query("SELECT id,name FROM mikrotik_routers WHERE isp_id=$1 AND enabled=true AND status='online' ORDER BY CASE WHEN lower(name)='kalungusu' THEN 0 ELSE 1 END,created_at DESC LIMIT 1",[isp]);
  return q.rows[0]||null;
}

export default async function(req,res){
 const w=await workspaceFor(req);if(!w)return res.status(403).json({error:'No ISP workspace assigned'});if(!canManage(w.role))return res.status(403).json({error:'Not permitted'});
 const file=req.files?.find(f=>f.field==='file')||req.files?.[0];if(!file)return res.status(422).json({error:'Upload a CSV file'});
 const text=new TextDecoder('utf-8').decode(file.buffer).replace(/^\uFEFF/,'');const rows=parseCsv(text);if(rows.length<2)return res.status(422).json({error:'CSV contains no data rows'});
 const expected=['username','password','first_name','phone','connection_type','status','package','last_online','expiry'];const rawHeaders=rows[0].map(v=>norm(v).replace(/^\uFEFF/,''));const headers=rawHeaders.map(key);const headerSet=new Set(headers);const headerOk=headers.length===expected.length&&expected.every(h=>headerSet.has(h));if(!headerOk)return res.status(422).json({error:'Invalid CSV format. Your CSV must contain exactly these 9 columns: Username, Password, First name, Phone, Connection type, Status, Package, Last online, Expiry.',detected_columns:rawHeaders});const data=rows.slice(1).filter(r=>r.some(x=>norm(x))).map(r=>normalizeRow(headers,r));
 const mode=norm(req.body?.mode||'preview').toLowerCase();
 const preview=[];
 for(let i=0;i<data.length;i++){const o=data[i],type=detectType(o),speed=cleanSpeed(o.package||o.speed),pkg=type==='pppoe'?await findPackage(w.isp_id,o):null,router=type==='pppoe'?await findRouter(w.isp_id,o):null;preview.push({row:i+2,username:o.username||'',name:nameOf(o),phone:phoneOf(o),email:o.email||'',account_number:accountOf(o),type,package:o.package||'',speed,router:o.nas||o.router||o.nas_router||router?.name||'',status:o.status||'active',expiry:expiryOf(o),password_present:Boolean(o.password),package_match:Boolean(pkg),router_match:Boolean(router),valid:Boolean(type&&o.username&&accountOf(o))});}
 if(mode!=='import')return res.json({preview,columns:headers,total:data.length,warning:'Review the preview before importing. The importer repairs shifted Account/Email columns from the legacy export and matches packages/routers by speed/name.'});
 let created=0,updated=0,services=0,skipped=0;const errors=[];
 for(let i=0;i<data.length;i++){
  const o=data[i],type=detectType(o),username=norm(o.username),account=accountOf(o),expiry=expiryOf(o);if(!type||!username||!account){skipped++;errors.push({row:i+2,error:'Missing username, account number, or supported connection type'});continue;}
  try{
   const existing=await db.query("SELECT id FROM customers WHERE isp_id=$1 AND customer_number=$2",[w.isp_id,account]);let customerId;
   if(existing.rows[0]){customerId=existing.rows[0].id;await db.query("UPDATE customers SET name=$1,phone=$2,email=$3,status=$4,updated_at=now() WHERE id=$5 AND isp_id=$6",[nameOf(o),phoneOf(o)||null,o.email||null,(o.status||'active').toLowerCase(),customerId,w.isp_id]);updated++;}
   else{const c=await db.query("INSERT INTO customers(isp_id,customer_number,name,phone,email,status) VALUES($1,$2,$3,$4,$5,$6) RETURNING id",[w.isp_id,account,nameOf(o),phoneOf(o)||null,o.email||null,(o.status||'active').toLowerCase()]);customerId=c.rows[0].id;created++;}
   if(type==='pppoe'){
    const pkg=await findPackage(w.isp_id,o);const router=await findRouter(w.isp_id,o);const exists=await db.query("SELECT id FROM pppoe_accounts WHERE isp_id=$1 AND username=$2",[w.isp_id,username]);
    if(exists.rows[0]){await db.query("UPDATE pppoe_accounts SET customer_id=$1,package_id=$2,router_id=COALESCE($3,router_id),profile=$4,status=$5,expires_at=$6,updated_at=now() WHERE id=$7",[customerId,pkg?.id||null,router?.id||null,o.package||pkg?.name||null,(o.status||'active').toLowerCase(),expiry,exists.rows[0].id]);services++;}
    else if(pkg&&router){const a=await db.query("INSERT INTO pppoe_accounts(isp_id,customer_id,router_id,package_id,username,password,profile,status,expires_at) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING id",[w.isp_id,customerId,router.id,pkg.id,username,o.password||'',o.package||pkg.name,(o.status||'active').toLowerCase(),expiry]);await provisionPppoe(w.isp_id,a.rows[0],router.id,pkg.speed||null);services++;}
    else {skipped++;errors.push({row:i+2,error:`PPPoE customer imported but service needs package/router assignment (package: ${o.package||'not supplied'}, router: ${o.nas||'auto-not-found'})`});}
   }else{
    let hp=null;if(o.package)hp=await db.query("SELECT id,name,duration_minutes,price FROM hotspot_profiles WHERE isp_id=$1 AND lower(name)=lower($2) LIMIT 1",[w.isp_id,o.package]);
    if(hp?.rows.length){const x=hp.rows[0];const already=await db.query("SELECT id FROM hotspot_customer_sales WHERE isp_id=$1 AND customer_id=$2 AND reference=$3 LIMIT 1",[w.isp_id,customerId,username]);if(!already.rows.length){await db.query("INSERT INTO hotspot_customer_sales(isp_id,customer_id,profile_id,amount,purchased_at,duration_minutes,consumed_minutes,status,reference) VALUES($1,$2,$3,$4,now(),$5,0,$6,$7)",[w.isp_id,customerId,x.id,x.price,x.duration_minutes,(o.status||'active').toLowerCase(),username]);}services++;if(o.password)await provisionHotspot(w.isp_id,{username,password:o.password,profile:x.name,comment:`Imported BillWave ${x.name}`});}
    else {skipped++;errors.push({row:i+2,error:`Hotspot customer imported but package '${o.package||'not supplied'}' was not found; assign a hotspot profile to finish the service`});}
   }
  }catch(e){skipped++;errors.push({row:i+2,error:String(e?.message||e).slice(0,300)});}
 }
 return res.json({success:true,summary:{rows:data.length,customers_created:created,customers_updated:updated,services_created:services,skipped,errors:errors.length},errors});
}