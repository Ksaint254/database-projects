import { db } from "hatchable";
import { workspaceFor, canManage } from "lib/tenant-context.js";
export const access = "user";
export const methods = ["GET","POST","PUT","DELETE"];
export default async function(req,res){
  const w=await workspaceFor(req); if(!w)return res.status(401).json({error:"Login required"});
  if(!canManage(w.role))return res.status(403).json({error:"Access denied"});
  if(req.method==='GET'){const q=await db.query("SELECT id,name,email,phone,role,status,created_at FROM isp_staff WHERE isp_id=$1 ORDER BY created_at DESC",[w.isp_id]);return res.json({staff:q.rows});}
  const b=req.body||{};
  if(req.method==='POST'){if(!b.name||!b.email)return res.status(400).json({error:"Name and email are required"});const q=await db.query("INSERT INTO isp_staff (isp_id,name,email,phone,role,status) VALUES ($1,$2,$3,$4,$5,'active') ON CONFLICT (email,isp_id) DO UPDATE SET name=EXCLUDED.name,phone=EXCLUDED.phone,role=EXCLUDED.role,status='active' RETURNING id,name,email,phone,role,status",[w.isp_id,b.name,b.email,b.phone||null,b.role||'customer_care']);return res.status(201).json({staff:q.rows[0]});}
  if(req.method==='PUT'){if(!b.id)return res.status(400).json({error:"Staff id is required"});const q=await db.query("UPDATE isp_staff SET name=COALESCE($2,name),phone=COALESCE($3,phone),role=COALESCE($4,role),status=COALESCE($5,status),updated_at=now() WHERE id=$1 AND isp_id=$6 RETURNING id,name,email,phone,role,status",[b.id,b.name,b.phone,b.role,b.status,w.isp_id]);return res.json({staff:q.rows[0]||null});}
  if(req.method==='DELETE'){if(!b.id)return res.status(400).json({error:"Staff id is required"});await db.query("UPDATE isp_staff SET status='disabled',updated_at=now() WHERE id=$1 AND isp_id=$2",[b.id,w.isp_id]);return res.json({ok:true});}
}