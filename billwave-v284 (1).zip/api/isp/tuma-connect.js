import { db } from "hatchable";
import { workspaceFor, canManage } from "../../lib/tenant-context.js";

export const access = "member";
export const methods = ["GET", "POST"];

const TUMA = "https://api.tuma.co.ke";
function clean(v){ return String(v ?? "").trim(); }
function normalizeMobile(v){ const x=clean(v).replace(/\D/g,""); return x.startsWith("0") ? "254"+x.slice(1) : x.startsWith("254") ? x : x; }

async function tumaToken(){
  const email=clean(process.env.TUMA_EMAIL), apiKey=clean(process.env.TUMA_API_KEY);
  if(!email||!apiKey) throw new Error("BillWave Tuma platform credentials are not configured");
  const r=await fetch(`${TUMA}/auth/token`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({email,api_key:apiKey})});
  const d=await r.json().catch(()=>({}));
  if(!r.ok||!d?.success||!d?.data?.token) throw new Error(d?.message||"Tuma authentication failed");
  return d.data.token;
}

export default async function(req,res){
  const workspace=await workspaceFor(req);
  if(!workspace) return res.status(403).json({error:"ISP workspace not found"});
  if(!canManage(workspace.role)) return res.status(403).json({error:"You do not have permission to manage payment gateways"});

  if(req.method==="GET"){
    const r=await fetch(`${TUMA}/reference/banks`);
    const d=await r.json().catch(()=>({}));
    if(!r.ok||!d?.success) return res.status(502).json({error:d?.message||"Unable to retrieve Tuma banks"});
    const s=await db.query("SELECT tuma_business_id,bank_id,bank_name,account_number,business_name,mobile,enabled,provisioning_status,last_error,created_at,updated_at FROM isp_tuma_settings WHERE isp_id=$1 LIMIT 1",[workspace.isp_id]);
    return res.json({banks:d.data||[],connection:s.rows[0]||null});
  }

  const b=req.body||{};
  const bankId=clean(b.bank_id), accountNumber=clean(b.account_number), mobile=normalizeMobile(b.mobile||workspace.phone), name=clean(b.name||workspace.name), email=clean(b.email||workspace.email), logo=clean(b.logo)||"https://billwave.hatchable.site/logo.png", description=clean(b.description||`${name} ISP powered by BillWave`);
  if(name.length<2||!email||!mobile||!bankId||accountNumber.length<5) return res.status(422).json({error:"Business name, email, mobile, bank and account number are required"});
  if(!/^254\d{9}$/.test(mobile)) return res.status(422).json({error:"Mobile number must be in 254XXXXXXXXX format"});

  const existing=await db.query("SELECT * FROM isp_tuma_settings WHERE isp_id=$1 LIMIT 1",[workspace.isp_id]);
  if(existing.rows[0]?.tuma_business_id) return res.status(409).json({error:"Tuma is already connected for this ISP",connection:existing.rows[0]});

  try{
    const token=await tumaToken();
    const r=await fetch(`${TUMA}/businesses`,{method:"POST",headers:{Authorization:`Bearer ${token}`,"Content-Type":"application/json"},body:JSON.stringify({name,email,mobile,bank_id:bankId,account_number:accountNumber,logo,description})});
    const d=await r.json().catch(()=>({}));
    if(!r.ok||!d?.success||!d?.data?.id||!d?.data?.api_key){
      await db.query("INSERT INTO isp_tuma_settings (isp_id,email,api_key,enabled,business_name,mobile,bank_id,account_number,provisioning_status,last_error) VALUES ($1,$2,'pending',$3,$4,$5,$6,$7,'failed',$8) ON CONFLICT (isp_id) DO UPDATE SET email=EXCLUDED.email,business_name=EXCLUDED.business_name,mobile=EXCLUDED.mobile,bank_id=EXCLUDED.bank_id,account_number=EXCLUDED.account_number,provisioning_status='failed',last_error=EXCLUDED.last_error,updated_at=now()",[workspace.isp_id,email,false,name,mobile,bankId,accountNumber,d?.message||"Tuma child business creation failed"]);
      return res.status(502).json({error:d?.message||"Tuma could not create the ISP business",details:d?.errors||null});
    }
    const x=d.data;
    const saved=await db.query("INSERT INTO isp_tuma_settings (isp_id,email,api_key,enabled,tuma_business_id,business_name,mobile,bank_id,bank_name,account_number,provisioning_status,last_error) VALUES ($1,$2,$3,true,$4,$5,$6,$7,$8,$9,'connected',NULL) ON CONFLICT (isp_id) DO UPDATE SET email=EXCLUDED.email,api_key=EXCLUDED.api_key,enabled=true,tuma_business_id=EXCLUDED.tuma_business_id,business_name=EXCLUDED.business_name,mobile=EXCLUDED.mobile,bank_id=EXCLUDED.bank_id,bank_name=EXCLUDED.bank_name,account_number=EXCLUDED.account_number,provisioning_status='connected',last_error=NULL,updated_at=now() RETURNING id,email,tuma_business_id,business_name,mobile,bank_id,bank_name,account_number,enabled,provisioning_status,created_at,updated_at",[workspace.isp_id,email,x.api_key,x.id,x.name,x.mobile,x.bank_id,x.bank_name,accountNumber]);
    return res.json({ok:true,connection:saved.rows[0]});
  }catch(e){
    return res.status(502).json({error:e.message||"Tuma connection failed"});
  }
}