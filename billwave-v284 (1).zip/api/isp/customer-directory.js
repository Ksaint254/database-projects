import { db } from 'hatchable';
import { workspaceFor } from 'lib/tenant-context.js';
export const access='user'; export const methods=['GET'];
function baseUrl(r){return `${r.ssl?'https':'http'}://${r.host}:${r.port||443}/rest`;}
function auth(r){return 'Basic '+btoa(`${r.username||''}:${r.password||''}`);}
export default async function(req,res){
 const w=await workspaceFor(req); if(!w)return res.status(403).json({error:'No ISP workspace assigned'});
 const q=await db.query("SELECT c.id,c.name,c.phone,c.email,c.status,c.package_id,c.account_number,c.customer_number,c.created_at,pkc.name AS customer_package_name,pkc.speed AS customer_package_speed,p.username,p.password,p.expires_at AS expiry,p.last_online_at,COALESCE(pkp.name,pkc.name,sub.package_name) AS package_name,COALESCE(pkp.speed,pkc.speed) AS package_speed,CASE WHEN p.username IS NOT NULL THEN 'PPPOE' WHEN hs.customer_id IS NOT NULL THEN 'HOTSPOT' ELSE '' END AS connection_type FROM customers c LEFT JOIN packages pkc ON pkc.id=c.package_id AND pkc.isp_id=c.isp_id LEFT JOIN LATERAL (SELECT username,password,expires_at,profile,package_id,last_online_at FROM pppoe_accounts WHERE isp_id=c.isp_id AND customer_id=c.id ORDER BY created_at DESC LIMIT 1) p ON true LEFT JOIN packages pkp ON pkp.id=p.package_id AND pkp.isp_id=c.isp_id LEFT JOIN LATERAL (SELECT customer_id FROM hotspot_customer_sales WHERE isp_id=c.isp_id AND customer_id=c.id ORDER BY created_at DESC LIMIT 1) hs ON true LEFT JOIN LATERAL (SELECT pk.name AS package_name FROM subscriptions s JOIN packages pk ON pk.id=s.package_id WHERE s.isp_id=c.isp_id AND s.customer_id=c.id ORDER BY s.created_at DESC LIMIT 1) sub ON true WHERE c.isp_id=$1 ORDER BY c.name",[w.isp_id]);
 const routers=await db.query("SELECT r.id,r.name,r.host,r.port,r.username,r.password,r.ssl,r.enabled,c.status connector_status,c.last_seen_at,c.metadata FROM mikrotik_routers r LEFT JOIN LATERAL (SELECT status,last_seen_at,metadata FROM router_connectors WHERE router_id=r.id ORDER BY last_seen_at DESC NULLS LAST LIMIT 1) c ON true WHERE r.isp_id=$1 AND r.enabled=true",[w.isp_id]);
 const now=Date.now();
 const sessionByUsername=new Map();
 for(const r of routers.rows){
   const fresh=r.last_seen_at&&now-new Date(r.last_seen_at).getTime()<90000;
   if(!fresh)continue;
   const active=Array.isArray(r.metadata?.ppp_active)?r.metadata.ppp_active:[];
   for(const a of active){
     const username=String(a.name||'').trim();
     if(username)sessionByUsername.set(username,{router:r.name,address:a.address||null,uptime:a.uptime||null,caller_id:a['caller-id']||a.caller_id||null,bytes_in:Number(a['bytes-in']||a.bytes_in||0),bytes_out:Number(a['bytes-out']||a.bytes_out||0)});
   }
 }
 const customers=q.rows.map(c=>{
   const expired=!!c.expiry&&new Date(c.expiry).getTime()<now;
   const account_status=expired?'expired':(c.status||'active');
   const s=c.username&&!expired?sessionByUsername.get(String(c.username).trim()):null;
   return {...c,status:account_status,expired,connection_status:expired?'expired':(c.username?(s?'online':'offline'):'offline'),last_online:c.last_online_at||null,active_router:s?.router||null,address:s?.address||null,uptime:s?.uptime||null,caller_id:s?.caller_id||null,bytes_in:s?.bytes_in||0,bytes_out:s?.bytes_out||0};
 });
 res.json({customers});
}