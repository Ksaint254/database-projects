import { db } from 'hatchable';
import { workspaceFor, canManage } from 'lib/tenant-context.js';
export const access='member'; export const methods=['POST'];

async function hash(v){const b=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(v));return [...new Uint8Array(b)].map(x=>x.toString(16).padStart(2,'0')).join('')}

async function waitForJob(jobId, timeoutMs=15000){
  const started=Date.now();
  while(Date.now()-started<timeoutMs){
    const q=await db.query('SELECT status,result FROM router_connector_jobs WHERE id=$1 LIMIT 1',[jobId]);
    const j=q.rows[0];
    if(j && (j.status==='completed'||j.status==='failed')) return j;
    await new Promise(r=>setTimeout(r,1000));
  }
  return {status:'timeout',result:{error:'Router connector did not complete the request in time'}};
}

async function enqueue(connectorId,action,payload){
  const q=await db.query('INSERT INTO router_connector_jobs(connector_id,action,payload,status) VALUES($1,$2,$3,\'pending\') RETURNING id',[connectorId,action,JSON.stringify(payload)]);
  return q.rows[0].id;
}

export default async function(req,res){
  const w=await workspaceFor(req); if(!w)return res.status(403).json({error:'No ISP workspace assigned'});
  if(!canManage(w.role))return res.status(403).json({error:'Not permitted'});
  const {router_id}=req.body||{}; if(!router_id)return res.status(422).json({error:'router_id is required'});
  const rr=await db.query('SELECT id,name,status FROM mikrotik_routers WHERE id=$1 AND isp_id=$2 LIMIT 1',[router_id,w.isp_id]);
  const router=rr.rows[0]; if(!router)return res.status(404).json({error:'Router not found'});

  const cq=await db.query('SELECT id,status,last_seen_at FROM router_connectors WHERE router_id=$1 AND isp_id=$2 ORDER BY last_seen_at DESC NULLS LAST LIMIT 1',[router_id,w.isp_id]);
  const connector=cq.rows[0];
  if(!connector)return res.status(409).json({error:'No BillWave router connector is registered for this router'});
  if(connector.status!=='online')return res.status(409).json({error:'Router connector is not online. Make sure the BillWave connector is running on the ISP network and try again.'});

  try{
    const secretJob=await enqueue(connector.id,'mikrotik',{path:'/ppp/secret',method:'GET'});
    const profileJob=await enqueue(connector.id,'mikrotik',{path:'/ppp/profile',method:'GET'});
    const [secretResult,profileResult]=await Promise.all([waitForJob(secretJob),waitForJob(profileJob)]);
    if(secretResult.status!=='completed')return res.status(502).json({error:'Could not read PPP secrets through the BillWave router connector',details:secretResult.result});
    const secrets=Array.isArray(secretResult.result)?secretResult.result:[];
    const profiles=profileResult.status==='completed'&&Array.isArray(profileResult.result)?profileResult.result:[];
    const profileMap=new Map(profiles.map(x=>[x.name,x]));
    let imported=0,skipped=0; const preview=[];
    for(const u of secrets){
      const username=String(u.name||'').trim(); if(!username)continue;
      const profile=String(u.profile||'default'); const p=profileMap.get(profile)||{};
      const speed=String(p['rate-limit']||'').trim()||null;
      const timeout=String(p['session-timeout']||'');
      const durationMatch=timeout.match(/(?:(\d+)w)?(?:(\d+)d)?(?:(\d+)h)?(?:(\d+)m)?/);
      let duration=null;
      if(durationMatch && durationMatch[0]) duration=(Number(durationMatch[1]||0)*7)+(Number(durationMatch[2]||0));
      const existing=await db.query('SELECT id FROM pppoe_accounts WHERE isp_id=$1 AND username=$2 LIMIT 1',[w.isp_id,username]);
      if(existing.rows[0]){skipped++;preview.push({username,profile,speed,status:'already_exists'});continue;}
      const password=String(u.password||'');
      if(!password){skipped++;preview.push({username,profile,speed,status:'needs_password'});continue;}
      let packageId=null;
      if(speed){const pq=await db.query('SELECT id FROM packages WHERE isp_id=$1 AND speed=$2 ORDER BY created_at DESC LIMIT 1',[w.isp_id,speed]);packageId=pq.rows[0]?.id||null;}
      const customer=await db.query('SELECT id FROM customers WHERE isp_id=$1 AND (customer_number=$2 OR name=$2) ORDER BY id LIMIT 1',[w.isp_id,username]);
      const customerId=customer.rows[0]?.id||null;
      await db.query("INSERT INTO pppoe_accounts(isp_id,customer_id,username,password,profile,status,expires_at,router_id,package_id) VALUES($1,$2,$3,$4,$5,'active',CASE WHEN $6::int IS NULL THEN NULL ELSE now()+($6::text||' days')::interval END,$7,$8)",[w.isp_id,customerId,username,password,profile,duration,router_id,packageId]);
      if(customerId&&packageId)await db.query("UPDATE customers SET package_id=$1,pppoe_username=$2,status='active',updated_at=now() WHERE id=$3 AND isp_id=$4",[packageId,username,customerId,w.isp_id]);
      imported++;preview.push({username,profile,speed,status:'imported',customer_linked:!!customerId,expiry_source:duration?'profile session-timeout':'not available'});
    }
    return res.json({success:true,router:router.name,found:secrets.length,imported,skipped,users:preview,note:'Import was performed through the BillWave router connector. SopraEnt/RADIUS expiry dates are not available from PPP secrets; expiry is derived only from a local profile session-timeout.'});
  }catch(e){return res.status(502).json({error:`Could not import PPPoE users: ${e.message}`});}
}