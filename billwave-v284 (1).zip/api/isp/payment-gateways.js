import { db } from "hatchable";
import { workspaceFor, canManage } from "../../lib/tenant-context.js";

export const access = "member";
export const methods = ["GET", "PUT"];

function clean(v) { return String(v ?? "").trim(); }

export default async function(req, res) {
  const workspace = await workspaceFor(req);
  if (!workspace) return res.status(403).json({ error: "ISP workspace not found" });
  if (!canManage(workspace.role)) return res.status(403).json({ error: "You do not have permission to manage payment gateways" });

  if (req.method === "GET") {
    const mp = await db.query("SELECT id, provider, environment, short_code, account_reference, callback_url, enabled, created_at, updated_at, (consumer_key IS NOT NULL AND consumer_secret IS NOT NULL AND passkey IS NOT NULL) AS credentials_configured FROM isp_mpesa_settings WHERE isp_id=$1 LIMIT 1", [workspace.isp_id]);
    const bank = await db.query("SELECT id, bank_name, account_name, account_number, branch, swift_code, instructions, enabled, created_at, updated_at FROM isp_bank_settings WHERE isp_id=$1 LIMIT 1", [workspace.isp_id]);
    const tuma = await db.query("SELECT id, email, enabled, created_at, updated_at, (api_key IS NOT NULL) AS credentials_configured FROM isp_tuma_settings WHERE isp_id=$1 LIMIT 1", [workspace.isp_id]);
    return res.json({
      isp_id: workspace.isp_id,
      gateways: {
        mpesa: mp.rows[0] || null,
        tuma: tuma.rows[0] || null,
        bank: bank.rows[0] || null
      },
      supported: [
        { key: "mpesa", name: "M-Pesa STK Push", automatic: true, description: "Customers pay directly to the ISP's configured M-Pesa shortcode." },
        { key: "tuma", name: "Tuma", automatic: true, description: "BillWave creates a separate Tuma child business for this ISP." },
        { key: "bank", name: "Bank Transfer", automatic: false, description: "Show the ISP's bank details and verify transfers manually." }
      ]
    });
  }

  const b = req.body || {};
  const gateway = clean(b.gateway).toLowerCase();
  if (!["mpesa", "tuma", "bank"].includes(gateway)) return res.status(422).json({ error: "Unsupported payment gateway" });

  if (gateway === "tuma") return res.status(400).json({ error: "Use the Tuma Connect flow. BillWave creates the ISP's Tuma child business automatically." });

  if (gateway === "mpesa") {
    const environment = b.environment === "production" ? "production" : "sandbox";
    const enabled = Boolean(b.enabled);
    const shortCode = clean(b.short_code) || null;
    const accountReference = clean(b.account_reference) || null;
    const callbackUrl = clean(b.callback_url) || null;
    const existing = await db.query("SELECT consumer_key, consumer_secret, passkey FROM isp_mpesa_settings WHERE isp_id=$1 LIMIT 1", [workspace.isp_id]);
    const old = existing.rows[0] || {};
    const consumerKey = clean(b.consumer_key) || old.consumer_key || null;
    const consumerSecret = clean(b.consumer_secret) || old.consumer_secret || null;
    const passkey = clean(b.passkey) || old.passkey || null;
    const row = await db.query("INSERT INTO isp_mpesa_settings (isp_id, provider, environment, short_code, account_reference, consumer_key, consumer_secret, passkey, callback_url, enabled) VALUES ($1,'mpesa',$2,$3,$4,$5,$6,$7,$8,$9) ON CONFLICT (isp_id) DO UPDATE SET environment=EXCLUDED.environment, short_code=EXCLUDED.short_code, account_reference=EXCLUDED.account_reference, consumer_key=EXCLUDED.consumer_key, consumer_secret=EXCLUDED.consumer_secret, passkey=EXCLUDED.passkey, callback_url=EXCLUDED.callback_url, enabled=EXCLUDED.enabled, updated_at=now() RETURNING id, provider, environment, short_code, account_reference, callback_url, enabled, updated_at, (consumer_key IS NOT NULL AND consumer_secret IS NOT NULL AND passkey IS NOT NULL) AS credentials_configured", [workspace.isp_id, environment, shortCode, accountReference, consumerKey, consumerSecret, passkey, callbackUrl, enabled]);
    return res.json({ ok: true, gateway: "mpesa", settings: row.rows[0] });
  }

  const bankName = clean(b.bank_name);
  const accountName = clean(b.account_name);
  const accountNumber = clean(b.account_number);
  if (!bankName || !accountName || !accountNumber) return res.status(422).json({ error: "Bank name, account name and account number are required" });
  const row = await db.query("INSERT INTO isp_bank_settings (isp_id, bank_name, account_name, account_number, branch, swift_code, instructions, enabled) VALUES ($1,$2,$3,$4,$5,$6,$7,$8) ON CONFLICT (isp_id) DO UPDATE SET bank_name=EXCLUDED.bank_name, account_name=EXCLUDED.account_name, account_number=EXCLUDED.account_number, branch=EXCLUDED.branch, swift_code=EXCLUDED.swift_code, instructions=EXCLUDED.instructions, enabled=EXCLUDED.enabled, updated_at=now() RETURNING id, bank_name, account_name, account_number, branch, swift_code, instructions, enabled, updated_at", [workspace.isp_id, bankName, accountName, accountNumber, clean(b.branch) || null, clean(b.swift_code) || null, clean(b.instructions) || null, Boolean(b.enabled)]);
  return res.json({ ok: true, gateway: "bank", settings: row.rows[0] });
}