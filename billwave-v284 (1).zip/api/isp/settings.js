import { db } from 'hatchable';
import { workspaceFor } from 'lib/tenant-context.js';

// ISP accounts are BillWave end users, so resolve them through app auth.
export const access='public';
export const methods=['GET','PUT'];

export default async function(req,res){
  const w=await workspaceFor(req); if(!w)return res.status(401).json({error:'Login required'});
  const ispId=w.isp_id;
  if(req.method==='GET'){
    const [i,p,b]=await Promise.all([
      db.query("SELECT name,email,phone,admin_email FROM isps WHERE id=$1",[ispId]),
      db.query("SELECT timezone,currency FROM isp_profiles WHERE isp_id=$1",[ispId]),
      db.query("SELECT logo_url,primary_color,dark_mode FROM isp_branding WHERE isp_id=$1",[ispId])
    ]);
    return res.json({...i.rows[0],...(p.rows[0]||{timezone:'Africa/Nairobi',currency:'KES'}),branding:b.rows[0]||{logo_url:'',primary_color:'#f59e0b',dark_mode:true}});
  }
  const b=req.body||{};
  const name=String(b.name||'').trim(); if(!name)return res.status(422).json({error:'Company name is required'});
  const updated=await db.query("UPDATE isps SET name=$2,email=$3,phone=$4,updated_at=now() WHERE id=$1 RETURNING id,name,email,phone,admin_email",[ispId,name,b.email?String(b.email).trim():null,b.phone?String(b.phone).trim():null]);
  if(!updated.rowCount)return res.status(404).json({error:'ISP workspace not found'});
  await db.query("INSERT INTO isp_profiles(isp_id,timezone,currency) VALUES($1,$2,$3) ON CONFLICT(isp_id) DO UPDATE SET timezone=EXCLUDED.timezone,currency=EXCLUDED.currency,updated_at=now()",[ispId,b.timezone||'Africa/Nairobi',b.currency||'KES']);
  await db.query("INSERT INTO isp_branding(isp_id,logo_url,primary_color,dark_mode) VALUES($1,$2,$3,$4) ON CONFLICT(isp_id) DO UPDATE SET logo_url=EXCLUDED.logo_url,primary_color=EXCLUDED.primary_color,dark_mode=EXCLUDED.dark_mode,updated_at=now()",[ispId,b.logo_url||null,b.primary_color||'#f59e0b',b.dark_mode!==false]);
  return res.json({ok:true,isp:updated.rows[0]});
}