import { db, email } from 'hatchable';
import { workspaceFor } from 'lib/tenant-context.js';
export const access='member';
export const methods=['GET','POST','PUT'];
export default async function(req,res){
  const w=await workspaceFor(req); if(!w)return res.status(403).json({error:'No ISP workspace assigned'});
  const ispId=w.isp_id;
  if(req.method==='GET'){
    const [n,p]=await Promise.all([
      db.query("SELECT id,type,severity,title,message,read_at,created_at FROM isp_notifications WHERE isp_id=$1 ORDER BY created_at DESC LIMIT 50",[ispId]),
      db.query("SELECT * FROM isp_notification_preferences WHERE isp_id=$1 LIMIT 1",[ispId])
    ]);
    return res.json({notifications:n.rows,unread:n.rows.filter(x=>!x.read_at).length,preferences:p.rows[0]||null});
  }
  const b=req.body||{};
  if(req.method==='PUT'){
    if(b.action==='read' && b.id){await db.query("UPDATE isp_notifications SET read_at=COALESCE(read_at,now()) WHERE id=$1 AND isp_id=$2",[b.id,ispId]);return res.json({ok:true});}
    if(b.action==='read_all'){await db.query("UPDATE isp_notifications SET read_at=COALESCE(read_at,now()) WHERE isp_id=$1 AND read_at IS NULL",[ispId]);return res.json({ok:true});}
    const fields=['mikrotik_errors','payment_events','pppoe_events','subscription_events','system_errors','security_events','customer_expiry_sms','customer_payment_sms','customer_renewal_sms'];
    const vals=fields.map(k=>b[k]===undefined?true:Boolean(b[k]));
    await db.query("INSERT INTO isp_notification_preferences(isp_id,mikrotik_errors,payment_events,pppoe_events,subscription_events,system_errors,security_events,customer_expiry_sms,customer_payment_sms,customer_renewal_sms) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) ON CONFLICT(isp_id) DO UPDATE SET mikrotik_errors=EXCLUDED.mikrotik_errors,payment_events=EXCLUDED.payment_events,pppoe_events=EXCLUDED.pppoe_events,subscription_events=EXCLUDED.subscription_events,system_errors=EXCLUDED.system_errors,security_events=EXCLUDED.security_events,customer_expiry_sms=EXCLUDED.customer_expiry_sms,customer_payment_sms=EXCLUDED.customer_payment_sms,customer_renewal_sms=EXCLUDED.customer_renewal_sms,updated_at=now()",[ispId,...vals]);
    return res.json({ok:true});
  }
  if(!b.message||!b.title)return res.status(422).json({error:'Title and message are required'});
  const r=await db.query("INSERT INTO isp_notifications(isp_id,type,severity,title,message,entity_type,entity_id) VALUES($1,$2,$3,$4,$5,$6,$7) RETURNING *",[ispId,String(b.type||'system'),String(b.severity||'info'),String(b.title),String(b.message),b.entity_type||null,b.entity_id||null]);
  return res.json({ok:true,notification:r.rows[0]});
}