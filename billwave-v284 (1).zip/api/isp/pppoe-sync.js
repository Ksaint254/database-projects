import { db } from 'hatchable';
import { workspaceFor, canManage } from 'lib/tenant-context.js';

export const access='user';
export const methods=['POST'];

export default async function(req,res){
  const w=await workspaceFor(req);
  if(!w)return res.status(403).json({error:'No ISP workspace assigned'});
  if(!canManage(w.role))return res.status(403).json({error:'Not permitted'});

  const id=req.body?.id;
  if(!id)return res.status(422).json({error:'PPPoE account id is required'});

  const q=await db.query("SELECT a.id,a.username,a.password,a.profile,a.status,a.expires_at,a.router_id,a.package_id,p.speed FROM pppoe_accounts a LEFT JOIN packages p ON p.id=a.package_id WHERE a.id=$1 AND a.isp_id=$2 LIMIT 1",[id,w.isp_id]);
  if(!q.rows[0])return res.status(404).json({error:'PPPoE account not found'});
  const a=q.rows[0];

  const c=await db.query("SELECT id,last_seen_at FROM router_connectors WHERE isp_id=$1 AND router_id=$2 ORDER BY last_seen_at DESC NULLS LAST LIMIT 1",[w.isp_id,a.router_id]);
  if(!c.rows[0])return res.status(409).json({error:'No connector is registered for this MikroTik'});

  const profile=String(a.profile||'').trim();
  if(!profile || profile.toLowerCase()==='default') return res.status(422).json({error:'A BillWave PPPoE account must have a non-default PPP profile'});
  const rate=a.speed?String(a.speed).replace(/\s*mbps/i,'M')+'/'+String(a.speed).replace(/\s*mbps/i,'M'):null;
  if(!rate) return res.status(422).json({error:'Package speed is required before syncing PPPoE account'});
  const jobs=[];
  const accountExpired=!!a.expires_at && new Date(a.expires_at)<=new Date();
  const blocked=a.status!=='active' || accountExpired;

  // Customer synchronization must NEVER rewrite a shared PPP profile.
  // A profile is shared by many subscribers, so changing it here can flap
  // every live customer using that profile. Profile creation/change belongs to
  // explicit package/profile provisioning, not an individual account sync.
  if(blocked){
    await db.query("DELETE FROM router_connector_jobs WHERE connector_id=$1 AND status='pending' AND payload->>'username'=$2 AND payload->>'path' IN ('/ppp/secret/upsert','/ppp/profile/upsert')",[c.rows[0].id,String(a.username)]);
    const d=await db.query("INSERT INTO router_connector_jobs(connector_id,action,payload,status) VALUES($1,'mikrotik',$2,'pending') RETURNING id",[c.rows[0].id,JSON.stringify({path:'/ppp/secret/disable',method:'POST',username:String(a.username)})]);
    jobs.push(d.rows[0].id);
    const x=await db.query("INSERT INTO router_connector_jobs(connector_id,action,payload,status) VALUES($1,'mikrotik',$2,'pending') RETURNING id",[c.rows[0].id,JSON.stringify({path:'/ppp/active/disconnect',method:'POST',username:String(a.username)})]);
    jobs.push(x.rows[0].id);
  }else{
    const allowEnable=true;
    const s=await db.query("INSERT INTO router_connector_jobs(connector_id,action,payload,status) VALUES($1,'mikrotik',$2,'pending') RETURNING id",[c.rows[0].id,JSON.stringify({path:'/ppp/secret/upsert',method:'POST',username:String(a.username),password:String(a.password),profile,disabled:false,rate_limit:rate,expires_at:a.expires_at,status:'active',allow_enable:allowEnable})]);
    jobs.push(s.rows[0].id);
  }

  return res.json({success:true,queued:true,job_ids:jobs,username:a.username,router_id:a.router_id});
}