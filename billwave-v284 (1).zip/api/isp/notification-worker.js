import { db } from 'hatchable';
export const access='scheduler';
export const methods=['POST'];
export const schedule='0 * * * *';

async function notify(ispId,type,severity,title,message,entityType=null,entityId=null){
  await db.query("INSERT INTO isp_notifications(isp_id,type,severity,title,message,entity_type,entity_id) SELECT $1,$2,$3,$4,$5,$6,$7 WHERE NOT EXISTS (SELECT 1 FROM isp_notifications WHERE isp_id=$1 AND type=$2 AND created_at>=now()-interval '6 hours')",[ispId,type,severity,title,message,entityType,entityId]);
}
async function sendSms(ispId,customerId,type,to,message){
  const s=await db.query("SELECT enabled,provider_name,api_url,api_key,sender_id FROM isp_sms_settings WHERE isp_id=$1 LIMIT 1",[ispId]);
  const cfg=s.rows[0]; if(!cfg?.enabled||!cfg.api_url||!cfg.api_key||!to)return {status:'skipped'};
  const exists=await db.query("SELECT id FROM isp_sms_logs WHERE isp_id=$1 AND customer_id=$2 AND notification_type=$3 AND created_at::date=current_date LIMIT 1",[ispId,customerId,type]);
  if(exists.rows.length)return {status:'duplicate'};
  const log=await db.query("INSERT INTO isp_sms_logs(isp_id,customer_id,notification_type,recipient,message,status,provider) VALUES($1,$2,$3,$4,$5,'queued',$6) RETURNING id",[ispId,customerId,type,to,message,cfg.provider_name||'HTTP SMS']);
  try{
    const r=await fetch(cfg.api_url,{method:'POST',headers:{'content-type':'application/json','authorization':'Bearer '+cfg.api_key},body:JSON.stringify({to,message,sender_id:cfg.sender_id||undefined,sender:cfg.sender_id||undefined})});
    const text=await r.text();
    if(!r.ok)throw new Error(text.slice(0,500)||('HTTP '+r.status));
    await db.query("UPDATE isp_sms_logs SET status='sent',sent_at=now(),provider_reference=$1 WHERE id=$2",[text.slice(0,500),log.rows[0].id]);
    return {status:'sent'};
  }catch(e){await db.query("UPDATE isp_sms_logs SET status='failed',error_message=$1 WHERE id=$2",[String(e?.message||e).slice(0,500),log.rows[0].id]);return {status:'failed'};}
}
export default async function(req,res){
  const isps=await db.query("SELECT i.id,i.name FROM isps i WHERE i.status='active'");
  let smsSent=0,alerts=0;
  for(const isp of isps.rows){
    const pref=(await db.query("SELECT * FROM isp_notification_preferences WHERE isp_id=$1",[isp.id])).rows[0]||{};
    const routers=await db.query("SELECT id,name,last_connected_at,last_error FROM mikrotik_routers WHERE isp_id=$1 AND enabled=true AND (status='offline' OR (last_connected_at IS NOT NULL AND last_connected_at<now()-interval '3 minutes'))",[isp.id]);
    if(pref.mikrotik_errors!==false)for(const r of routers.rows){await notify(isp.id,'mikrotik_offline_'+r.id,'error','MikroTik offline',`${r.name} is offline or has not checked in recently.${r.last_error?' '+r.last_error:''}`,'mikrotik_router',r.id);alerts++;}
    const recentPayments=await db.query("SELECT p.id,p.customer_id,p.amount,p.method,p.reference,c.name,c.phone FROM payments p JOIN customers c ON c.id=p.customer_id WHERE p.isp_id=$1 AND p.paid_at>=now()-interval '2 hours'",[isp.id]);
    for(const p of recentPayments.rows){
      if(pref.payment_events!==false)await notify(isp.id,'payment_'+p.id,'success','Payment received',`${p.name||'Customer'} paid KSh ${Number(p.amount||0).toLocaleString()} via ${p.method||'payment'}.`,'payment',p.id);
      if(pref.customer_payment_sms!==false&&p.phone){const r=await sendSms(isp.id,p.customer_id,'payment_'+p.id,p.phone,`Payment received. Thank you ${p.name||'Customer'}; KSh ${Number(p.amount||0).toLocaleString()} has been received by your ISP.`);if(r.status==='sent')smsSent++;}
    }
    const due=await db.query("SELECT p.id,p.customer_id,p.username,p.expires_at,c.name,c.phone,pk.name package_name FROM pppoe_accounts p LEFT JOIN customers c ON c.id=p.customer_id LEFT JOIN packages pk ON pk.id=p.package_id WHERE p.isp_id=$1 AND p.status='active' AND p.expires_at IS NOT NULL AND p.expires_at>now() AND p.expires_at<=now()+interval '7 days'",[isp.id]);
    for(const a of due.rows){const days=Math.max(0,Math.ceil((new Date(a.expires_at)-Date.now())/86400000));const type='expiry_'+days;const msg=days===0?`Hello ${a.name||'Customer'}, your internet subscription expires today. Please renew to avoid interruption.`:`Hello ${a.name||'Customer'}, your ${a.package_name||'internet'} subscription expires in ${days} day${days===1?'':'s'} (${new Date(a.expires_at).toLocaleDateString('en-KE')}). Please renew.`;if(pref.customer_expiry_sms!==false&&a.phone){const r=await sendSms(isp.id,a.customer_id,type,a.phone,msg);if(r.status==='sent')smsSent++;}if(pref.subscription_events!==false)await notify(isp.id,type,'warning','Customer subscription expiring',`${a.name||a.username} expires in ${days} day${days===1?'':'s'}.`,'pppoe_account',a.id);}
  }
  res.json({ok:true,alerts,sms_sent:smsSent});
}