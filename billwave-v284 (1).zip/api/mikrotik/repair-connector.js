import { db, auth, admin } from 'hatchable';

export const access = 'public';
export const methods = ['POST'];

function esc(v) {
  return String(v ?? '').replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/\$/g, '\\$').replace(/\r?\n/g, ' ');
}

export default async function (req, res) {
  const routerId = String(req.body?.router_id || '').trim();
  if (!routerId) return res.status(400).json({ error: 'router_id is required' });

  const routerQ = await db.query(
    `SELECT r.id,r.name,r.isp_id FROM mikrotik_routers r
     JOIN isps i ON i.id=r.isp_id
     WHERE r.id=$1 LIMIT 1`, [routerId]
  );
  if (!routerQ.rows[0]) return res.status(404).json({ error: 'Router not found' });
  const router = routerQ.rows[0];

  let appUser = null;
  try { appUser = await auth.getUser(req); } catch (_) { appUser = null; }
  let authorized = false;
  if (appUser?.id) {
    const ownerQ = await db.query(
      `SELECT 1 FROM isp_users WHERE isp_id=$1 AND auth_user_id=$2 AND status='active' LIMIT 1`,
      [router.isp_id, appUser.id]
    );
    authorized = !!ownerQ.rows[0];
  }
  if (!authorized) {
    try { authorized = !!admin.check(req); } catch (_) { authorized = false; }
  }
  if (!authorized) return res.status(403).json({ error: 'Not authorized for this router' });

  const codeQ = await db.query(
    `SELECT connector_token FROM router_provision_codes
     WHERE router_id=$1 AND isp_id=$2 AND connector_token IS NOT NULL
     ORDER BY CASE WHEN status='active' THEN 0 ELSE 1 END, created_at DESC LIMIT 1`,
    [router.id, router.isp_id]
  );
  const token = codeQ.rows[0]?.connector_token;
  if (!token) return res.status(409).json({ error: 'No connector credential is available for this router. Generate a fresh provisioning script first.' });

  const sourceResp = await fetch('https://billwave.hatchable.site/api/connector/script', {
    headers: { 'X-Connector-Token': token }
  });
  if (!sourceResp.ok) return res.status(502).json({ error: 'Could not retrieve the current BillWave connector source' });
  const connectorSource = await sourceResp.text();
  const quote = s => JSON.stringify(s).replaceAll('$', '\\$');
  const command = `/system script remove [find where name="billwave-connector"]; /system scheduler remove [find where name="billwave-connector"]; /system script add name="billwave-connector" policy=read,write,test source=${quote(connectorSource)}; /system scheduler add name="billwave-connector" interval=5s on-event="/system script run billwave-connector" start-time=startup policy=read,write,test; /system script run billwave-connector`;

  res.json({
    router: router.name,
    command,
    note: 'This only replaces the BillWave connector script and scheduler. It does not reset networking, PPP profiles, or PPPoE accounts.'
  });
}