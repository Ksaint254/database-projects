import { db, auth, admin } from 'hatchable';

export const access = 'public';
export const methods = ['POST'];

function esc(v) {
  return String(v ?? '').replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/\$/g, '\\$').replace(/\r?\n/g, ' ');
}

export default async function (req, res) {
  const routerId = String(req.body?.router_id || '').trim();
  if (!routerId) return res.status(400).json({ error: 'router_id is required' });

  const routerQ = await db.query(
    `SELECT r.id,r.name,r.isp_id FROM mikrotik_routers r
     JOIN isps i ON i.id=r.isp_id
     WHERE r.id=$1 LIMIT 1`, [routerId]
  );
  if (!routerQ.rows[0]) return res.status(404).json({ error: 'Router not found' });

  const router = routerQ.rows[0];

  // BillWave ISP users are app users, not Hatchable collaborators. Since this
  // endpoint is public at the platform edge, resolve the signed-in app user
  // explicitly and authorize against isp_users.auth_user_id.
  let appUser = null;
  try {
    appUser = await auth.getUser(req);
  } catch (_) {
    appUser = null;
  }

  let authorized = false;
  if (appUser?.id) {
    const ownerQ = await db.query(
      `SELECT 1 FROM isp_users WHERE isp_id=$1 AND auth_user_id=$2 AND status='active' LIMIT 1`,
      [router.isp_id, appUser.id]
    );
    authorized = !!ownerQ.rows[0];
  }

  // Preserve the project-owner/admin path as a fallback.
  if (!authorized) {
    try {
      authorized = !!admin.check(req);
    } catch (_) {
      authorized = false;
    }
  }

  if (!authorized) return res.status(403).json({ error: 'Not authorized for this router' });

  const codeQ = await db.query(
    `SELECT connector_token FROM router_provision_codes
     WHERE router_id=$1 AND isp_id=$2 AND connector_token IS NOT NULL
     ORDER BY CASE WHEN status='active' THEN 0 ELSE 1 END, created_at DESC LIMIT 1`,
    [router.id, router.isp_id]
  );
  const token = codeQ.rows[0]?.connector_token;
  if (!token) return res.status(409).json({ error: 'No connector credential is available for this router. Generate a fresh provisioning script first.' });

  const api = 'https://billwave.hatchable.site';
  const heartbeatSource = `
:local api "${api}"
:local token "${esc(token)}"
:local n [/system identity get name]
:local u [/system resource get uptime]
:local v [/system resource get version]
:local b [/system resource get board-name]
:local a [/system resource get architecture-name]
:local cc [/system resource get cpu-count]
:local cf [/system resource get cpu-frequency]
:local cm [/system resource get total-memory]
:local fm [/system resource get free-memory]
:local cl [/system resource get cpu-load]
:local fh [/system resource get free-hdd-space]
:local th [/system resource get total-hdd-space]
:local p [/system resource get platform]
:local activeSessions [:toarray ""]
:foreach sessionId in=[/ppp active find] do={
  :local sname [/ppp active get $sessionId name]
  :local sservice [/ppp active get $sessionId service]
  :local saddress [/ppp active get $sessionId address]
  :local suptime [/ppp active get $sessionId uptime]
  :local scaller [/ppp active get $sessionId caller-id]
  :set activeSessions ($activeSessions, {"name"=$sname;"service"=$sservice;"address"=$saddress;"uptime"=$suptime;"caller-id"=$scaller})
}
:local metadata {"identity"=$n;"uptime"=$u;"version"=$v;"board"=$b;"architecture"=$a;"cpu_count"=$cc;"cpu_frequency"=$cf;"total_memory"=$cm;"free_memory"=$fm;"cpu_load"=$cl;"free_hdd_space"=$fh;"total_hdd_space"=$th;"platform"=$p;"ppp_active"=$activeSessions}
:local d [:serialize to=json value={"metadata"=$metadata} options=json.no-string-conversion]
:onerror e in={ /tool fetch url=($api . "/api/connector/heartbeat") http-method=post http-header-field=("X-Connector-Token: " . $token . ",Content-Type: application/json") http-data=$d output=none } do={ :log warning ("BillWave heartbeat failed: " . $e) }
`;

  // JSON.stringify supplies the quoting needed for RouterOS source="...".
  // Escape each $ with exactly one backslash so RouterOS stores $sessionId,
  // $activeSessions, etc. rather than a literal backslash before the variable.
  const quote = s => JSON.stringify(s).replaceAll('$', '\\$');
  const command = `/system script remove [find where name="billwave-heartbeat"]; /system scheduler remove [find where name="billwave-heartbeat"]; /system script add name="billwave-heartbeat" policy=read,write,test source=${quote(heartbeatSource)}; /system scheduler add name="billwave-heartbeat" interval=30s on-event="/system script run billwave-heartbeat" start-time=startup policy=read,write,test; /system script run billwave-heartbeat`;

  res.json({ router: router.name, command, note: 'This only replaces the BillWave heartbeat script and scheduler. It does not reset networking or modify PPPoE accounts.' });
}