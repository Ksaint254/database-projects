import { db } from 'hatchable';
export const access='admin';
export const methods=['GET'];
export default async function(req,res){const q=await db.query("SELECT check_name,status,details,checked_at FROM system_health_checks ORDER BY checked_at DESC LIMIT 100");return res.json({checks:q.rows});}