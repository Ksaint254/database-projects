import { db } from "hatchable";
export const access = "admin";
export const methods = ["GET"];
export default async function (req, res) {
  const [isps, customers, activeCustomers] = await Promise.all([
    db.query("SELECT count(*)::int AS count FROM isps"),
    db.query("SELECT count(*)::int AS count FROM customers"),
    db.query("SELECT count(*)::int AS count FROM customers WHERE status = 'active'")
  ]);
  res.json({ total_isps: isps.rows[0].count, total_customers: customers.rows[0].count, active_customers: activeCustomers.rows[0].count, system_status: "operational" });
}