import { db } from 'hatchable';
import { workspaceFor, canManage } from 'lib/tenant-context.js';
export const access='user'; export const methods=['GET','POST'];

export default async function(req,res){
 const w=await workspaceFor(req); if(!w)return res.status(403).json({error:'No ISP workspace assigned'});
 if(req.method==='GET'){
   const {rows}=await db.query("SELECT p.id,p.customer_id,p.invoice_id,p.amount,p.method,p.reference,p.paid_at,p.created_at,c.name customer_name,c.customer_number,i.invoice_number,CASE WHEN i.id IS NULL THEN 'paid' ELSE CASE WHEN i.status='paid' THEN 'paid' WHEN i.status='partial' THEN 'partial' ELSE 'recorded' END END payment_status FROM payments p JOIN customers c ON c.id=p.customer_id LEFT JOIN invoices i ON i.id=p.invoice_id WHERE p.isp_id=$1 ORDER BY p.paid_at DESC",[w.isp_id]);
   return res.json({payments:rows});
 }
 if(!canManage(w.role))return res.status(403).json({error:'Your role cannot record payments'});
 const b=req.body||{};
 if(!b.invoice_id||b.amount===undefined||b.amount==='')return res.status(422).json({error:'Please select an invoice and enter a payment amount'});
 const amount=Number(b.amount); if(!Number.isFinite(amount)||amount<=0)return res.status(422).json({error:'Payment amount must be greater than zero'});
 const invoice=await db.query("SELECT * FROM invoices WHERE id=$1 AND isp_id=$2",[b.invoice_id,w.isp_id]);
 if(!invoice.rows.length)return res.status(404).json({error:'Invoice not found'});
 const inv=invoice.rows[0]; if(Number(inv.balance)<=0)return res.status(422).json({error:'This invoice is already fully paid'});
 if(amount>Number(inv.balance))return res.status(422).json({error:'Payment amount cannot exceed the remaining balance'});
 const reference=String(b.reference||'').trim()||null;
 if(reference){const dup=await db.query("SELECT id FROM payments WHERE isp_id=$1 AND reference=$2",[w.isp_id,reference]);if(dup.rows.length)return res.status(422).json({error:'A payment with this reference already exists'});}
 const payment=await db.query("INSERT INTO payments (isp_id,customer_id,invoice_id,amount,method,reference,paid_at) VALUES ($1,$2,$3,$4,$5,$6,now()) RETURNING id,customer_id,invoice_id,amount,method,reference,paid_at",[w.isp_id,inv.customer_id,inv.id,amount,b.method||'M-Pesa',reference]);
 const balance=Math.max(0,Number(inv.balance)-amount), status=balance===0?'paid':'partial';
 await db.query("UPDATE invoices SET balance=$1,status=$2 WHERE id=$3 AND isp_id=$4",[balance,status,inv.id,w.isp_id]);
 let activation=null;
 if(status==='paid'){
   if(inv.subscription_id){
     const sub=await db.query("SELECT s.id,s.customer_id,s.package_id,p.duration_days FROM subscriptions s JOIN packages p ON p.id=s.package_id WHERE s.id=$1 AND s.isp_id=$2",[inv.subscription_id,w.isp_id]);
     if(sub.rows.length){
       const days=Math.max(1,Number(sub.rows[0].duration_days)||30);
       const s=sub.rows[0];
       await db.query("UPDATE subscriptions SET status='active',starts_at=COALESCE(starts_at,now()),expires_at=GREATEST(COALESCE(expires_at,now()),now())+($1::text||' days')::interval,updated_at=now() WHERE id=$2 AND isp_id=$3",[days,s.id,w.isp_id]);
       const pp=await db.query("UPDATE pppoe_accounts SET status='active',expires_at=GREATEST(COALESCE(expires_at,now()),now())+($1::text||' days')::interval,updated_at=now() WHERE isp_id=$2 AND customer_id=$3 AND package_id=$4 RETURNING id,username,expires_at",[days,w.isp_id,s.customer_id,s.package_id]);
       activation={subscription_id:s.id,pppoe_accounts:pp.rows};
     }
   }
   await db.query("UPDATE customers SET status='active',updated_at=now() WHERE id=$1 AND isp_id=$2",[inv.customer_id,w.isp_id]);
 }
 return res.status(201).json({payment:payment.rows[0],invoice:{id:inv.id,status,balance},activation});
}