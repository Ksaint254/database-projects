import { db } from 'hatchable';
import { workspaceFor } from 'lib/tenant-context.js';
export const access='user'; export const methods=['GET'];
export default async function(req,res){
 const w=await workspaceFor(req); if(!w)return res.status(403).json({error:'No ISP workspace assigned'});
 const {rows}=await db.query("SELECT i.id,i.invoice_number,i.balance,i.amount,i.status,i.due_date,c.id customer_id,c.name customer_name,c.customer_number FROM invoices i JOIN customers c ON c.id=i.customer_id WHERE i.isp_id=$1 AND i.balance>0 AND i.status IN ('unpaid','partial','pending') ORDER BY i.created_at DESC",[w.isp_id]);
 res.json({invoices:rows});
}