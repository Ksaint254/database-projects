import { db } from 'hatchable';

export const access = 'public';
export const methods = ['GET'];

async function hash(v) {
  const b = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(v));
  return [...new Uint8Array(b)].map(x => x.toString(16).padStart(2, '0')).join('');
}

function esc(v) {
  return String(v).replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/\$/g, '\\$').replace(/\r?\n/g, ' ');
}

export default async function (req, res) {
  const code = String(req.params.code || '').trim();
  const q = await db.query("SELECT * FROM router_provision_codes WHERE code=$1 AND status='active' AND expires_at>now() LIMIT 1", [code]);
  if (!q.rows[0]) {
    res.status(404);
    res.setHeader('Content-Type', 'text/plain; charset=utf-8');
    return res.send('# BillWave: invalid or expired provision code\n');
  }

  const p = q.rows[0];
  const token = esc(p.connector_token);
  const api = 'https://billwave.hatchable.site';

  const connectorSource = `
:global billwaveConnectorRunning
:if ($billwaveConnectorRunning = true) do={ :return }
:set billwaveConnectorRunning true
:local api "${api}"
:local token "${token}"
:onerror pollError in={
  :local r [/tool fetch url=($api . "/api/connector/jobs") http-method=get http-header-field=("X-Connector-Token: " . $token) output=user as-value]
  :if (($r->"status") = "finished") do={
    :local body ($r->"data")
    :if ([:len $body] > 0) do={
      :local response [:deserialize from=json value=$body]
      :local job ($response->"job")
      :if ([:len $job] > 0) do={
        :local jobId ($job->"id")
        :local action ($job->"action")
        :local payload ($job->"payload")
        :local path ""
        :set path ($payload->"path")
        :if (($action = "mikrotik") and ([:len $jobId] > 0)) do={
          :local result {"ok"=false;"error"="No connector action executed"}
          :local success false

          :if ($path = "/system/resource") do={
            :set result [/system resource get]
            :set success true
          }

          :if ($path = "/interface") do={
            :set result [/interface print as-value]
            :set success true
          }

          :if ($path = "/ip/address") do={
            :set result [/ip address print as-value]
            :set success true
          }

          :if ($path = "/ip/route") do={
            :set result [/ip route print as-value]
            :set success true
          }

          :if ($path = "/ppp/active") do={
            :set result [/ppp active print as-value]
            :set success true
          }

          :if ($path = "/ppp/secret") do={
            :set result [/ppp secret print as-value]
            :set success true
          }

          :if ($path = "/ppp/profile") do={
            :set result [/ppp profile print as-value]
            :set success true
          }

          :if ($path = "/ppp/profile/upsert") do={
            :local profileName ($payload->"name")
            :local rateLimit ($payload->"rate_limit")
            :if (([:len $profileName] = 0) or ($profileName = "default") or ($profileName = "<default>")) do={
              :set result {"ok"=false;"error"="Protected PPP profile cannot be modified: default"}
            } else={
              :local poolIds [/ip pool find where name="billwave-pppoe-pool"]
              :if ([:len $poolIds] = 0) do={ /ip pool add name="billwave-pppoe-pool" ranges=172.31.0.2-172.31.255.254 }
              :local poolName "billwave-pppoe-pool"
              :local poolCheck [/ip pool find where name=$poolName]
              :if ([:len $poolCheck] = 0) do={
                :set result {"ok"=false;"error"="BillWave PPPoE pool could not be created"}
              } else={
                :local profileIds [/ppp profile find where name=$profileName]
                :if ([:len $profileIds] = 0) do={
                  /ppp profile add name=$profileName local-address=172.31.0.1 remote-address=$poolName dns-server=8.8.8.8 rate-limit=$rateLimit comment="BillWave managed"
                } else={
                  :local targetId [:pick $profileIds 0]
                  :local targetName [/ppp profile get $targetId name]
                  :if ($targetName != $profileName) do={
                    :set result {"ok"=false;"error"=("Profile lookup mismatch: requested " . $profileName . ", matched " . $targetName)}
                  } else={
                    :local currentLocal [/ppp profile get $targetId local-address]
                    :local currentRemote [/ppp profile get $targetId remote-address]
                    :local currentDns [/ppp profile get $targetId dns-server]
                    :local currentRate [/ppp profile get $targetId rate-limit]
                    :local currentComment [/ppp profile get $targetId comment]
                    :if (($currentLocal != "172.31.0.1") or ($currentRemote != $poolName) or ($currentDns != "8.8.8.8") or ($currentRate != $rateLimit) or ($currentComment != "BillWave managed")) do={
                      /ppp profile set $targetId local-address=172.31.0.1 remote-address=$poolName dns-server=8.8.8.8 rate-limit=$rateLimit comment="BillWave managed"
                    }
                  }
                }
                :local verify [/ppp profile find where name=$profileName]
                :if ([:len $verify] > 0) do={
                  :local verifyId [:pick $verify 0]
                  :local verifyName [/ppp profile get $verifyId name]
                  :if ($verifyName = $profileName) do={
                    :set result {"ok"=true;"profile"=$profileName}
                    :set success true
                  } else={
                    :set result {"ok"=false;"error"=("PPP profile verification mismatch: expected " . $profileName . ", got " . $verifyName)}
                  }
                } else={
                  :set result {"ok"=false;"error"=("PPP profile was not created: " . $profileName)}
                }
              }
            }
          }

          :if ($path = "/ppp/secret/upsert") do={
            :local usernameName ($payload->"username")
            :local userPassword ($payload->"password")
            :local userProfile ($payload->"profile")
            :local isDisabled ($payload->"disabled")
            :local rateLimit ($payload->"rate_limit")
            :local allowEnable ($payload->"allow_enable")

            :if (($isDisabled = false) and ($allowEnable != true)) do={ :set isDisabled true }

            :if ([:len $usernameName] = 0) do={
              :set result {"ok"=false;"error"="Username is required"}
            } else={
              :if ([:len $userProfile] = 0) do={
                :set result {"ok"=false;"error"="PPP profile is required"}
              } else={
                :if (($userProfile = "default") or ($userProfile = "<default>")) do={
                  :set result {"ok"=false;"error"="Customer cannot use protected PPP profile: default"}
                } else={
                  :local profileIds [/ppp profile find where name=$userProfile]

              :if (([:len $profileIds] = 0) and ($userProfile != "default")) do={
                :if ([:len $rateLimit] > 0) do={
                  :local poolIds [/ip pool find where name="billwave-pppoe-pool"]
                  :if ([:len $poolIds] = 0) do={ /ip pool add name="billwave-pppoe-pool" ranges=172.31.0.2-172.31.255.254 }
                  :do {
                    /ppp profile add name=$userProfile local-address=172.31.0.1 remote-address=billwave-pppoe-pool dns-server=8.8.8.8 rate-limit=$rateLimit comment="BillWave managed"
                  } on-error={}
                }
              }

              :local finalProfileIds [/ppp profile find where name=$userProfile]
              :if ([:len $finalProfileIds] = 0) do={
                :set result {"ok"=false;"error"=("PPP profile not found: " . $userProfile)}
              } else={
                :local secretIds [/ppp secret find where name=$usernameName]
                :do {
                  :if ([:len $secretIds] = 0) do={
                    /ppp secret add name=$usernameName password=$userPassword service=pppoe profile=$userProfile disabled=$isDisabled comment="BillWave managed"
                  } else={
                    :local targetId [:pick $secretIds 0]
                    :local targetName [/ppp secret get $targetId name]
                    :if ($targetName != $usernameName) do={
                      :set result {"ok"=false;"error"=("Secret lookup mismatch: requested " . $usernameName . ", matched " . $targetName)}
                    } else={
                      :local currentPassword [/ppp secret get $targetId password]
                      :local currentService [/ppp secret get $targetId service]
                      :local currentProfile [/ppp secret get $targetId profile]
                      :local currentDisabled [/ppp secret get $targetId disabled]
                      :local currentComment [/ppp secret get $targetId comment]
                      :if (($currentPassword != $userPassword) or ($currentService != "pppoe") or ($currentProfile != $userProfile) or ($currentDisabled != $isDisabled) or ($currentComment != "BillWave managed")) do={
                        /ppp secret set $targetId password=$userPassword service=pppoe profile=$userProfile disabled=$isDisabled comment="BillWave managed"
                      }
                    }
                  }

                  :local verify [/ppp secret find where name=$usernameName]
                  :if ([:len $verify] = 0) do={
                    :set result {"ok"=false;"error"=("PPP secret was not created: " . $usernameName)}
                  } else={
                    :local verifyId [:pick $verify 0]
                    :local actualName [/ppp secret get $verifyId name]
                    :local actualProfile [/ppp secret get $verifyId profile]
                    :local actualDisabled [/ppp secret get $verifyId disabled]
                    :if (($actualName != $usernameName) or ($actualProfile != $userProfile) or ($actualDisabled != $isDisabled)) do={
                      :set result {"ok"=false;"error"=("PPP secret verification mismatch: expected " . $usernameName . " / " . $userProfile . " / disabled=" . $isDisabled . ", got " . $actualName . " / " . $actualProfile . " / disabled=" . $actualDisabled)}
                    } else={
                      :set result {"ok"=true;"username"=$usernameName;"profile"=$userProfile;"disabled"=$actualDisabled}
                      :set success true
                    }
                  }
                } on-error={
                  :set result {"ok"=false;"error"=("RouterOS failed while creating PPP secret: " . $usernameName)}
                }
              }
            }
          }
        }
        }

          :if ($path = "/ppp/secret/disable") do={
            :local name ($payload->"username")
            :if ([:len $name] > 0) do={
              :local ids [/ppp secret find where name=$name]
              :if ([:len $ids] > 0) do={
                :local targetId [:pick $ids 0]
                /ppp secret set $targetId disabled=yes
                :local actualDisabled [/ppp secret get $targetId disabled]
                :if ($actualDisabled = true) do={
                  :set result {"ok"=true;"username"=$name;"disabled"=true}
                  :set success true
                } else={
                  :set result {"ok"=false;"username"=$name;"disabled"=false;"error"=("RouterOS did not persist disabled=yes for " . $name)}
                }
              } else={
                :set result {"ok"=false;"error"=("PPP secret was not found: " . $name)}
              }
            }
          }

          :if ($path = "/ppp/active/disconnect") do={
            :local name ($payload->"username")
            :if ([:len $name] > 0) do={
              :local ids [/ppp active find where name=$name]
              :foreach targetId in=$ids do={ /ppp active remove $targetId }
              :set result {"ok"=true;"username"=$name;"disconnected"=true}
              :set success true
            }
          }

          :if ($path = "/ppp/secret/remove") do={
            # Safety: treat account deletion as router-side retirement.
            # Do not physically remove a PPP secret because that operation has
            # caused collateral PPPoE session churn on the production router.
            :local name ($payload->"username")
            :if ([:len $name] > 0) do={
              :local ids [/ppp secret find where name=$name]
              :if ([:len $ids] > 0) do={
                :local targetId [:pick $ids 0]
                /ppp secret set $targetId disabled=yes comment="BillWave retired"
                :local activeIds [/ppp active find where name=$name]
                :foreach activeId in=$activeIds do={ /ppp active remove $activeId }
                :set result {"ok"=true;"username"=$name;"removed"=false;"retired"=true;"disabled"=true}
                :set success true
              } else={
                :set result {"ok"=true;"username"=$name;"removed"=true;"retired"=true;"note"="PPP secret was already absent"}
                :set success true
              }
            }
          }

          :local report {"job_id"=$jobId;"success"=$success;"result"=$result}
          :local reportJson [:serialize to=json value=$report options=json.no-string-conversion]
          :do {
            /tool fetch url=(($api . "/api/connector/jobs")) http-method=post http-header-field=("X-Connector-Token: " . $token . ",Content-Type: application/json") http-data=$reportJson output=none
          } on-error={
            :log warning ("BillWave job report failed: " . $jobId)
          }
        }
      }
    }
  }
} do={ :log error ("BillWave connector error: " . $pollError) }
:set billwaveConnectorRunning false
`;

  const heartbeatSource = `
:local n [/system identity get name]
:local u [/system resource get uptime]
:local v [/system resource get version]
:local b [/system resource get board-name]
:local a [/system resource get architecture-name]
:local cc [/system resource get cpu-count]
:local cf [/system resource get cpu-frequency]
:local cm [/system resource get total-memory]
:local fm [/system resource get free-memory]
:local cl [/system resource get cpu-load]
:local fh [/system resource get free-hdd-space]
:local th [/system resource get total-hdd-space]
:local p [/system resource get platform]
:local kenyaDate [/system clock get date]
:local kenyaTime [/system clock get time]
:local kenyaZone [/system clock get time-zone-name]
:local activePpp [/ppp active print as-value]
:local metadata {"identity"=$n;"uptime"=$u;"version"=$v;"board"=$b;"architecture"=$a;"cpu_count"=$cc;"cpu_frequency"=$cf;"total_memory"=$cm;"free_memory"=$fm;"cpu_load"=$cl;"free_hdd_space"=$fh;"total_hdd_space"=$th;"platform"=$p;"kenya_date"=$kenyaDate;"kenya_time"=$kenyaTime;"kenya_timezone"=$kenyaZone;"ppp_active"=$activePpp;"wireguard_address"="10.77.0.1";"wireguard_port"=51820}
:local d [:serialize to=json value={"metadata"=$metadata} options=json.no-string-conversion]
:onerror e in={ /tool fetch url="${api}/api/connector/heartbeat" http-method=post http-header-field="X-Connector-Token: ${token},Content-Type: application/json" http-data=$d output=none } do={ :log warning ("BillWave heartbeat failed: " . $e) }
`;

  const quote = s => JSON.stringify(s).replaceAll('$', '\\$');
  const script = `# BillWave Router Provisioning - RouterOS 7
:local bwToken "${token}"

# ============================================================
# BILLWAVE INDEPENDENT NETWORK
# ether1 = WAN / upstream Internet
# ether2-ether5 = BillWave customer ports
# ============================================================

# Remove old PPPoE services that belong to the temporary ISP setup.
/interface pppoe-server server remove [find where interface="hotspot-bridge"]
/interface pppoe-server server remove [find where interface="centipid-bridge"]

# Remove old HotSpot service instances from the temporary setup.
/ip hotspot remove [find where interface="hotspot-bridge"]

# Create the BillWave customer bridge if it does not exist.
:local bwBridge [/interface bridge find where name="billwave-bridge"]
:if ([:len $bwBridge] = 0) do={
  /interface bridge add name="billwave-bridge" protocol-mode=rstp comment="BillWave customer network"
}

# Move customer Ethernet ports out of the temporary bridge(s).
/interface bridge port remove [find where interface=ether2]
/interface bridge port remove [find where interface=ether3]
/interface bridge port remove [find where interface=ether4]
/interface bridge port remove [find where interface=ether5]

# Add the customer ports to BillWave.
:local bwPort2 [/interface bridge port find where interface=ether2 and bridge="billwave-bridge"]
:if ([:len $bwPort2] = 0) do={ /interface bridge port add bridge="billwave-bridge" interface=ether2 }
:local bwPort3 [/interface bridge port find where interface=ether3 and bridge="billwave-bridge"]
:if ([:len $bwPort3] = 0) do={ /interface bridge port add bridge="billwave-bridge" interface=ether3 }
:local bwPort4 [/interface bridge port find where interface=ether4 and bridge="billwave-bridge"]
:if ([:len $bwPort4] = 0) do={ /interface bridge port add bridge="billwave-bridge" interface=ether4 }
:local bwPort5 [/interface bridge port find where interface=ether5 and bridge="billwave-bridge"]
:if ([:len $bwPort5] = 0) do={ /interface bridge port add bridge="billwave-bridge" interface=ether5 }

# Remove temporary ISP bridge addresses before assigning the BillWave gateway.
/ip address remove [find where interface="hotspot-bridge"]
/ip address remove [find where interface="centipid-bridge"]

# BillWave PPPoE gateway address.
:local bwGateway [/ip address find where address="172.31.0.1/16" and interface="billwave-bridge"]
:if ([:len $bwGateway] = 0) do={
  /ip address add address=172.31.0.1/16 interface="billwave-bridge" comment="BillWave PPPoE gateway"
}

# BillWave PPPoE address pool.
:local bwPool [/ip pool find where name="billwave-pppoe-pool"]
:if ([:len $bwPool] = 0) do={
  /ip pool add name="billwave-pppoe-pool" ranges=172.31.0.2-172.31.255.254 comment="BillWave PPPoE pool"
} else={
  /ip pool set [:pick $bwPool 0] ranges=172.31.0.2-172.31.255.254 comment="BillWave PPPoE pool"
}

# BillWave PPPoE server.
:local bwPppoe [/interface pppoe-server server find where service-name="BillWave" and interface="billwave-bridge"]
:if ([:len $bwPppoe] = 0) do={
  /interface pppoe-server server add service-name="BillWave" interface="billwave-bridge" default-profile="default" authentication=pap,chap,mschap1,mschap2 keepalive-timeout=10 one-session-per-host=yes disabled=no comment="BillWave PPPoE server"
} else={
  /interface pppoe-server server set [:pick $bwPppoe 0] disabled=no default-profile="default" authentication=pap,chap,mschap1,mschap2 one-session-per-host=yes
}

# Ensure PPPoE clients can reach the WAN and are NATed to ether1.
/ip firewall nat remove [find where comment="BillWave WAN NAT"]
/ip firewall nat add chain=srcnat action=masquerade src-address=172.31.0.0/16 out-interface=ether1 comment="BillWave WAN NAT"

# Allow BillWave PPPoE customers through the router firewall before broad drop rules.
/ip firewall filter remove [find where comment="BillWave PPPoE Internet"]
/ip firewall filter add chain=forward action=accept src-address=172.31.0.0/16 out-interface=ether1 connection-state=new,established,related comment="BillWave PPPoE Internet" place-before=0

# Router DNS for PPPoE clients.
/ip dns set servers=8.8.8.8,1.1.1.1 allow-remote-requests=yes

# Keep the MikroTik clock in Kenya time so connector timestamps are local/EAT.
/system clock set time-zone-name=Africa/Nairobi

# Remove now-empty temporary bridges.
/interface bridge port remove [find where bridge="hotspot-bridge"]
/interface bridge port remove [find where bridge="centipid-bridge"]
/interface bridge remove [find where name="hotspot-bridge"]
/interface bridge remove [find where name="centipid-bridge"]

# Remove the temporary Centipid PPPoE pool and obsolete server/profile objects where present.
/ip pool remove [find where name="centipid-pool"]
/interface pppoe-server server remove [find where service-name="centipid-pppoe"]
/ppp profile remove [find where name="INTERNET" and comment="Added by Centipid"]

/system script remove [find where name="billwave-heartbeat"]
/system scheduler remove [find where name="billwave-heartbeat"]
/system script remove [find where name="billwave-connector"]
/system scheduler remove [find where name="billwave-connector"]

/system script add name="billwave-heartbeat" policy=read,write,test source=${quote(heartbeatSource)}
/system script add name="billwave-connector" policy=read,write,test source=${quote(connectorSource)}
/system scheduler add name="billwave-heartbeat" interval=30s on-event="/system script run billwave-heartbeat" start-time=startup policy=read,write,test
/system scheduler add name="billwave-connector" interval=5s on-event="/system script run billwave-connector" start-time=startup policy=read,write,test
/system script run billwave-heartbeat
/system script run billwave-connector

:put "BillWave provisioning complete"
:put "Outbound HTTPS connector enabled"
`;

  const tokenHash = await hash(p.connector_token);

  // A router must have exactly one active BillWave connector. Reprovisioning
  // previously created a new connector every time, leaving old connectors
  // online and causing PPP jobs to be delivered to a stale token/script.
  const existing = await db.query("SELECT id FROM router_connectors WHERE router_id=$1 ORDER BY last_seen_at DESC NULLS LAST,created_at DESC", [p.router_id]);
  for (const old of existing.rows) {
    await db.query("DELETE FROM router_connector_jobs WHERE connector_id=$1", [old.id]);
    await db.query("DELETE FROM router_connectors WHERE id=$1", [old.id]);
  }
  await db.query("INSERT INTO router_connectors(isp_id,router_id,name,token_hash,status,last_seen_at) VALUES($1,$2,$3,$4,'provisioned',now())", [p.isp_id, p.router_id, 'BillWave Provisioned Router', tokenHash]);

  // Keep the provisioning code active until the router actually checks in.
  // A failed RouterOS import must not permanently burn the code.
  await db.query("UPDATE router_provision_codes SET status='active',used_at=NULL WHERE id=$1", [p.id]);

  const cq = await db.query("SELECT id FROM router_connectors WHERE token_hash=$1 LIMIT 1", [tokenHash]);
  const connectorId = cq.rows[0]?.id;
  if (connectorId) {
    const accounts = await db.query("SELECT a.username,a.password,a.profile,a.status,a.expires_at,p.speed FROM pppoe_accounts a LEFT JOIN packages p ON p.id=a.package_id WHERE a.isp_id=$1 AND a.router_id=$2 ORDER BY a.created_at", [p.isp_id, p.router_id]);
    for (const a of accounts.rows) {
      if (!a.username || !a.password) continue;
      const profile = String(a.profile || '').trim();
      const rate = a.speed ? String(a.speed).replace(/\s*mbps/i,'M') + '/' + String(a.speed).replace(/\s*mbps/i,'M') : null;
      // Never enqueue a customer secret against RouterOS's protected default profile.
      // Accounts without a real BillWave profile must be fixed in the ISP data first.
      if (!profile || profile === 'default' || profile === '<default>') continue;
      const accountExpired = !!a.expires_at && new Date(a.expires_at) <= new Date();
      const allowEnable = a.status === 'active' && !accountExpired;
      if (!allowEnable) {
        await db.query("INSERT INTO router_connector_jobs(connector_id,action,payload,status) VALUES($1,'mikrotik',$2,'pending')", [connectorId, JSON.stringify({path:'/ppp/secret/disable',method:'POST',username:a.username})]);
        await db.query("INSERT INTO router_connector_jobs(connector_id,action,payload,status) VALUES($1,'mikrotik',$2,'pending')", [connectorId, JSON.stringify({path:'/ppp/active/disconnect',method:'POST',username:a.username})]);
      } else {
        // Do not rewrite shared PPP profiles during router reprovisioning. The
        // secret upsert only references the already-existing profile.
        await db.query("INSERT INTO router_connector_jobs(connector_id,action,payload,status) VALUES($1,'mikrotik',$2,'pending')", [connectorId, JSON.stringify({path:'/ppp/secret/upsert',method:'POST',username:a.username,password:a.password,profile,disabled:false,rate_limit:rate,expires_at:a.expires_at,status:'active',allow_enable:true})]);
      }
    }
  }

  res.setHeader('Content-Type', 'text/plain; charset=utf-8');
  res.setHeader('Content-Disposition', 'inline; filename=billwave.rsc');
  return res.send(script);
}