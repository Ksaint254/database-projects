import { auth } from 'hatchable';
export const access='public';
export const methods=['GET'];
const OWNER_EMAIL='iancty8@gmail.com';
export default async function(req,res){
  const u=await auth.getUser(req);
  const email=String(u?.email||'').trim().toLowerCase();
  res.json({is_owner:email===OWNER_EMAIL});
}