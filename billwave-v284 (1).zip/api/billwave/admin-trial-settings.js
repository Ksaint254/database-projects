import { db } from 'hatchable';
export const access='admin'; export const methods=['GET','PUT'];
export default async function(req,res){
 if(req.method==='GET'){
  const q=await db.query("SELECT key,value FROM billwave_settings WHERE key IN ('trial_enabled','trial_days')");
  const s=Object.fromEntries(q.rows.map(x=>[x.key,x.value]));
  return res.json({trial_enabled:s.trial_enabled!=='false',trial_days:Number(s.trial_days||14)});
 }
 const days=Number(req.body?.trial_days),enabled=req.body?.trial_enabled!==false;
 if(!Number.isInteger(days)||days<0||days>365)return res.status(422).json({error:'Trial days must be a whole number from 0 to 365.'});
 await db.query("INSERT INTO billwave_settings(key,value,updated_at) VALUES('trial_days',$1,now()) ON CONFLICT(key) DO UPDATE SET value=EXCLUDED.value,updated_at=now()",[String(days)]);
 await db.query("INSERT INTO billwave_settings(key,value,updated_at) VALUES('trial_enabled',$1,now()) ON CONFLICT(key) DO UPDATE SET value=EXCLUDED.value,updated_at=now()",[enabled?'true':'false']);
 return res.json({ok:true,trial_enabled:enabled,trial_days:days});
}