import { db } from 'hatchable';
export const access='admin'; export const methods=['GET','POST','PUT'];
export default async function(req,res){
 if(req.method==='GET'){const {rows}=await db.query("SELECT t.*,i.name isp_name,i.email isp_email FROM support_tickets t LEFT JOIN isps i ON i.id=t.isp_id ORDER BY CASE WHEN t.status='open' THEN 0 WHEN t.status='pending' THEN 1 ELSE 2 END,t.created_at DESC");return res.json({tickets:rows});}
 const b=req.body||{}; if(!b.id&&req.method==='POST') return res.status(422).json({error:'Ticket id is required'});
 if(req.method==='PUT'){if(!['open','pending','resolved','closed'].includes(String(b.status)))return res.status(422).json({error:'Invalid status'});const {rows}=await db.query("UPDATE support_tickets SET status=$1,admin_reply=$2,updated_at=now() WHERE id=$3 RETURNING *",[b.status,b.admin_reply||null,b.id]);if(!rows.length)return res.status(404).json({error:'Ticket not found'});return res.json({ticket:rows[0]});}
 return res.status(405).json({error:'Method not supported'});
}