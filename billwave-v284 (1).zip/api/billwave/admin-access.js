import { auth } from 'hatchable';
export const access='public';
export const methods=['GET'];
const OWNER_EMAIL='iancty8@gmail.com';
export default async function(req,res){
 const user=await auth.getUser(req);
 if(!user)return res.status(401).json({is_owner:false,error:'Not signed in.'});
 const email=String(user.email||'').trim().toLowerCase();
 return res.json({is_owner:email===OWNER_EMAIL});
}