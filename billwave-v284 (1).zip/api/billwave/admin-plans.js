import { auth, db } from 'hatchable';

export const access = 'public';
export const methods = ['GET','POST','PUT'];

const OWNER_EMAIL = 'iancty8@gmail.com';

async function requireOwner(req, res) {
  const user = await auth.getUser(req);
  const email = String(user?.email || '').trim().toLowerCase();
  if (!user || email !== OWNER_EMAIL) {
    res.status(403).json({ error: 'Owner access required.' });
    return null;
  }
  return user;
}

export default async function(req,res){
  if (!await requireOwner(req,res)) return;

  if(req.method==='GET'){
    const q=await db.query('SELECT id,name,monthly_price,description,status FROM billwave_plans ORDER BY monthly_price');
    return res.json({plans:q.rows});
  }

  if(req.method==='POST'){
    const {name,monthly_price,description,status}=req.body||{};
    const clean=String(name||'').trim(),price=Number(monthly_price);
    if(!clean)return res.status(422).json({error:'Plan name is required'});
    if(!Number.isFinite(price)||price<=0)return res.status(422).json({error:'Enter a valid monthly price'});
    const q=await db.query('INSERT INTO billwave_plans(name,monthly_price,description,status) VALUES($1,$2,$3,$4) RETURNING id,name,monthly_price,description,status',[clean,price,String(description||'').trim(),status==='inactive'?'inactive':'active']);
    return res.status(201).json({ok:true,plan:q.rows[0]});
  }

  const {id,name,monthly_price,description,status}=req.body||{};
  if(!id)return res.status(400).json({error:'Plan id is required'});
  const clean=String(name||'').trim(),price=Number(monthly_price);
  if(!clean)return res.status(422).json({error:'Plan name is required'});
  if(!Number.isFinite(price)||price<=0)return res.status(400).json({error:'Invalid monthly price'});
  const q=await db.query('UPDATE billwave_plans SET name=$1,monthly_price=$2,description=$3,status=$4 WHERE id=$5 RETURNING id,name,monthly_price,description,status',[clean,price,String(description||'').trim(),status==='inactive'?'inactive':'active',id]);
  if(!q.rows.length)return res.status(404).json({error:'Plan not found'});
  return res.json({ok:true,plan:q.rows[0]});
}