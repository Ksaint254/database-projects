import { auth, db } from 'hatchable';
export const access='public';
export const methods=['GET','POST','DELETE'];
const OWNER_EMAIL='iancty8@gmail.com';
async function owner(req){
 const u=await auth.getUser(req); if(!u)return null;
 if(String(u.email||'').trim().toLowerCase()===OWNER_EMAIL)return u;
 return null;
}
export default async function(req,res){
 const u=await owner(req); if(!u)return res.status(403).json({error:'Owner access required.'});
 if(req.method==='GET'){
   const q=await db.query("SELECT iu.id,iu.auth_user_id,iu.isp_id,iu.role,iu.status,iu.created_at,i.name AS isp_name FROM isp_users iu LEFT JOIN isps i ON i.id=iu.isp_id ORDER BY iu.created_at DESC");
   return res.json({users:q.rows});
 }
 if(req.method==='POST'){
   const b=req.body||{}; const email=String(b.email||'').trim().toLowerCase(); const ispId=String(b.isp_id||'').trim(); const role=String(b.role||'isp_staff').trim();
   if(!email||!ispId)return res.status(422).json({error:'Email and ISP are required.'});
   if(!['isp_admin','isp_staff','support'].includes(role))return res.status(422).json({error:'Invalid dashboard role.'});
   const u=await db.query('SELECT id,email FROM users WHERE lower(email)=lower($1) LIMIT 1',[email]);
   if(!u.rows.length)return res.status(404).json({error:'This email has not created a BillWave account yet. Ask the user to register first, then add them.'});
   const r=await db.query("INSERT INTO isp_users(isp_id,auth_user_id,role,status) VALUES($1,$2,$3,'active') ON CONFLICT(isp_id,auth_user_id) DO UPDATE SET role=EXCLUDED.role,status='active' RETURNING id,isp_id,auth_user_id,role,status",[ispId,u.rows[0].id,role]);
   return res.status(201).json({user:r.rows[0],email});
 }
 const id=String(req.body?.id||req.query?.id||'').trim(); if(!id)return res.status(422).json({error:'User id is required.'});
 const r=await db.query('DELETE FROM isp_users WHERE id=$1 RETURNING id',[id]); return res.json({ok:r.rows.length>0});
}