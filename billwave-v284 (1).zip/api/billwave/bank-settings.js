import { db } from 'hatchable';
export const access='admin'; export const methods=['GET','PUT'];
export default async function(req,res){
 if(req.method==='GET'){const r=await db.query("SELECT bank_name,account_name,account_number,branch,instructions FROM billwave_bank_settings ORDER BY updated_at DESC LIMIT 1");return res.json(r.rows[0]||null)}
 const b=req.body||{}; if(!b.bank_name||!b.account_name)return res.status(422).json({error:'Bank name and account name are required'});
 const r=await db.query("UPDATE billwave_bank_settings SET bank_name=$1,account_name=$2,account_number=$3,branch=$4,instructions=$5,updated_at=now() RETURNING bank_name,account_name,account_number,branch,instructions",[b.bank_name,b.account_name,b.account_number||'',b.branch||'',b.instructions||'']); return res.json(r.rows[0]);
}