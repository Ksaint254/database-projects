import { db } from 'hatchable';
export const access='admin'; export const methods=['GET'];
export default async function(req,res){
 const {rows}=await db.query("SELECT bp.id,bp.amount,bp.payment_method,bp.reference,bp.mpesa_receipt,bp.provider,bp.status,bp.verification_note,bp.paid_at,bp.created_at,s.id subscription_id,s.status subscription_status,i.id isp_id,i.name isp_name,i.email isp_email,p.name plan_name,p.monthly_price FROM billwave_subscription_payments bp JOIN isp_subscriptions s ON s.id=bp.isp_subscription_id JOIN isps i ON i.id=s.isp_id JOIN billwave_plans p ON p.id=s.plan_id ORDER BY CASE WHEN bp.status='pending' THEN 0 ELSE 1 END,bp.created_at DESC");return res.json({payments:rows});
}