import { auth, db } from 'hatchable';

export const access = 'public';
export const methods = ['GET'];

const OWNER_EMAIL = 'iancty8@gmail.com';

export default async function(req, res) {
  const user = await auth.getUser(req);
  const email = String(user?.email || '').trim().toLowerCase();
  if (!user || email !== OWNER_EMAIL) {
    return res.status(403).json({ error: 'Owner access required.' });
  }

  const [isps, active, trials, mrr, revenue] = await Promise.all([
    db.query('SELECT count(*)::int count FROM isps'),
    db.query("SELECT count(*)::int count FROM isp_subscriptions WHERE status='active'"),
    db.query("SELECT count(*)::int count FROM isp_subscriptions WHERE status='trial'"),
    db.query("SELECT COALESCE(sum(p.monthly_price),0) total FROM isp_subscriptions s JOIN billwave_plans p ON p.id=s.plan_id WHERE s.status='active'"),
    db.query("SELECT COALESCE(sum(amount),0) total FROM billwave_subscription_payments WHERE status='paid' AND paid_at>=date_trunc('month',now())")
  ]);

  return res.json({
    total_isps: isps.rows[0].count,
    active_isps: active.rows[0].count,
    trial_isps: trials.rows[0].count,
    mrr: Number(mrr.rows[0].total || 0),
    revenue_month: Number(revenue.rows[0].total || 0)
  });
}