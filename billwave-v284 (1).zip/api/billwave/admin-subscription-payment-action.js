import { db } from 'hatchable';
export const access='admin'; export const methods=['POST'];
export default async function(req,res){
 const {payment_id,action,note}=req.body||{};if(!payment_id||!['approve','reject'].includes(action))return res.status(422).json({error:'Payment and valid action are required'});
 const p=await db.query('SELECT bp.*,s.isp_id,s.plan_id,p.monthly_price FROM billwave_subscription_payments bp JOIN isp_subscriptions s ON s.id=bp.isp_subscription_id JOIN billwave_plans p ON p.id=s.plan_id WHERE bp.id=$1',[payment_id]);if(!p.rows.length)return res.status(404).json({error:'Payment not found'});const x=p.rows[0];if(x.status!=='pending')return res.status(409).json({error:`Payment is already ${x.status}`});
 if(action==='reject'){await db.query("UPDATE billwave_subscription_payments SET status='rejected',verification_note=$1 WHERE id=$2",[String(note||'Rejected by owner'),payment_id]);return res.json({status:'rejected'});}
 await db.query("UPDATE billwave_subscription_payments SET status='paid',paid_at=now(),verification_note=$1 WHERE id=$2",[String(note||'Verified manually by owner'),payment_id]);
 await db.query("UPDATE isp_subscriptions SET status='active',started_at=COALESCE(started_at,now()),renews_at=CASE WHEN renews_at IS NOT NULL AND renews_at>now() THEN renews_at+interval '1 month' ELSE now()+interval '1 month' END WHERE id=$1",[x.isp_subscription_id]);
 await db.query("UPDATE isps SET status='active',updated_at=now() WHERE id=$1",[x.isp_id]);
 return res.json({status:'paid'});
}