import { db } from 'hatchable';
export const access='admin'; export const methods=['GET'];
export default async function(req,res){
 try{
  const m=await db.query("SELECT COALESCE(SUM(amount),0) total,COUNT(*) count FROM billwave_subscription_payments WHERE status='completed'");
  const mo=await db.query("SELECT COALESCE(SUM(amount),0) total,COUNT(*) count FROM billwave_subscription_payments WHERE status='completed' AND created_at>=date_trunc('month',now())");
  const by=await db.query("SELECT date_trunc('day',created_at)::date day,COALESCE(SUM(amount),0) amount,COUNT(*) count FROM billwave_subscription_payments WHERE status='completed' AND created_at>=now()-interval '30 days' GROUP BY 1 ORDER BY 1");
  return res.json({total:Number(m.rows[0].total),count:Number(m.rows[0].count),month:Number(mo.rows[0].total),month_count:Number(mo.rows[0].count),daily:by.rows});
 }catch(e){return res.status(500).json({error:'Revenue data is temporarily unavailable.',detail:e?.message||'unknown'});}
}