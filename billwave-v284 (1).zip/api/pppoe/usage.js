import { db } from 'hatchable';
import { workspaceFor } from 'lib/tenant-context.js';

export const access = "user";
export const methods = ["GET"];

export default async function(req, res) {
  const workspace = await workspaceFor(req);
  if (!workspace) return res.status(403).json({ error: "No ISP workspace assigned" });

  const accountId = req.query?.pppoe_account_id;
  const range = String(req.query?.range || 'month').toLowerCase();
  const since = range === 'all' ? '1970-01-01' : range === '30d' ? 'current_date - 29' : 'date_trunc(\'month\', current_date)::date';

  if (accountId) {
    const account = await db.query("SELECT a.id,a.username,c.name customer_name FROM pppoe_accounts a LEFT JOIN customers c ON c.id=a.customer_id WHERE a.id=$1 AND a.isp_id=$2 LIMIT 1", [accountId, workspace.isp_id]);
    if (!account.rows[0]) return res.status(404).json({ error: "PPPoE account not found" });
    const result = await db.query(`SELECT usage_date,download_bytes,upload_bytes,session_seconds,(download_bytes+upload_bytes) total_bytes FROM pppoe_usage_daily WHERE isp_id=$1 AND pppoe_account_id=$2 AND usage_date >= ${since} ORDER BY usage_date ASC`, [workspace.isp_id, accountId]);
    const totals = result.rows.reduce((a,x)=>({download_bytes:a.download_bytes+Number(x.download_bytes||0),upload_bytes:a.upload_bytes+Number(x.upload_bytes||0),session_seconds:a.session_seconds+Number(x.session_seconds||0)}),{download_bytes:0,upload_bytes:0,session_seconds:0});
    return res.json({ customer: account.rows[0], range, usage: result.rows, totals: {...totals,total_bytes:totals.download_bytes+totals.upload_bytes} });
  }

  const result = await db.query(`SELECT a.id,a.username,c.name customer_name,COALESCE(SUM(u.download_bytes),0) download_bytes,COALESCE(SUM(u.upload_bytes),0) upload_bytes,COALESCE(SUM(u.session_seconds),0) session_seconds FROM pppoe_accounts a LEFT JOIN customers c ON c.id=a.customer_id LEFT JOIN pppoe_usage_daily u ON u.pppoe_account_id=a.id AND u.usage_date >= ${since} WHERE a.isp_id=$1 GROUP BY a.id,a.username,c.name ORDER BY (COALESCE(SUM(u.download_bytes),0)+COALESCE(SUM(u.upload_bytes),0)) DESC`, [workspace.isp_id]);
  return res.json({ range, usage: result.rows.map(x=>({...x,total_bytes:Number(x.download_bytes||0)+Number(x.upload_bytes||0)})) });
}