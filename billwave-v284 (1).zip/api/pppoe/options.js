export const access='user'; export const methods=['GET'];
import { db } from 'hatchable'; import { workspaceFor } from 'lib/tenant-context.js';
export default async function(req,res){const w=await workspaceFor(req);if(!w)return res.status(403).json({error:'No ISP workspace assigned'});const [customers,packages,routers]=await Promise.all([
db.query("SELECT id,name,phone FROM customers WHERE isp_id=$1 ORDER BY name",[w.isp_id]),
db.query("SELECT id,name,speed,price,duration_days,status FROM packages WHERE isp_id=$1 AND status='active' ORDER BY price",[w.isp_id]),
db.query("SELECT id,name,status FROM mikrotik_routers WHERE isp_id=$1 AND enabled=true ORDER BY name",[w.isp_id])
]);res.json({customers:customers.rows,packages:packages.rows,routers:routers.rows});}