export const access='user'; export const methods=['GET','POST','PUT','DELETE'];
import { db } from 'hatchable';
import { workspaceFor,canManage } from 'lib/tenant-context.js';
import { provisionPppoe } from 'lib/mikrotik-provision.js';

export default async function(req,res){
  const w=await workspaceFor(req);
  if(!w)return res.status(403).json({error:'No ISP workspace assigned'});

  if(req.method==='GET'){
    const {rows}=await db.query("SELECT a.id,a.customer_id,a.router_id,a.package_id,a.username,a.password,a.profile,a.status,a.expires_at,a.created_at,c.name customer_name,c.phone customer_phone,r.name router_name,p.name package_name,p.speed package_speed,rc.last_seen_at connector_last_seen,rc.metadata connector_metadata FROM pppoe_accounts a LEFT JOIN customers c ON c.id=a.customer_id LEFT JOIN mikrotik_routers r ON r.id=a.router_id LEFT JOIN LATERAL (SELECT last_seen_at,metadata FROM router_connectors WHERE router_id=a.router_id ORDER BY last_seen_at DESC NULLS LAST LIMIT 1) rc ON true LEFT JOIN packages p ON p.id=a.package_id WHERE a.isp_id=$1 ORDER BY a.created_at DESC",[w.isp_id]);
    // Determine live state from the MikroTik itself. The connector heartbeat is
    // useful as a fallback, but it can legitimately contain an empty/stale
    // snapshot (for example immediately after reprovisioning). A customer who
    // is present in RouterOS /ppp/active must therefore be shown Online.
    const routerIds=[...new Set(rows.map(a=>a.router_id).filter(Boolean))];
    const liveByRouter=new Map();
    for(const routerId of routerIds){
      try{
        const r=await db.query('SELECT id,name,host,port,username,password,ssl FROM mikrotik_routers WHERE id=$1 AND isp_id=$2 AND enabled=true',[routerId,w.isp_id]);
        const router=r.rows[0];
        if(!router)continue;
        const base=`${router.ssl?'https':'http'}://${router.host}:${router.port||443}/rest`;
        const auth='Basic '+btoa(`${router.username}:${router.password}`);
        const x=await fetch(`${base}/ppp/active`,{headers:{Authorization:auth,Accept:'application/json'}});
        if(!x.ok)continue;
        const d=await x.json();
        liveByRouter.set(routerId,Array.isArray(d)?d:[]);
      }catch(e){
        // Fall back to the last connector snapshot below if direct REST is
        // temporarily unavailable.
      }
    }
    const now=Date.now();
    const accounts=rows.map(a=>{
      const direct=liveByRouter.get(a.router_id);
      const fresh=a.connector_last_seen&&now-new Date(a.connector_last_seen).getTime()<90000;
      const active=Array.isArray(direct)?direct:(fresh&&Array.isArray(a.connector_metadata?.ppp_active)?a.connector_metadata.ppp_active:[]);
      const session=active.find(s=>String(s?.name||'').trim().toLowerCase()===String(a.username||'').trim().toLowerCase());
      const expired=!!a.expires_at && new Date(a.expires_at)<=new Date();
      const blocked=a.status!=='active' || expired;
      return {...a,last_online:blocked?'offline':(session?'online':'offline'),online:blocked?false:!!session,active_address:blocked?null:(session?.address||null),active_uptime:blocked?null:(session?.uptime||null),caller_id:blocked?null:(session?.['caller-id']||session?.caller_id||null),bytes_in:blocked?0:Number(session?.['bytes-in']||session?.bytes_in||0),bytes_out:blocked?0:Number(session?.['bytes-out']||session?.bytes_out||0),password:undefined};
    });
    return res.json({accounts});
  }

  if(!canManage(w.role))return res.status(403).json({error:'Not permitted'});
  const b=req.body||{};

  if(req.method==='POST'){
    // Accept both the canonical API names and the friendly form names so the
    // PPPoE form cannot fail simply because a field was renamed in the UI.
    const username=String(b.username??'').trim();
    const password=String(b.password??'');
    const routerId=b.router_id??b.connection_id??b.connection??b.router;
    const customerId=b.customer_id??b.customer;
    const packageId=b.package_id??b.package;
    const expiresAt=b.expires_at??b.expiry_date??b.expiry;

    const missing=[];
    if(!username)missing.push('Username');
    if(!password)missing.push('Password');
    if(!routerId)missing.push('Connection');
    if(!customerId)missing.push('Customer');
    if(!packageId)missing.push('Package');
    if(!expiresAt)missing.push('Expiry');
    if(missing.length)return res.status(422).json({error:`Please complete: ${missing.join(', ')}`,missing});

    const p=await db.query("SELECT id,name,speed,status FROM packages WHERE id=$1 AND isp_id=$2",[packageId,w.isp_id]);
    if(!p.rows[0])return res.status(422).json({error:'Selected package was not found'});
    if(p.rows[0].status!=='active')return res.status(422).json({error:'Selected package is not active'});

    const customer=await db.query("SELECT id FROM customers WHERE id=$1 AND isp_id=$2",[customerId,w.isp_id]);
    if(!customer.rows[0])return res.status(422).json({error:'Selected customer was not found'});

    const router=await db.query("SELECT id,name FROM mikrotik_routers WHERE id=$1 AND isp_id=$2 AND enabled=true",[routerId,w.isp_id]);
    if(!router.rows[0])return res.status(422).json({error:'Selected MikroTik connection was not found or is disabled'});

    const speed=p.rows[0].speed||null;
    const profile=b.profile||p.rows[0].name;
    const {rows}=await db.query("INSERT INTO pppoe_accounts(isp_id,customer_id,router_id,package_id,username,password,profile,status,expires_at) VALUES($1,$2,$3,$4,$5,$6,$7,'active',$8) RETURNING id,customer_id,router_id,package_id,username,password,profile,status,expires_at,created_at",[w.isp_id,customerId,routerId,packageId,username,password,profile,expiresAt]);
    const account=rows[0];
    const network=await provisionPppoe(w.isp_id,account,routerId,speed);
    return res.status(201).json({account:{...account,password:undefined,speed,router_id:routerId,package_id:packageId},network});
  }

  const id=b.id;
  if(!id)return res.status(422).json({error:'Account id is required'});
  if(req.method==='DELETE'){
    const existing=await db.query("SELECT id,router_id,username FROM pppoe_accounts WHERE id=$1 AND isp_id=$2",[id,w.isp_id]);
    if(!existing.rows[0])return res.status(404).json({error:'PPPoE account not found'});
    const account=existing.rows[0];
    const connector=await db.query("SELECT id FROM router_connectors WHERE isp_id=$1 AND router_id=$2 ORDER BY last_seen_at DESC NULLS LAST LIMIT 1",[w.isp_id,account.router_id]);
    if(connector.rows[0]){
      // Never physically remove a live PPP secret from the router. Retire it
      // with the two safe, targeted operations instead.
      await db.query("INSERT INTO router_connector_jobs(connector_id,action,payload,status) VALUES($1,'mikrotik',$2,'pending')",[connector.rows[0].id,JSON.stringify({path:'/ppp/secret/disable',method:'POST',username:String(account.username)})]);
      await db.query("INSERT INTO router_connector_jobs(connector_id,action,payload,status) VALUES($1,'mikrotik',$2,'pending')",[connector.rows[0].id,JSON.stringify({path:'/ppp/active/disconnect',method:'POST',username:String(account.username)})]);
    }
    const r=await db.query("DELETE FROM pppoe_accounts WHERE id=$1 AND isp_id=$2",[id,w.isp_id]);
    if(!r.rowCount)return res.status(404).json({error:'PPPoE account not found'});
    return res.json({success:true,queued_for_router:!!connector.rows[0]});
  }
  if(req.method==='PUT'){
    const existing=await db.query("SELECT a.*,p.speed FROM pppoe_accounts a LEFT JOIN packages p ON p.id=a.package_id WHERE a.id=$1 AND a.isp_id=$2",[id,w.isp_id]);
    const old=existing.rows[0];
    if(!old)return res.status(404).json({error:'PPPoE account not found'});
    const username=String(b.username ?? old.username).trim();
    const password=String(b.password ?? (old.password || ''));
    const routerId=b.router_id ?? b.connection ?? old.router_id;
    const customerId=b.customer_id ?? b.customer ?? old.customer_id;
    const packageId=b.package_id ?? b.package ?? old.package_id;
    const profile=String(b.profile ?? (old.profile || '')).trim();
    const status=String(b.status ?? (old.status || 'active'));
    const expiresAt=b.expires_at ?? b.expiry ?? old.expires_at;
    if(!username||!password||!routerId||!customerId||!packageId)return res.status(422).json({error:'Username, password, connection, customer and package are required'});
    if(!['active','disabled','expired','suspended'].includes(status))return res.status(422).json({error:'Invalid status'});
    const checks=await db.query("SELECT (SELECT id FROM customers WHERE id=$1 AND isp_id=$4) customer_id,(SELECT id FROM packages WHERE id=$2 AND isp_id=$4 AND status='active') package_id,(SELECT id FROM mikrotik_routers WHERE id=$3 AND isp_id=$4 AND enabled=true) router_id",[customerId,packageId,routerId,w.isp_id]);
    const chk=checks.rows[0];
    if(!chk.customer_id)return res.status(422).json({error:'Selected customer was not found'});
    if(!chk.package_id)return res.status(422).json({error:'Selected package was not found or is not active'});
    if(!chk.router_id)return res.status(422).json({error:'Selected MikroTik connection was not found or is disabled'});
    const duplicate=await db.query("SELECT id FROM pppoe_accounts WHERE isp_id=$1 AND lower(username)=lower($2) AND id<>$3",[w.isp_id,username,id]);
    if(duplicate.rows[0])return res.status(409).json({error:'That PPPoE username is already in use'});
    if(String(old.username)!==username){
      const connector=await db.query("SELECT id FROM router_connectors WHERE isp_id=$1 AND router_id=$2 ORDER BY last_seen_at DESC NULLS LAST LIMIT 1",[w.isp_id,old.router_id]);
      if(connector.rows[0]){
        // Username changes retire the old secret safely; do not physically remove it.
        await db.query("INSERT INTO router_connector_jobs(connector_id,action,payload,status) VALUES($1,'mikrotik',$2,'pending')",[connector.rows[0].id,JSON.stringify({path:'/ppp/secret/disable',method:'POST',username:String(old.username)})]);
        await db.query("INSERT INTO router_connector_jobs(connector_id,action,payload,status) VALUES($1,'mikrotik',$2,'pending')",[connector.rows[0].id,JSON.stringify({path:'/ppp/active/disconnect',method:'POST',username:String(old.username)})]);
      }
    }
    const updated=await db.query("UPDATE pppoe_accounts SET username=$1,password=$2,router_id=$3,customer_id=$4,package_id=$5,profile=$6,status=$7,service_locked=$8,expires_at=$9,updated_at=now() WHERE id=$10 AND isp_id=$11 RETURNING id,customer_id,router_id,package_id,username,profile,status,service_locked,expires_at,created_at",[username,password,routerId,customerId,packageId,profile,status,['disabled','suspended','expired'].includes(status),expiresAt,id,w.isp_id]);
    const account=updated.rows[0];
    const pkg=await db.query("SELECT speed FROM packages WHERE id=$1 AND isp_id=$2",[packageId,w.isp_id]);
    const network=await provisionPppoe(w.isp_id,{...account,password,speed:pkg.rows[0]?.speed||null},routerId,pkg.rows[0]?.speed||null);
    return res.json({success:true,account:{...account,password:undefined},network});
  }

  const allowed=['status','profile','expires_at','password'];
  if(!allowed.includes(b.field))return res.status(422).json({error:'Invalid update'});
  const existing=await db.query("SELECT a.id,a.router_id,a.username,a.password,a.profile,a.status,a.expires_at,p.speed FROM pppoe_accounts a LEFT JOIN packages p ON p.id=a.package_id WHERE a.id=$1 AND a.isp_id=$2",[id,w.isp_id]);
  if(!existing.rows[0])return res.status(404).json({error:'PPPoE account not found'});
  const old=existing.rows[0];
  const field=String(b.field);
  const value=b.value;
  const r=await db.query("UPDATE pppoe_accounts SET "+field+"=$1,updated_at=now() WHERE id=$2 AND isp_id=$3 RETURNING id,router_id,username,password,profile,status,expires_at",[value,id,w.isp_id]);
  if(!r.rows[0])return res.status(404).json({error:'PPPoE account not found'});
  const account=r.rows[0];

  // A BillWave status change must also be enforced on the MikroTik. In
  // particular, suspending an already-connected customer requires BOTH
  // disabling the PPP secret and disconnecting the live PPPoE session.
  const connector=await db.query("SELECT id FROM router_connectors WHERE isp_id=$1 AND router_id=$2 ORDER BY last_seen_at DESC NULLS LAST LIMIT 1",[w.isp_id,old.router_id]);
  if(connector.rows[0] && field==='status'){
    const status=String(value);
    if(['disabled','suspended','expired'].includes(status)){
      await db.query("INSERT INTO router_connector_jobs(connector_id,action,payload,status) VALUES($1,'mikrotik',$2,'pending')",[connector.rows[0].id,JSON.stringify({path:'/ppp/secret/disable',method:'POST',username:String(old.username)})]);
      await db.query("INSERT INTO router_connector_jobs(connector_id,action,payload,status) VALUES($1,'mikrotik',$2,'pending')",[connector.rows[0].id,JSON.stringify({path:'/ppp/active/disconnect',method:'POST',username:String(old.username)})]);
    }else if(status==='active'){
      const allowEnable=old.expires_at?new Date(old.expires_at)>new Date():true;
      await db.query("INSERT INTO router_connector_jobs(connector_id,action,payload,status) VALUES($1,'mikrotik',$2,'pending')",[connector.rows[0].id,JSON.stringify({path:'/ppp/secret/upsert',method:'POST',username:String(old.username),password:String(old.password||''),profile:String(old.profile||''),disabled:!allowEnable,expires_at:old.expires_at,status:'active',allow_enable:allowEnable,rate_limit:old.speed?String(old.speed).replace(/\\s+/g,'').replace(/Mbps?/i,'M').replace(/Gbps?/i,'G'):undefined})]);
    }
  }
  return res.json({account:{...account,password:undefined},router_action:connector.rows[0]&&field==='status'?String(value):null});
}