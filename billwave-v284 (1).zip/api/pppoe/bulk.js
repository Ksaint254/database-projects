export const access='user';
export const methods=['POST'];
import { db } from 'hatchable';
import { workspaceFor,canManage } from 'lib/tenant-context.js';
import { provisionPppoe } from 'lib/mikrotik-provision.js';

export default async function(req,res){
  const w=await workspaceFor(req);
  if(!w)return res.status(403).json({error:'No ISP workspace assigned'});
  if(!canManage(w.role))return res.status(403).json({error:'Not permitted'});
  const b=req.body||{};
  if(!Array.isArray(b.ids)||!b.ids.length||!['activate','suspend','enable','disable','delete','sync'].includes(b.action))return res.status(422).json({error:'Select accounts and a valid action'});

  if(b.action==='delete'){
    const accounts=await db.query("SELECT id,router_id,username FROM pppoe_accounts WHERE isp_id=$1 AND id=ANY($2::uuid[])",[w.isp_id,b.ids]);
    for(const a of accounts.rows){
      const connector=await db.query("SELECT id FROM router_connectors WHERE isp_id=$1 AND router_id=$2 ORDER BY last_seen_at DESC NULLS LAST LIMIT 1",[w.isp_id,a.router_id]);
      if(connector.rows[0]){
        // Bulk deletion must use only targeted disable/disconnect operations.
        // Physical PPP secret removal has caused collateral session churn.
        await db.query("INSERT INTO router_connector_jobs(connector_id,action,payload,status) VALUES($1,'mikrotik',$2,'pending')",[connector.rows[0].id,JSON.stringify({path:'/ppp/secret/disable',method:'POST',username:String(a.username)})]);
        await db.query("INSERT INTO router_connector_jobs(connector_id,action,payload,status) VALUES($1,'mikrotik',$2,'pending')",[connector.rows[0].id,JSON.stringify({path:'/ppp/active/disconnect',method:'POST',username:String(a.username)})]);
      }
    }
    const q=await db.query("DELETE FROM pppoe_accounts WHERE isp_id=$1 AND id=ANY($2::uuid[])",[w.isp_id,b.ids]);
    return res.json({success:true,affected:q.rowCount,queued_for_router:accounts.rows.length});
  }

  if(b.action==='sync'){
    const q=await db.query("SELECT a.*,p.speed FROM pppoe_accounts a LEFT JOIN packages p ON p.id=a.package_id WHERE a.isp_id=$1 AND a.id=ANY($2::uuid[])",[w.isp_id,b.ids]);
    const results=[];
    for(const a of q.rows){
      try{ results.push({id:a.id,username:a.username,network:await provisionPppoe(w.isp_id,a,a.router_id,a.speed)}); }
      catch(e){ results.push({id:a.id,username:a.username,error:String(e?.message||e)}); }
    }
    return res.json({success:true,affected:q.rowCount,results});
  }

  const status=(b.action==='activate'||b.action==='enable')?'active':'disabled';
  const q=await db.query("UPDATE pppoe_accounts SET status=$1,service_locked=$2,updated_at=now() WHERE isp_id=$3 AND id=ANY($4::uuid[])",[status,status==='disabled',w.isp_id,b.ids]);
  const accounts=await db.query("SELECT a.*,p.speed FROM pppoe_accounts a LEFT JOIN packages p ON p.id=a.package_id WHERE a.isp_id=$1 AND a.id=ANY($2::uuid[])",[w.isp_id,b.ids]);
  for(const a of accounts.rows){
    try{ await provisionPppoe(w.isp_id,a,a.router_id,a.speed); }catch(e){}
  }
  res.json({success:true,affected:q.rowCount,status});
}