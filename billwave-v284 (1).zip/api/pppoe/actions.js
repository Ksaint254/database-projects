export const access='user'; export const methods=['POST'];
import { db } from 'hatchable';
import { workspaceFor,canManage } from 'lib/tenant-context.js';
import { provisionPppoe } from 'lib/mikrotik-provision.js';
export default async function(req,res){
 const w=await workspaceFor(req); if(!w)return res.status(403).json({error:'No ISP workspace assigned'}); if(!canManage(w.role))return res.status(403).json({error:'Not permitted'});
 const b=req.body||{}; if(!b.id||!b.action)return res.status(422).json({error:'Account and action are required'});
 const q=await db.query("SELECT a.*,p.speed FROM pppoe_accounts a LEFT JOIN packages p ON p.id=a.package_id WHERE a.id=$1 AND a.isp_id=$2",[b.id,w.isp_id]); const a=q.rows[0]; if(!a)return res.status(404).json({error:'PPPoE account not found'});
 let status=a.status; if(b.action==='activate')status='active'; if(b.action==='suspend')status='disabled';
 if(b.action==='reset-password'){if(!b.password)return res.status(422).json({error:'New password is required'});await db.query("UPDATE pppoe_accounts SET password=$1,updated_at=now() WHERE id=$2 AND isp_id=$3",[String(b.password),a.id,w.isp_id]);a.password=String(b.password)}
 if(b.action==='extend'){if(!b.expires_at)return res.status(422).json({error:'New expiry is required'});await db.query("UPDATE pppoe_accounts SET expires_at=$1,status='active',service_locked=false,updated_at=now() WHERE id=$2 AND isp_id=$3",[b.expires_at,a.id,w.isp_id]);a.expires_at=b.expires_at;status='active'}
 if(['activate','suspend'].includes(b.action)){
  const locked=b.action==='suspend';
  await db.query("UPDATE pppoe_accounts SET status=$1,service_locked=$2,updated_at=now() WHERE id=$3 AND isp_id=$4",[status,locked,a.id,w.isp_id]);
  a.status=status; a.service_locked=locked;
 }
 if(!['activate','suspend','reset-password','extend'].includes(b.action))return res.status(422).json({error:'Unsupported PPPoE action'});
 // provisionPppoe is the single synchronization path. It now deliberately
 // queues disable+disconnect for inactive/service-locked accounts and never
 // emits a secret upsert for them. This prevents a suspend from being undone
 // by the final synchronization step.
 const network=await provisionPppoe(w.isp_id,a,a.router_id,a.speed);
 res.json({success:true,status:a.status||status,message:b.action+' completed and queued for MikroTik synchronization.',network});
}