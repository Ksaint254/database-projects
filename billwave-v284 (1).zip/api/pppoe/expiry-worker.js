export const access = 'scheduler';
export const methods = ['POST'];
export const schedule = '0 * * * *';
import { db, email } from 'hatchable';
export default async function(req,res){
  const expired=await db.query("SELECT a.id,a.isp_id,a.router_id,a.customer_id,a.username,a.status,a.service_locked,a.expires_at FROM pppoe_accounts a WHERE a.expires_at IS NOT NULL AND a.expires_at<now() AND a.status IN ('active','disabled','suspended','expired') ORDER BY a.expires_at");
  let changed=0,queued=0,notified=0;
  for(const a of expired.rows){
    if(a.status!=='disabled' || a.service_locked===true){
      const r=await db.query("UPDATE pppoe_accounts SET status='disabled',service_locked=false,updated_at=now() WHERE id=$1 AND isp_id=$2 RETURNING id",[a.id,a.isp_id]);
      changed+=r.rowCount||0;
    }
    const connector=await db.query("SELECT id FROM router_connectors WHERE isp_id=$1 AND router_id=$2 ORDER BY last_seen_at DESC NULLS LAST LIMIT 1",[a.isp_id,a.router_id]);
    if(connector.rows[0]&&String(a.username||'').trim()){
      const username=String(a.username).trim();
      const paths=[
        {path:'/ppp/secret/disable',method:'POST',username},
        {path:'/ppp/active/disconnect',method:'POST',username}
      ];
      for(const payload of paths){
        const existing=await db.query("SELECT id FROM router_connector_jobs WHERE connector_id=$1 AND status IN ('pending','running') AND payload->>'path'=$2 AND payload->>'username'=$3 LIMIT 1",[connector.rows[0].id,payload.path,username]);
        if(!existing.rows[0]){
          await db.query("INSERT INTO router_connector_jobs(connector_id,action,payload,status) VALUES($1,'mikrotik',$2,'pending')",[connector.rows[0].id,JSON.stringify(payload)]);
          queued++;
        }
      }
    }
    const c=await db.query("SELECT email,name FROM customers WHERE id=$1 AND isp_id=$2 LIMIT 1",[a.customer_id,a.isp_id]);
    if(c.rows[0]?.email&&a.status!=='disabled'){
      try{await email.send({to:c.rows[0].email,subject:'Internet account expired',html:`<p>Hello ${String(c.rows[0].name||'Customer').replace(/[&<>]/g,'')}, your BillWave internet account has expired. Please renew your package to restore access.</p>`});notified++}catch(e){}
    }
  }
  res.json({success:true,expired:expired.rowCount,changed,queued,notifications_sent:notified,accounts:expired.rows.map(x=>({id:x.id,username:x.username,expires_at:x.expires_at}))});
}