export const access='admin';
export const methods=['GET'];
export default async function(req,res){
 const email=process.env.TUMA_EMAIL;
 const apiKey=process.env.TUMA_API_KEY;
 if(!email||!apiKey)return res.status(503).json({success:false,configured:false,message:'Tuma credentials are not configured in Hatchable secrets.'});
 const r=await fetch('https://api.tuma.co.ke/auth/token',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({email,api_key:apiKey})});
 const data=await r.json().catch(()=>({}));
 if(!r.ok||!data.success)return res.status(502).json({success:false,configured:true,message:data.message||'Tuma authentication failed'});
 const d=data.data||data;
 return res.json({success:true,configured:true,business:{id:d.shop?.id||d.business?.id||null,name:d.shop?.name||d.business?.name||null,email:d.shop?.email||d.business?.email||email},expires_in:d.expires_in||null});
}