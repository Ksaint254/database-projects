import { db } from 'hatchable';
import { workspaceFor } from 'lib/tenant-context.js';
export const access='user';
export const methods=['POST'];
export default async function(req,res){
 const w=await workspaceFor(req); if(!w)return res.status(403).json({error:'No ISP workspace assigned'});
 const {plan_id,phone,amount}=req.body||{};
 if(!plan_id||!phone)return res.status(422).json({error:'Plan and M-Pesa phone number are required'});
 const plan=await db.query("SELECT id,name,monthly_price FROM billwave_plans WHERE id=$1 AND status='active'",[plan_id]);
 if(!plan.rows.length)return res.status(422).json({error:'Invalid BillWave plan'});
 const expected=Number(plan.rows[0].monthly_price);
 const requested=amount===undefined?expected:Number(amount);
 if(!Number.isFinite(requested)||requested<=0||requested!==expected)return res.status(422).json({error:'Payment amount must match the selected BillWave plan'});
 const normalized=String(phone).replace(/\\s+/g,'').replace(/^\\+/, '');
 if(!/^2547\\d{8}$/.test(normalized))return res.status(422).json({error:'Use a valid Kenyan M-Pesa number such as 254712345678'});
 const email=process.env.TUMA_EMAIL, apiKey=process.env.TUMA_API_KEY;
 if(!email||!apiKey)return res.status(503).json({error:'Tuma is not configured. Add TUMA_EMAIL and TUMA_API_KEY in Hatchable secrets.'});
 const tokenResp=await fetch('https://api.tuma.co.ke/auth/token',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({email,api_key:apiKey})});
 const tokenData=await tokenResp.json().catch(()=>({}));
 if(!tokenResp.ok||!tokenData.success)return res.status(502).json({error:tokenData.message||'Unable to authenticate with Tuma'});
 const token=tokenData.data?.token||tokenData.token;
 if(!token)return res.status(502).json({error:'Tuma returned no access token'});
 let sub=await db.query("SELECT id FROM isp_subscriptions WHERE isp_id=$1 ORDER BY created_at DESC LIMIT 1",[w.isp_id]);
 if(!sub.rows.length)sub=await db.query("INSERT INTO isp_subscriptions(isp_id,plan_id,status) VALUES($1,$2,'pending') RETURNING id",[w.isp_id,plan_id]);
 else await db.query("UPDATE isp_subscriptions SET plan_id=$1,status=CASE WHEN status='active' THEN status ELSE 'pending' END WHERE id=$2 AND isp_id=$3",[plan_id,sub.rows[0].id,w.isp_id]);
 const payment=await db.query("INSERT INTO billwave_subscription_payments(isp_subscription_id,amount,payment_method,reference,status,paid_at,provider) VALUES($1,$2,'mpesa_tuma',NULL,'pending',NULL,'tuma') RETURNING id",[sub.rows[0].id,requested]);
 const callback=`${new URL(req.url).origin}/api/tuma/callback`;
 const stk=await fetch('https://api.tuma.co.ke/payment/stk-push',{method:'POST',headers:{'Content-Type':'application/json','Authorization':`Bearer ${token}`},body:JSON.stringify({amount:requested,phone:normalized,callback_url:callback,description:`BillWave ${plan.rows[0].name} subscription`})});
 const data=await stk.json().catch(()=>({}));
 if(!stk.ok||!data.success){await db.query("UPDATE billwave_subscription_payments SET status='failed',result_description=$1 WHERE id=$2",[data.message||'Tuma STK Push failed',payment.rows[0].id]);return res.status(502).json({error:data.message||'Tuma STK Push failed'});}
 const d=data.data||data;
 await db.query("UPDATE billwave_subscription_payments SET merchant_request_id=$1,checkout_request_id=$2 WHERE id=$3",[d.merchant_request_id||null,d.checkout_request_id||null,payment.rows[0].id]);
 return res.status(201).json({success:true,payment_id:payment.rows[0].id,merchant_request_id:d.merchant_request_id||null,checkout_request_id:d.checkout_request_id||null,customer_message:d.customer_message||data.message||'Complete the M-Pesa prompt on your phone.'});
}