import { db } from 'hatchable';
import { setPppoeEnabled } from '../../lib/mikrotik-auto.js';

export const access='public';
export const methods=['POST'];

function val(...xs){for(const x of xs){if(x!==undefined&&x!==null&&String(x).trim()!=='')return x}return null}
function ok(b){const r=String(val(b.result_code,b.resultCode,b.ResultCode,b.status,b.Status,b.success)||'').toLowerCase();return r==='0'||r==='completed'||r==='success'||r==='true'}
function num(v){const n=Number(v);return Number.isFinite(n)?n:0}
function receipt(b){return val(b.mpesa_receipt_number,b.mpesa_receipt,b.receipt_number,b.transaction_id,b.receipt,b.reference,b.data?.mpesa_receipt_number,b.data?.receipt_number)}
function account(b){return val(b.account_number,b.accountNumber,b.account,b.account_reference,b.accountReference,b.bill_reference,b.reference,b.data?.account_number,b.data?.account,b.data?.account_reference)}
function ispId(b){return val(b.isp_id,b.ispId,b.business_id,b.businessId,b.tuma_business_id,b.shop_id,b.shopId,b.data?.isp_id,b.data?.business_id,b.data?.shop_id)}

export default async function(req,res){
  const b=req.body||{};
  const accountNumber=String(account(b)||'').trim();
  const amount=num(val(b.amount,b.Amount,b.paid_amount,b.data?.amount));
  const receiptNumber=receipt(b);
  if(!accountNumber||amount<=0)return res.status(400).json({received:false,error:'Account number and positive payment amount are required'});
  if(!ok(b))return res.json({received:true,processed:false,status:'ignored'});

  const existing=receiptNumber?await db.query('SELECT id,status FROM tuma_collection_transactions WHERE receipt_number=$1 LIMIT 1',[receiptNumber]):{rows:[]};
  if(existing.rows[0])return res.json({received:true,processed:existing.rows[0].status==='completed',already_processed:true});

  let customer;
  const q=await db.query('SELECT id,isp_id,account_number,customer_number,name,package_id,status FROM customers WHERE account_number=$1 LIMIT 1',[accountNumber]);
  if(!q.rows[0])return res.status(404).json({received:true,processed:false,error:'Customer account number not found'});
  customer=q.rows[0];

  const suppliedIsp=String(ispId(b)||'').trim();
  if(suppliedIsp && suppliedIsp!==String(customer.isp_id))return res.status(400).json({received:true,processed:false,error:'Payment business does not match customer ISP'});

  const inserted=await db.query('INSERT INTO tuma_collection_transactions(isp_id,customer_id,account_number,amount,receipt_number,provider_transaction_id,status,raw_callback) VALUES($1,$2,$3,$4,$5,$6,\'processing\',$7) ON CONFLICT DO NOTHING RETURNING id',[customer.isp_id,customer.id,accountNumber,amount,receiptNumber,val(b.provider_transaction_id,b.providerTransactionId,b.transaction_id,b.transactionId),JSON.stringify(b)]);
  if(!inserted.rows[0])return res.json({received:true,already_processed:true});
  const txId=inserted.rows[0].id;

  try{
    let remaining=amount;
    const service=await db.query("SELECT 1 FROM pppoe_accounts WHERE customer_id=$1 AND isp_id=$2 LIMIT 1",[customer.id,customer.isp_id]);
    const isPppoe=service.rows.length>0;
    const invoices=await db.query("SELECT id,invoice_number,subscription_id,balance FROM invoices WHERE customer_id=$1 AND isp_id=$2 AND status IN ('unpaid','partial') AND balance>0 ORDER BY due_date NULLS LAST,created_at ASC FOR UPDATE",[customer.id,customer.isp_id]);
    let applied=0; let activated=false; let lastInvoice=null;
    for(const inv of invoices.rows){
      if(remaining<=0)break;
      const due=Number(inv.balance||0), take=Math.min(due,remaining);
      if(take<=0)continue;
      const p=await db.query('INSERT INTO payments(isp_id,customer_id,invoice_id,amount,method,reference,paid_at) VALUES($1,$2,$3,$4,\'tuma_paybill\',$5,now()) RETURNING id',[customer.isp_id,customer.id,inv.id,take,receiptNumber||accountNumber]);
      const newBal=Math.max(0,due-take); const status=newBal<=0?'paid':'partial';
      await db.query('UPDATE invoices SET balance=$1,status=$2 WHERE id=$3',[newBal,status,inv.id]);
      const fee=isPppoe?Math.round(take*0.0055*100)/100:0;
      if(fee>0)await db.query("INSERT INTO billwave_platform_fees(isp_id,payment_id,service,rate,payment_amount,fee_amount,status) VALUES($1,$2,'pppoe',$3,$4,$5,'accrued')",[customer.isp_id,p.rows[0]?.id||null,0.0055,take,fee]);
      applied+=take; remaining-=take; lastInvoice={...inv,balance:newBal,status};
    }

    if(lastInvoice?.status==='paid' && lastInvoice.subscription_id){
      const s=await db.query('SELECT s.id,s.package_id,s.expires_at,p.speed,p.duration_days FROM subscriptions s JOIN packages p ON p.id=s.package_id WHERE s.id=$1 AND s.customer_id=$2 AND s.isp_id=$3 LIMIT 1',[lastInvoice.subscription_id,customer.id,customer.isp_id]);
      if(s.rows[0]){
        const base=s.rows[0].expires_at&&new Date(s.rows[0].expires_at)>new Date()?new Date(s.rows[0].expires_at):new Date();
        const expiry=new Date(base.getTime()+Number(s.rows[0].duration_days||30)*86400000);
        await db.query("UPDATE subscriptions SET status='active',starts_at=COALESCE(starts_at,now()),expires_at=$1,updated_at=now() WHERE id=$2",[expiry.toISOString(),s.rows[0].id]);
        const a=await db.query("SELECT id,username FROM pppoe_accounts WHERE customer_id=$1 AND isp_id=$2 ORDER BY created_at DESC LIMIT 1",[customer.id,customer.isp_id]);
        if(a.rows[0]){
          await db.query("UPDATE pppoe_accounts SET status='active',service_locked=false,expires_at=$1,profile=COALESCE($2,profile),updated_at=now() WHERE id=$3",[expiry.toISOString(),s.rows[0].speed||null,a.rows[0].id]);
          const network=await setPppoeEnabled(customer.isp_id,a.rows[0].username,true); activated=!!network.ok;
        }
        await db.query("UPDATE customers SET status='active',package_id=$1,updated_at=now() WHERE id=$2 AND isp_id=$3",[s.rows[0].package_id,customer.id,customer.isp_id]);
      }
    }

    await db.query("UPDATE tuma_collection_transactions SET status='completed',updated_at=now() WHERE id=$1",[txId]);
    return res.json({received:true,processed:true,account_number:accountNumber,amount,applied_amount:applied,unapplied_amount:Math.max(0,remaining),pppoe_activated:activated});
  }catch(e){
    await db.query("UPDATE tuma_collection_transactions SET status='failed',updated_at=now() WHERE id=$1",[txId]);
    console.error('Tuma PayBill callback processing failed',e);
    return res.status(200).json({received:true,processed:false,error:'Payment received but processing failed; it remains visible for reconciliation'});
  }
}