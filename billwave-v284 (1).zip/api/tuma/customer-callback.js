import { db } from 'hatchable';
import { setPppoeEnabled } from '../../lib/mikrotik-auto.js';

// Public webhook: Tuma calls this after an ISP customer's STK payment completes.
// It is intentionally public because the request originates from Tuma, not a
// signed-in BillWave user. The payment is correlated to a pending transaction
// created by BillWave before the STK Push is sent.
export const access='public';
export const methods=['POST'];

function clean(v){ return String(v ?? '').trim(); }

function callbackValue(body, key){
  return body?.[key] ?? body?.data?.[key] ?? body?.result?.[key] ?? null;
}

function isSuccess(body){
  const status=clean(callbackValue(body,'status')).toLowerCase();
  const code=clean(callbackValue(body,'result_code') ?? body?.ResultCode);
  return status==='completed' || code==='0' || (body?.success===true && status!=='failed');
}

function receiptOf(body){
  return callbackValue(body,'mpesa_receipt_number') ||
    callbackValue(body,'mpesa_receipt') ||
    callbackValue(body,'receipt') ||
    callbackValue(body,'receipt_number') ||
    callbackValue(body,'transaction_id') || null;
}

export default async function(req,res){
  const b=req.body||{};
  const checkout=clean(callbackValue(b,'checkout_request_id')) || null;
  const merchant=clean(callbackValue(b,'merchant_request_id')) || null;
  if(!checkout&&!merchant) return res.status(422).json({success:false,message:'Missing Tuma transaction identifier'});

  let q=checkout
    ? await db.query('SELECT * FROM mpesa_transactions WHERE checkout_request_id=$1 LIMIT 1',[checkout])
    : {rows:[]};
  if(!q.rows.length&&merchant){
    q=await db.query('SELECT * FROM mpesa_transactions WHERE merchant_request_id=$1 ORDER BY created_at DESC LIMIT 1',[merchant]);
  }
  if(!q.rows.length) return res.json({success:true,received:true,matched:false});

  const tx=q.rows[0];
  if(tx.status==='completed') return res.json({success:true,received:true,already_processed:true});
  if(tx.status==='failed') return res.json({success:true,received:true,already_processed:true});

  const code=clean(callbackValue(b,'result_code') ?? b?.ResultCode);
  const description=clean(callbackValue(b,'result_desc') ?? callbackValue(b,'result_description') ?? b?.ResultDesc) || 'Tuma payment failed';

  if(!isSuccess(b)){
    await db.query("UPDATE mpesa_transactions SET status='failed',result_code=$1,result_description=$2,raw_callback=$3,updated_at=now() WHERE id=$4 AND status='pending'",[code,description,JSON.stringify(b),tx.id]);
    return res.json({success:true,received:true,status:'failed'});
  }

  const amount=Number(callbackValue(b,'amount') ?? tx.amount);
  const expected=Number(tx.amount);
  if(!Number.isFinite(amount) || !Number.isFinite(expected) || Math.abs(amount-expected)>0.001){
    await db.query("UPDATE mpesa_transactions SET status='failed',result_code=$1,result_description=$2,raw_callback=$3,updated_at=now() WHERE id=$4 AND status='pending'",[code||'AMOUNT_MISMATCH','Payment amount mismatch',JSON.stringify(b),tx.id]);
    return res.status(409).json({success:false,message:'Payment amount mismatch'});
  }

  // Claim the transaction before changing billing state. This makes repeated
  // webhook deliveries safe even when Tuma retries the callback.
  const claimed=await db.query("UPDATE mpesa_transactions SET status='processing',result_code=$1,result_description=$2,raw_callback=$3,updated_at=now() WHERE id=$4 AND status='pending' RETURNING id",[code,description,JSON.stringify(b),tx.id]);
  if(!claimed.rows.length) return res.json({success:true,received:true,already_processed:true});

  try{
    const receipt=receiptOf(b);
    const inv=await db.query('SELECT id,customer_id,subscription_id,balance,status FROM invoices WHERE id=$1 AND isp_id=$2 LIMIT 1',[tx.invoice_id,tx.isp_id]);
    if(!inv.rows[0]) throw new Error('Invoice not found for Tuma transaction');

    const invoice=inv.rows[0];
    const paymentRow=await db.query("INSERT INTO payments(isp_id,customer_id,invoice_id,amount,method,reference) VALUES($1,$2,$3,$4,'mpesa_tuma',$5) RETURNING id",[tx.isp_id,tx.customer_id,tx.invoice_id,amount,receipt]);
    // BillWave platform fee: 0.55% on PPPoE payments only. The full customer
    // payment remains the ISP's Tuma settlement; this ledger records the fee
    // owed to BillWave so it can be settled through the ISP billing account.
    const fee=Math.round(amount*0.0055*100)/100;
    if(fee>0){
      await db.query("INSERT INTO billwave_platform_fees(isp_id,payment_id,service,rate,payment_amount,fee_amount,status) VALUES($1,$2,'pppoe',$3,$4,$5,'accrued')",[tx.isp_id,paymentRow.rows[0]?.id||null,0.0055,amount,fee]);
    }
    const paidInvoice=await db.query("UPDATE invoices SET balance=GREATEST(balance-$1,0),status=CASE WHEN balance-$1<=0 THEN 'paid' ELSE 'partial' END WHERE id=$2 AND isp_id=$3 RETURNING balance,status",[amount,tx.invoice_id,tx.isp_id]);

    let activated=false;
    let pppoeUsername=null;
    let expiresAt=null;

    // Internet subscriptions activate only when the invoice is fully paid.
    // The new expiry extends from the later of now or the customer's current
    // expiry, so an early renewal never throws away remaining service time.
    if(paidInvoice.rows[0]?.status==='paid' && invoice.subscription_id){
      const sub=await db.query("SELECT s.id,s.customer_id,s.package_id,s.expires_at,p.duration_days,p.speed FROM subscriptions s JOIN packages p ON p.id=s.package_id WHERE s.id=$1 AND s.isp_id=$2 LIMIT 1",[invoice.subscription_id,tx.isp_id]);
      if(sub.rows[0]){
        const s=sub.rows[0];
        const days=Math.max(1,Number(s.duration_days)||30);
        const base=s.expires_at && new Date(s.expires_at)>new Date() ? new Date(s.expires_at) : new Date();
        const expiry=new Date(base.getTime()+days*86400000);
        expiresAt=expiry.toISOString();

        await db.query("UPDATE subscriptions SET status='active',starts_at=COALESCE(starts_at,now()),expires_at=$1,amount=$2,updated_at=now() WHERE id=$3 AND isp_id=$4",[expiresAt,amount,s.id,tx.isp_id]);

        const accounts=await db.query("SELECT id,username FROM pppoe_accounts WHERE customer_id=$1 AND isp_id=$2 ORDER BY created_at DESC LIMIT 1",[tx.customer_id,tx.isp_id]);
        if(accounts.rows[0]){
          pppoeUsername=accounts.rows[0].username;
          await db.query("UPDATE pppoe_accounts SET status='active',service_locked=false,expires_at=$1,profile=COALESCE($2,profile),updated_at=now() WHERE id=$3 AND isp_id=$4",[expiresAt,s.speed||null,accounts.rows[0].id,tx.isp_id]);
          const network=await setPppoeEnabled(tx.isp_id,pppoeUsername,true);
          activated=!!network.ok;
        }

        await db.query("UPDATE customers SET status='active',package_id=$1,updated_at=now() WHERE id=$2 AND isp_id=$3",[s.package_id,tx.customer_id,tx.isp_id]);
      }
    }

    await db.query("UPDATE mpesa_transactions SET status='completed',mpesa_receipt=$1,result_code=$2,result_description=$3,raw_callback=$4,updated_at=now() WHERE id=$5",[receipt,code,description,JSON.stringify(b),tx.id]);
    return res.json({success:true,received:true,status:'paid',pppoe_activated:activated,pppoe_username:pppoeUsername,expires_at:expiresAt});
  }catch(e){
    await db.query("UPDATE mpesa_transactions SET status='failed',result_code=$1,result_description=$2,raw_callback=$3,updated_at=now() WHERE id=$4",['PROCESSING_ERROR',String(e?.message||e).slice(0,500),JSON.stringify(b),tx.id]);
    return res.status(500).json({success:false,received:true,message:'Payment received but automatic activation failed. BillWave will require manual reconciliation.'});
  }
}